-- MySQL dump 10.19  Distrib 10.3.31-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.3.31-MariaDB-1:10.3.31+maria~focal-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `config` text COLLATE utf8_unicode_ci NOT NULL,
  `icon` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `identifier` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `title` varchar(120) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `widgets` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
INSERT INTO `be_dashboards` VALUES (1,0,1639056577,1639056577,1,0,0,0,0,'bbd20be9cf1d214dbb55121afb6e32a455e9cfb9','My dashboard','{\"017b83c2de81229f2437e732fc479d030ef31df2\":{\"identifier\":\"t3information\"},\"0477cdf209020d4319eccf523300f13ab9dc29e9\":{\"identifier\":\"t3news\"},\"d3cda5d5cfe2e0befc4fe84256fc983d339e91c1\":{\"identifier\":\"docGettingStarted\"}}');
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `non_exclude_fields` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `explicit_allowdeny` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `allowed_languages` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `custom_options` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `db_mountpoints` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `pagetypes_select` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tables_select` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tables_modify` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `groupMods` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `availableWidgets` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_mountpoints` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_permissions` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `lockToDomain` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `subgroup` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `category_perms` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  `ses_backuserid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
INSERT INTO `be_sessions` VALUES ('cc9c186d914bd017f8e950f2c351012f','[DISABLED]',1,1639059425,'a:5:{s:26:\"formProtectionSessionToken\";s:64:\"3182f95bfc7d9cae6d47a17095117576a021425270d73d9b17e25304691ceac5\";s:27:\"core.template.flashMessages\";N;s:80:\"extbase.flashmessages.tx_extensionmanager_tools_extensionmanagerextensionmanager\";N;s:52:\"TYPO3\\CMS\\Recordlist\\Controller\\RecordListController\";a:1:{s:12:\"search_field\";s:0:\"\";}s:26:\"extbase.flashmessages.tx__\";N;}',0);
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `usergroup` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `lang` varchar(6) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `db_mountpoints` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `options` smallint(5) unsigned NOT NULL DEFAULT 0,
  `realName` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `userMods` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `allowed_languages` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `uc` mediumblob DEFAULT NULL,
  `file_mountpoints` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `file_permissions` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `lockToDomain` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `disableIPlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastlogin` int(10) unsigned NOT NULL DEFAULT 0,
  `createdByAction` int(11) NOT NULL DEFAULT 0,
  `usergroup_cached_list` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `category_perms` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_reset_token` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES (1,0,1639056548,1639056548,0,0,0,0,0,NULL,'admin',0,'$argon2i$v=19$m=65536,t=16,p=1$ZUNHOWl1czhNUkFDWHY5Uw$xt0BA+hC6T67tqyxNNAmmVYtvwEXHexukwLxB7RKP2I',1,'','','',NULL,0,'',NULL,'','a:16:{s:14:\"interfaceSetup\";s:7:\"backend\";s:10:\"moduleData\";a:9:{s:28:\"dashboard/current_dashboard/\";s:40:\"bbd20be9cf1d214dbb55121afb6e32a455e9cfb9\";s:10:\"web_layout\";a:2:{s:8:\"function\";s:1:\"1\";s:8:\"language\";s:1:\"0\";}s:6:\"web_ts\";a:2:{s:8:\"function\";s:85:\"TYPO3\\CMS\\Tstemplate\\Controller\\TypoScriptTemplateInformationModuleFunctionController\";s:19:\"constant_editor_cat\";s:14:\"frontend login\";}s:10:\"FormEngine\";a:2:{i:0;a:9:{s:32:\"696addfecc296b326ff6e9f04c7ff3e1\";a:4:{i:0;s:4:\"Home\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:1;s:3:\"pid\";i:0;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"9b967901d6c9df7fbe10e9cd1eacc0fe\";a:4:{i:0;s:4:\"Home\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";a:1:{s:5:\"pages\";a:1:{s:16:\"sys_language_uid\";s:1:\"0\";}}s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:76:\"&edit%5Bpages%5D%5B1%5D=edit&overrideVals%5Bpages%5D%5Bsys_language_uid%5D=0\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:1;s:3:\"pid\";i:0;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"86205c5935270b8ee413592ec1b62292\";a:4:{i:0;s:8:\"NEW SITE\";i:1;a:5:{s:4:\"edit\";a:1:{s:12:\"sys_template\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Bsys_template%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:12:\"sys_template\";s:3:\"uid\";i:1;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"71e18511409318c1e53982f4f2ba8cb3\";a:4:{i:0;s:4:\"test\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";a:1:{s:10:\"tt_content\";a:3:{s:6:\"colPos\";s:1:\"0\";s:16:\"sys_language_uid\";s:1:\"0\";s:5:\"CType\";s:4:\"text\";}}s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:159:\"&edit%5Btt_content%5D%5B1%5D=edit&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0&defVals%5Btt_content%5D%5BCType%5D=text\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:1;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"c312013d83c1a6ad7fec8b36a37ba3c8\";a:4:{i:0;s:4:\"test\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:1;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"6fbcfbaaff2a7c867a22cb20e79408ff\";a:4:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";a:1:{s:10:\"tt_content\";a:3:{s:6:\"colPos\";s:1:\"0\";s:16:\"sys_language_uid\";s:1:\"0\";s:5:\"CType\";s:7:\"textpic\";}}s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:162:\"&edit%5Btt_content%5D%5B2%5D=edit&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0&defVals%5Btt_content%5D%5BCType%5D=textpic\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:2;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"1c5bc59673b226f94ab436b35d83a96a\";a:4:{i:0;s:591:\"Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:3;s:4:\"edit\";}}s:7:\"defVals\";a:1:{s:10:\"tt_content\";a:3:{s:6:\"colPos\";s:1:\"0\";s:16:\"sys_language_uid\";s:1:\"0\";s:5:\"CType\";s:4:\"text\";}}s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:159:\"&edit%5Btt_content%5D%5B3%5D=edit&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0&defVals%5Btt_content%5D%5BCType%5D=text\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:3;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"dc7208191dce8894c5b8718687ec84e6\";a:4:{i:0;s:591:\"Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:4;s:4:\"edit\";}}s:7:\"defVals\";a:1:{s:10:\"tt_content\";a:3:{s:6:\"colPos\";s:1:\"0\";s:16:\"sys_language_uid\";s:1:\"0\";s:5:\"CType\";s:4:\"text\";}}s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:159:\"&edit%5Btt_content%5D%5B4%5D=edit&defVals%5Btt_content%5D%5BcolPos%5D=0&defVals%5Btt_content%5D%5Bsys_language_uid%5D=0&defVals%5Btt_content%5D%5BCType%5D=text\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:4;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}s:32:\"deac478137dd48a97e299bd046412e21\";a:4:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:2;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}i:1;s:32:\"deac478137dd48a97e299bd046412e21\";}s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:8:\"web_list\";a:0:{}s:9:\"file_list\";a:0:{}s:16:\"browse_links.php\";a:1:{s:12:\"expandFolder\";s:3:\"1:/\";}s:16:\"opendocs::recent\";a:1:{s:32:\"deac478137dd48a97e299bd046412e21\";a:4:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:2;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}}}}s:19:\"thumbnailsByDefault\";i:1;s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:8:\"edit_RTE\";s:1:\"1\";s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"resizeTextareas\";i:1;s:25:\"resizeTextareas_MaxHeight\";i:500;s:24:\"resizeTextareas_Flexible\";i:0;s:4:\"lang\";s:0:\"\";s:19:\"firstLoginTimeStamp\";i:1639056571;s:15:\"moduleSessionID\";a:9:{s:28:\"dashboard/current_dashboard/\";s:40:\"51327ad90547593018021288e4a196a05b887d44\";s:10:\"web_layout\";s:40:\"51327ad90547593018021288e4a196a05b887d44\";s:6:\"web_ts\";s:40:\"51327ad90547593018021288e4a196a05b887d44\";s:10:\"FormEngine\";s:40:\"51327ad90547593018021288e4a196a05b887d44\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"51327ad90547593018021288e4a196a05b887d44\";s:8:\"web_list\";s:40:\"51327ad90547593018021288e4a196a05b887d44\";s:9:\"file_list\";s:40:\"51327ad90547593018021288e4a196a05b887d44\";s:16:\"browse_links.php\";s:40:\"51327ad90547593018021288e4a196a05b887d44\";s:16:\"opendocs::recent\";s:40:\"51327ad90547593018021288e4a196a05b887d44\";}s:10:\"modulemenu\";s:2:\"{}\";s:17:\"BackendComponents\";a:1:{s:6:\"States\";a:1:{s:8:\"Pagetree\";a:1:{s:9:\"stateHash\";a:1:{s:3:\"0_0\";s:1:\"1\";}}}}s:10:\"inlineView\";s:104:\"{\"tt_content\":{\"NEW61b20988c57ba658654552\":{\"sys_file_reference\":[1]},\"2\":{\"sys_file_reference\":[2,3]}}}\";}',NULL,NULL,1,'',0,NULL,1639056571,0,NULL,0,NULL,'');
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
INSERT INTO `cache_hash` VALUES (1,'d07b003d9fce07cd551ada22027bf881',2145909600,'a:3:{s:8:\"options.\";a:8:{s:15:\"enableBookmarks\";s:1:\"1\";s:10:\"file_list.\";a:4:{s:28:\"enableDisplayBigControlPanel\";s:10:\"selectable\";s:23:\"enableDisplayThumbnails\";s:10:\"selectable\";s:15:\"enableClipBoard\";s:10:\"selectable\";s:10:\"thumbnail.\";a:2:{s:5:\"width\";s:2:\"64\";s:6:\"height\";s:2:\"64\";}}s:9:\"pageTree.\";a:1:{s:31:\"doktypesToShowInNewPageDragArea\";s:21:\"1,6,4,7,3,254,255,199\";}s:12:\"contextMenu.\";a:1:{s:6:\"table.\";a:3:{s:6:\"pages.\";a:2:{s:12:\"disableItems\";s:0:\"\";s:5:\"tree.\";a:1:{s:12:\"disableItems\";s:0:\"\";}}s:9:\"sys_file.\";a:2:{s:12:\"disableItems\";s:0:\"\";s:5:\"tree.\";a:1:{s:12:\"disableItems\";s:0:\"\";}}s:15:\"sys_filemounts.\";a:2:{s:12:\"disableItems\";s:0:\"\";s:5:\"tree.\";a:1:{s:12:\"disableItems\";s:0:\"\";}}}}s:11:\"saveDocView\";s:1:\"1\";s:10:\"saveDocNew\";s:1:\"1\";s:11:\"saveDocNew.\";a:3:{s:5:\"pages\";s:1:\"0\";s:8:\"sys_file\";s:1:\"0\";s:17:\"sys_file_metadata\";s:1:\"0\";}s:14:\"disableDelete.\";a:1:{s:8:\"sys_file\";s:1:\"1\";}}s:9:\"admPanel.\";a:1:{s:7:\"enable.\";a:1:{s:3:\"all\";s:1:\"1\";}}s:12:\"TCAdefaults.\";a:1:{s:9:\"sys_note.\";a:2:{s:6:\"author\";s:0:\"\";s:5:\"email\";s:0:\"\";}}}'),(2,'95fd679b4c2e0087232eee3d1495afb1',2145909600,'a:2:{s:9:\"constants\";a:4:{s:7:\"styles.\";a:1:{s:8:\"content.\";a:1:{s:10:\"loginform.\";a:22:{s:3:\"pid\";s:1:\"0\";s:9:\"recursive\";s:1:\"0\";s:12:\"templateFile\";s:76:\"EXT:bootstrap_package/Resources/Private/Templates/Felogin/FrontendLogin.html\";s:14:\"feloginBaseURL\";s:0:\"\";s:10:\"dateFormat\";s:9:\"Y-m-d H:i\";s:22:\"showForgotPasswordLink\";s:1:\"0\";s:14:\"showPermaLogin\";s:1:\"0\";s:24:\"showLogoutFormAfterLogin\";s:1:\"0\";s:9:\"emailFrom\";s:0:\"\";s:13:\"emailFromName\";s:0:\"\";s:12:\"replyToEmail\";s:0:\"\";s:6:\"email.\";a:4:{s:14:\"layoutRootPath\";s:0:\"\";s:16:\"templateRootPath\";s:46:\"EXT:felogin/Resources/Private/Email/Templates/\";s:15:\"partialRootPath\";s:0:\"\";s:12:\"templateName\";s:16:\"PasswordRecovery\";}s:12:\"redirectMode\";s:0:\"\";s:19:\"redirectFirstMethod\";s:1:\"0\";s:17:\"redirectPageLogin\";s:1:\"0\";s:22:\"redirectPageLoginError\";s:1:\"0\";s:18:\"redirectPageLogout\";s:1:\"0\";s:15:\"redirectDisable\";s:1:\"0\";s:23:\"forgotLinkHashValidTime\";s:2:\"12\";s:20:\"newPasswordMinLength\";s:1:\"6\";s:7:\"domains\";s:0:\"\";s:43:\"exposeNonexistentUserInForgotPasswordDialog\";s:1:\"0\";}}}s:7:\"plugin.\";a:4:{s:34:\"bootstrap_package_contentelements.\";a:11:{s:5:\"view.\";a:3:{s:14:\"layoutRootPath\";s:64:\"EXT:bootstrap_package/Resources/Private/Layouts/ContentElements/\";s:15:\"partialRootPath\";s:65:\"EXT:bootstrap_package/Resources/Private/Partials/ContentElements/\";s:16:\"templateRootPath\";s:66:\"EXT:bootstrap_package/Resources/Private/Templates/ContentElements/\";}s:7:\"header.\";a:3:{s:17:\"defaultHeaderType\";s:1:\"2\";s:5:\"class\";s:14:\"element-header\";s:5:\"date.\";a:1:{s:6:\"format\";s:9:\"%B %e, %Y\";}}s:10:\"subheader.\";a:1:{s:5:\"class\";s:17:\"element-subheader\";}s:9:\"lightbox.\";a:3:{s:8:\"cssClass\";s:8:\"lightbox\";s:6:\"prefix\";s:14:\"lightbox-group\";s:6:\"image.\";a:2:{s:9:\"maxHeight\";s:4:\"1200\";s:8:\"maxWidth\";s:4:\"1200\";}}s:6:\"media.\";a:1:{s:17:\"additionalConfig.\";a:7:{s:8:\"autoplay\";s:1:\"0\";s:8:\"controls\";s:1:\"1\";s:4:\"loop\";s:1:\"0\";s:11:\"enablejsapi\";s:1:\"1\";s:8:\"showinfo\";s:1:\"0\";s:13:\"relatedVideos\";s:1:\"0\";s:14:\"modestbranding\";s:1:\"0\";}}s:8:\"gallery.\";a:1:{s:8:\"columns.\";a:6:{s:2:\"1.\";a:1:{s:5:\"class\";s:19:\"gallery-item-size-1\";}s:2:\"2.\";a:1:{s:5:\"class\";s:19:\"gallery-item-size-2\";}s:2:\"3.\";a:1:{s:5:\"class\";s:19:\"gallery-item-size-3\";}s:2:\"4.\";a:1:{s:5:\"class\";s:19:\"gallery-item-size-4\";}s:2:\"5.\";a:1:{s:5:\"class\";s:19:\"gallery-item-size-5\";}s:2:\"6.\";a:1:{s:5:\"class\";s:19:\"gallery-item-size-6\";}}}s:15:\"menu_thumbnail.\";a:2:{s:6:\"title.\";a:1:{s:4:\"crop\";s:3:\"100\";}s:9:\"subtitle.\";a:1:{s:4:\"crop\";s:2:\"80\";}}s:10:\"menu_card.\";a:4:{s:5:\"icon.\";a:3:{s:6:\"enable\";s:1:\"0\";s:6:\"height\";s:2:\"32\";s:5:\"width\";s:3:\"32c\";}s:6:\"title.\";a:1:{s:4:\"crop\";s:3:\"100\";}s:9:\"subtitle.\";a:1:{s:4:\"crop\";s:3:\"100\";}s:9:\"abstract.\";a:1:{s:4:\"crop\";s:3:\"250\";}}s:9:\"texticon.\";a:1:{s:5:\"icon.\";a:4:{s:8:\"default.\";a:2:{s:6:\"height\";s:2:\"32\";s:5:\"width\";s:2:\"32\";}s:7:\"medium.\";a:2:{s:6:\"height\";s:2:\"48\";s:5:\"width\";s:2:\"48\";}s:6:\"large.\";a:2:{s:6:\"height\";s:2:\"64\";s:5:\"width\";s:2:\"64\";}s:8:\"awesome.\";a:2:{s:6:\"height\";s:2:\"80\";s:5:\"width\";s:2:\"80\";}}}s:9:\"timeline.\";a:1:{s:5:\"date.\";a:1:{s:6:\"format\";s:17:\"%B %e, %Y - %H:%M\";}}s:8:\"uploads.\";a:1:{s:8:\"preview.\";a:2:{s:6:\"height\";s:4:\"100c\";s:5:\"width\";s:4:\"100c\";}}}s:18:\"bootstrap_package.\";a:2:{s:9:\"settings.\";a:3:{s:23:\"overrideParserVariables\";s:1:\"1\";s:16:\"cssSourceMapping\";s:1:\"0\";s:5:\"scss.\";a:38:{s:5:\"white\";s:7:\"#ffffff\";s:8:\"gray-100\";s:7:\"#f8f8f8\";s:8:\"gray-200\";s:7:\"#e9e9e9\";s:8:\"gray-300\";s:7:\"#dedede\";s:8:\"gray-400\";s:7:\"#cecece\";s:8:\"gray-500\";s:7:\"#ababab\";s:8:\"gray-600\";s:7:\"#6c6c6c\";s:8:\"gray-700\";s:7:\"#494949\";s:8:\"gray-800\";s:7:\"#313131\";s:8:\"gray-900\";s:7:\"#212121\";s:5:\"black\";s:7:\"#000000\";s:7:\"primary\";s:7:\"#2a9d8f\";s:9:\"secondary\";s:7:\"#e76f51\";s:8:\"tertiary\";s:7:\"#f4a261\";s:10:\"quaternary\";s:7:\"#e9c46a\";s:7:\"default\";s:7:\"#eaebec\";s:7:\"success\";s:7:\"#5cb85c\";s:4:\"info\";s:7:\"#319fc0\";s:7:\"warning\";s:7:\"#f0ad4e\";s:6:\"danger\";s:7:\"#d9534f\";s:7:\"lighter\";s:9:\"$gray-100\";s:5:\"light\";s:9:\"$gray-200\";s:4:\"dark\";s:9:\"$gray-800\";s:6:\"darker\";s:9:\"$gray-900\";s:18:\"min-contrast-ratio\";s:3:\"2.4\";s:7:\"body-bg\";s:6:\"$white\";s:10:\"body-color\";s:9:\"$gray-900\";s:10:\"link-color\";s:8:\"$primary\";s:15:\"link-decoration\";s:4:\"none\";s:21:\"link-shade-percentage\";s:3:\"20%\";s:16:\"link-hover-color\";s:48:\"shift-color($link-color, $link-shade-percentage)\";s:21:\"link-hover-decoration\";s:9:\"underline\";s:22:\"font-family-sans-serif\";s:32:\"\"#{$google-webfont}\", sans-serif\";s:21:\"font-family-monospace\";s:85:\"SFMono-Regular, Menlo, Monaco, Consolas, \"Liberation Mono\", \"Courier New\", monospace;\";s:14:\"enable-rounded\";s:4:\"true\";s:14:\"enable-shadows\";s:4:\"true\";s:16:\"enable-gradients\";s:5:\"false\";s:18:\"enable-transitions\";s:4:\"true\";}}s:5:\"view.\";a:3:{s:14:\"layoutRootPath\";s:48:\"EXT:bootstrap_package/Resources/Private/Layouts/\";s:15:\"partialRootPath\";s:49:\"EXT:bootstrap_package/Resources/Private/Partials/\";s:16:\"templateRootPath\";s:50:\"EXT:bootstrap_package/Resources/Private/Templates/\";}}s:25:\"bootstrap_package_blocks.\";a:1:{s:5:\"view.\";a:3:{s:14:\"layoutRootPath\";s:55:\"EXT:bootstrap_package/Resources/Private/Layouts/Blocks/\";s:15:\"partialRootPath\";s:56:\"EXT:bootstrap_package/Resources/Private/Partials/Blocks/\";s:16:\"templateRootPath\";s:57:\"EXT:bootstrap_package/Resources/Private/Templates/Blocks/\";}}s:7:\"tx_seo.\";a:2:{s:5:\"view.\";a:3:{s:16:\"templateRootPath\";s:36:\"EXT:seo/Resources/Private/Templates/\";s:15:\"partialRootPath\";s:35:\"EXT:seo/Resources/Private/Partials/\";s:14:\"layoutRootPath\";s:34:\"EXT:seo/Resources/Private/Layouts/\";}s:9:\"settings.\";a:1:{s:11:\"xmlSitemap.\";a:1:{s:9:\"sitemaps.\";a:1:{s:6:\"pages.\";a:2:{s:16:\"excludedDoktypes\";s:25:\"3, 4, 6, 7, 199, 254, 255\";s:15:\"additionalWhere\";s:36:\"no_index = 0 AND canonical_link = \'\'\";}}}}}}s:5:\"page.\";a:6:{s:5:\"logo.\";a:6:{s:4:\"file\";s:66:\"EXT:bootstrap_package/Resources/Public/Images/BootstrapPackage.svg\";s:12:\"fileInverted\";s:74:\"EXT:bootstrap_package/Resources/Public/Images/BootstrapPackageInverted.svg\";s:6:\"height\";s:2:\"52\";s:5:\"width\";s:3:\"180\";s:3:\"alt\";s:0:\"\";s:9:\"linktitle\";s:0:\"\";}s:8:\"favicon.\";a:1:{s:4:\"file\";s:56:\"EXT:bootstrap_package/Resources/Public/Icons/favicon.ico\";}s:6:\"theme.\";a:9:{s:11:\"googleFont.\";a:3:{s:6:\"enable\";s:1:\"1\";s:4:\"font\";s:15:\"Source Sans Pro\";s:6:\"weight\";s:11:\"300,400,700\";}s:11:\"navigation.\";a:4:{s:5:\"style\";s:7:\"default\";s:4:\"type\";s:0:\"\";s:5:\"icon.\";a:3:{s:6:\"enable\";s:1:\"1\";s:5:\"width\";s:2:\"20\";s:6:\"height\";s:2:\"20\";}s:9:\"dropdown.\";a:1:{s:5:\"icon.\";a:3:{s:6:\"enable\";s:1:\"1\";s:5:\"width\";s:2:\"16\";s:6:\"height\";s:2:\"16\";}}}s:14:\"subnavigation.\";a:1:{s:5:\"icon.\";a:3:{s:6:\"enable\";s:1:\"1\";s:5:\"width\";s:2:\"16\";s:6:\"height\";s:2:\"16\";}}s:11:\"breadcrumb.\";a:3:{s:6:\"enable\";s:1:\"1\";s:11:\"enableLevel\";s:1:\"2\";s:5:\"icon.\";a:3:{s:6:\"enable\";s:1:\"0\";s:5:\"width\";s:2:\"16\";s:6:\"height\";s:2:\"16\";}}s:5:\"meta.\";a:4:{s:6:\"enable\";s:1:\"1\";s:15:\"navigationValue\";s:0:\"\";s:14:\"navigationType\";s:4:\"list\";s:16:\"includeNotInMenu\";s:1:\"1\";}s:9:\"language.\";a:2:{s:6:\"enable\";s:1:\"1\";s:13:\"languageValue\";s:4:\"auto\";}s:12:\"socialmedia.\";a:2:{s:6:\"enable\";s:1:\"1\";s:9:\"channels.\";a:11:{s:9:\"facebook.\";a:2:{s:5:\"label\";s:8:\"Facebook\";s:3:\"url\";s:0:\"\";}s:8:\"twitter.\";a:2:{s:5:\"label\";s:7:\"Twitter\";s:3:\"url\";s:0:\"\";}s:10:\"instagram.\";a:2:{s:5:\"label\";s:9:\"Instagram\";s:3:\"url\";s:0:\"\";}s:7:\"github.\";a:2:{s:5:\"label\";s:6:\"GitHub\";s:3:\"url\";s:0:\"\";}s:11:\"googleplus.\";a:2:{s:5:\"label\";s:7:\"Google+\";s:3:\"url\";s:0:\"\";}s:9:\"linkedin.\";a:2:{s:5:\"label\";s:8:\"LinkedIn\";s:3:\"url\";s:0:\"\";}s:5:\"xing.\";a:2:{s:5:\"label\";s:4:\"Xing\";s:3:\"url\";s:0:\"\";}s:8:\"youtube.\";a:2:{s:5:\"label\";s:7:\"YouTube\";s:3:\"url\";s:0:\"\";}s:3:\"vk.\";a:2:{s:5:\"label\";s:2:\"VK\";s:3:\"url\";s:0:\"\";}s:6:\"vimeo.\";a:2:{s:5:\"label\";s:5:\"Vimeo\";s:3:\"url\";s:0:\"\";}s:4:\"rss.\";a:2:{s:5:\"label\";s:3:\"RSS\";s:3:\"url\";s:0:\"\";}}}s:10:\"copyright.\";a:2:{s:6:\"enable\";s:1:\"1\";s:4:\"text\";s:186:\"Running with <a href=\"http://www.typo3.org\" rel=\"noopener\" target=\"_blank\">TYPO3</a> and <a href=\"https://www.bootstrap-package.com\" rel=\"noopener\" target=\"_blank\">Bootstrap Package</a>.\";}s:14:\"cookieconsent.\";a:10:{s:6:\"enable\";s:1:\"1\";s:6:\"layout\";s:5:\"basic\";s:8:\"position\";s:6:\"bottom\";s:6:\"static\";s:1:\"0\";s:8:\"content.\";a:1:{s:4:\"href\";s:0:\"\";}s:9:\"revokable\";s:1:\"0\";s:8:\"location\";s:1:\"0\";s:4:\"law.\";a:2:{s:11:\"countryCode\";s:0:\"\";s:11:\"regionalLaw\";s:1:\"1\";}s:4:\"type\";s:4:\"info\";s:7:\"cookie.\";a:1:{s:10:\"expiryDays\";s:3:\"365\";}}}s:14:\"fluidtemplate.\";a:3:{s:14:\"layoutRootPath\";s:53:\"EXT:bootstrap_package/Resources/Private/Layouts/Page/\";s:15:\"partialRootPath\";s:54:\"EXT:bootstrap_package/Resources/Private/Partials/Page/\";s:16:\"templateRootPath\";s:55:\"EXT:bootstrap_package/Resources/Private/Templates/Page/\";}s:5:\"meta.\";a:6:{s:8:\"viewport\";s:52:\"width=device-width, initial-scale=1, minimum-scale=1\";s:6:\"robots\";s:12:\"index,follow\";s:28:\"apple-mobile-web-app-capable\";s:2:\"no\";s:10:\"compatible\";s:7:\"IE=edge\";s:6:\"google\";s:11:\"notranslate\";s:24:\"google-site-verification\";s:0:\"\";}s:9:\"tracking.\";a:1:{s:7:\"google.\";a:1:{s:10:\"trackingID\";s:0:\"\";}}}s:7:\"config.\";a:10:{s:8:\"no_cache\";s:1:\"0\";s:15:\"removeDefaultJS\";s:1:\"0\";s:10:\"compressJs\";s:1:\"1\";s:11:\"compressCss\";s:1:\"1\";s:13:\"concatenateJs\";s:1:\"1\";s:14:\"concatenateCss\";s:1:\"1\";s:8:\"admPanel\";s:1:\"1\";s:18:\"prefixLocalAnchors\";s:3:\"all\";s:13:\"headerComment\";s:90:\"Based on the TYPO3 Bootstrap Package by Benjamin Kott - https://www.bootstrap-package.com/\";s:16:\"sendCacheHeaders\";s:1:\"1\";}}s:5:\"setup\";a:15:{s:7:\"config.\";a:24:{s:19:\"pageTitleProviders.\";a:2:{s:7:\"record.\";a:1:{s:8:\"provider\";s:48:\"TYPO3\\CMS\\Core\\PageTitle\\RecordPageTitleProvider\";}s:4:\"seo.\";a:2:{s:8:\"provider\";s:49:\"TYPO3\\CMS\\Seo\\PageTitle\\SeoTitlePageTitleProvider\";s:6:\"before\";s:6:\"record\";}}s:12:\"absRefPrefix\";s:4:\"auto\";s:8:\"no_cache\";s:1:\"0\";s:14:\"pageTitleFirst\";s:1:\"1\";s:18:\"pageTitleSeparator\";s:1:\"-\";s:19:\"pageTitleSeparator.\";a:1:{s:10:\"noTrimWrap\";s:5:\"| | |\";}s:8:\"linkVars\";s:6:\"L(int)\";s:18:\"prefixLocalAnchors\";s:3:\"all\";s:7:\"doctype\";s:5:\"html5\";s:15:\"removeDefaultJS\";s:1:\"0\";s:8:\"admPanel\";s:1:\"1\";s:5:\"debug\";s:1:\"0\";s:16:\"sendCacheHeaders\";s:1:\"1\";s:12:\"index_enable\";s:1:\"1\";s:15:\"index_externals\";s:1:\"1\";s:14:\"index_metatags\";s:1:\"1\";s:13:\"headerComment\";s:90:\"Based on the TYPO3 Bootstrap Package by Benjamin Kott - https://www.bootstrap-package.com/\";s:20:\"sys_language_overlay\";s:1:\"1\";s:17:\"sys_language_mode\";s:16:\"content_fallback\";s:10:\"compressJs\";s:1:\"1\";s:11:\"compressCss\";s:1:\"1\";s:13:\"concatenateJs\";s:1:\"1\";s:14:\"concatenateCss\";s:1:\"1\";s:11:\"tx_extbase.\";a:3:{s:4:\"mvc.\";a:1:{s:48:\"throwPageNotFoundExceptionIfActionCantBeResolved\";s:1:\"0\";}s:12:\"persistence.\";a:2:{s:28:\"enableAutomaticCacheClearing\";s:1:\"1\";s:20:\"updateReferenceIndex\";s:1:\"0\";}s:9:\"features.\";a:2:{s:20:\"skipDefaultArguments\";s:1:\"0\";s:25:\"ignoreAllEnableFieldsInBe\";s:1:\"0\";}}}s:7:\"styles.\";a:1:{s:8:\"content.\";a:2:{s:3:\"get\";s:7:\"CONTENT\";s:4:\"get.\";a:2:{s:5:\"table\";s:10:\"tt_content\";s:7:\"select.\";a:2:{s:7:\"orderBy\";s:7:\"sorting\";s:5:\"where\";s:11:\"{#colPos}=0\";}}}}s:10:\"tt_content\";s:4:\"CASE\";s:11:\"tt_content.\";a:101:{s:4:\"key.\";a:1:{s:5:\"field\";s:5:\"CType\";}s:7:\"default\";s:4:\"TEXT\";s:8:\"default.\";a:4:{s:5:\"field\";s:5:\"CType\";s:16:\"htmlSpecialChars\";s:1:\"1\";s:4:\"wrap\";s:165:\"<p style=\"background-color: yellow; padding: 0.5em 1em;\"><strong>ERROR:</strong> Content Element with uid \"{field:uid}\" and type \"|\" has no rendering definition!</p>\";s:5:\"wrap.\";a:1:{s:10:\"insertData\";s:1:\"1\";}}s:4:\"list\";s:20:\"< lib.contentElement\";s:5:\"list.\";a:1:{s:12:\"templateName\";s:4:\"List\";}s:18:\"form_formframework\";s:20:\"< lib.contentElement\";s:19:\"form_formframework.\";a:3:{s:12:\"templateName\";s:7:\"Generic\";i:20;s:4:\"USER\";s:3:\"20.\";a:3:{s:8:\"userFunc\";s:37:\"TYPO3\\CMS\\Extbase\\Core\\Bootstrap->run\";s:13:\"extensionName\";s:4:\"Form\";s:10:\"pluginName\";s:13:\"Formframework\";}}s:13:\"felogin_login\";s:20:\"< lib.contentElement\";s:14:\"felogin_login.\";a:3:{s:12:\"templateName\";s:7:\"Generic\";i:20;s:4:\"USER\";s:3:\"20.\";a:3:{s:8:\"userFunc\";s:37:\"TYPO3\\CMS\\Extbase\\Core\\Bootstrap->run\";s:13:\"extensionName\";s:7:\"Felogin\";s:10:\"pluginName\";s:5:\"Login\";}}s:5:\"audio\";s:20:\"< lib.contentElement\";s:6:\"audio.\";a:2:{s:12:\"templateName\";s:5:\"Audio\";s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:6:\"assets\";}}}}s:7:\"bullets\";s:20:\"< lib.contentElement\";s:8:\"bullets.\";a:2:{s:12:\"templateName\";s:7:\"Bullets\";s:15:\"dataProcessing.\";a:4:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\SplitProcessor\";s:3:\"10.\";a:4:{s:3:\"if.\";a:2:{s:5:\"value\";s:1:\"2\";s:11:\"isLessThan.\";a:1:{s:5:\"field\";s:12:\"bullets_type\";}}s:9:\"fieldName\";s:8:\"bodytext\";s:18:\"removeEmptyEntries\";s:1:\"1\";s:2:\"as\";s:7:\"bullets\";}i:20;s:62:\"TYPO3\\CMS\\Frontend\\DataProcessing\\CommaSeparatedValueProcessor\";s:3:\"20.\";a:4:{s:9:\"fieldName\";s:8:\"bodytext\";s:3:\"if.\";a:2:{s:5:\"value\";s:1:\"2\";s:7:\"equals.\";a:1:{s:5:\"field\";s:12:\"bullets_type\";}}s:14:\"fieldDelimiter\";s:1:\"|\";s:2:\"as\";s:7:\"bullets\";}}}s:3:\"csv\";s:20:\"< lib.contentElement\";s:4:\"csv.\";a:2:{s:12:\"templateName\";s:3:\"Csv\";s:15:\"dataProcessing.\";a:2:{i:10;s:53:\"BK2K\\BootstrapPackage\\DataProcessing\\CsvFileProcessor\";s:3:\"10.\";a:4:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"media\";}s:15:\"fieldDelimiter.\";a:1:{s:5:\"char.\";a:2:{s:7:\"cObject\";s:4:\"TEXT\";s:8:\"cObject.\";a:1:{s:5:\"field\";s:15:\"table_delimiter\";}}}s:15:\"fieldEnclosure.\";a:1:{s:5:\"char.\";a:2:{s:7:\"cObject\";s:4:\"TEXT\";s:8:\"cObject.\";a:1:{s:5:\"field\";s:15:\"table_enclosure\";}}}s:15:\"maximumColumns.\";a:1:{s:5:\"field\";s:4:\"cols\";}}}}s:3:\"div\";s:20:\"< lib.contentElement\";s:4:\"div.\";a:1:{s:12:\"templateName\";s:3:\"Div\";}s:6:\"header\";s:20:\"< lib.contentElement\";s:7:\"header.\";a:1:{s:12:\"templateName\";s:6:\"Header\";}s:4:\"html\";s:20:\"< lib.contentElement\";s:5:\"html.\";a:1:{s:12:\"templateName\";s:4:\"Html\";}s:5:\"image\";s:20:\"< lib.contentElement\";s:6:\"image.\";a:2:{s:12:\"templateName\";s:5:\"Image\";s:15:\"dataProcessing.\";a:4:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:3:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"image\";}s:8:\"folders.\";a:1:{s:5:\"field\";s:11:\"file_folder\";}s:8:\"sorting.\";a:1:{s:5:\"field\";s:16:\"filelink_sorting\";}}i:20;s:56:\"BK2K\\BootstrapPackage\\DataProcessing\\FileFilterProcessor\";s:3:\"20.\";a:1:{s:14:\"predefinedList\";s:5:\"image\";}}}s:5:\"media\";s:20:\"< lib.contentElement\";s:6:\"media.\";a:2:{s:12:\"templateName\";s:5:\"Media\";s:15:\"dataProcessing.\";a:4:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:3:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:6:\"assets\";}s:8:\"folders.\";a:1:{s:5:\"field\";s:11:\"file_folder\";}s:8:\"sorting.\";a:1:{s:5:\"field\";s:16:\"filelink_sorting\";}}i:20;s:56:\"BK2K\\BootstrapPackage\\DataProcessing\\FileFilterProcessor\";s:3:\"20.\";a:1:{s:21:\"allowedFileExtensions\";s:14:\"youtube, vimeo\";}}}s:13:\"menu_abstract\";s:20:\"< lib.contentElement\";s:14:\"menu_abstract.\";a:2:{s:12:\"templateName\";s:12:\"MenuAbstract\";s:15:\"dataProcessing.\";a:4:{i:10;s:47:\"TYPO3\\CMS\\Frontend\\DataProcessing\\MenuProcessor\";s:3:\"10.\";a:3:{s:7:\"special\";s:9:\"directory\";s:8:\"special.\";a:1:{s:6:\"value.\";a:1:{s:5:\"field\";s:5:\"pages\";}}s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"media\";}}}}i:90;s:56:\"TYPO3\\CMS\\Frontend\\DataProcessing\\DatabaseQueryProcessor\";s:3:\"90.\";a:7:{s:3:\"if.\";a:1:{s:7:\"isTrue.\";a:1:{s:5:\"field\";s:20:\"accessibility_bypass\";}}s:5:\"table\";s:10:\"tt_content\";s:9:\"pidInList\";s:4:\"this\";s:7:\"orderBy\";s:7:\"sorting\";s:3:\"max\";s:1:\"1\";s:6:\"where.\";a:1:{s:8:\"dataWrap\";s:53:\"colPos = {field:colPos} AND sorting > {field:sorting}\";}s:2:\"as\";s:18:\"nextContentElement\";}}}s:24:\"menu_categorized_content\";s:20:\"< lib.contentElement\";s:25:\"menu_categorized_content.\";a:2:{s:12:\"templateName\";s:22:\"MenuCategorizedContent\";s:15:\"dataProcessing.\";a:4:{i:10;s:56:\"TYPO3\\CMS\\Frontend\\DataProcessing\\DatabaseQueryProcessor\";s:3:\"10.\";a:9:{s:5:\"table\";s:10:\"tt_content\";s:12:\"selectFields\";s:12:\"tt_content.*\";s:7:\"groupBy\";s:3:\"uid\";s:10:\"pidInList.\";a:1:{s:4:\"data\";s:12:\"leveluid : 0\";}s:9:\"recursive\";s:2:\"99\";s:5:\"join.\";a:2:{s:4:\"data\";s:25:\"field:selected_categories\";s:4:\"wrap\";s:120:\"sys_category_record_mm ON tt_content.uid = sys_category_record_mm.uid_foreign AND sys_category_record_mm.uid_local IN(|)\";}s:6:\"where.\";a:2:{s:4:\"data\";s:20:\"field:category_field\";s:4:\"wrap\";s:41:\"tablenames=\'tt_content\' and fieldname=\'|\'\";}s:2:\"as\";s:7:\"content\";s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"image\";}}}}i:90;s:56:\"TYPO3\\CMS\\Frontend\\DataProcessing\\DatabaseQueryProcessor\";s:3:\"90.\";a:7:{s:3:\"if.\";a:1:{s:7:\"isTrue.\";a:1:{s:5:\"field\";s:20:\"accessibility_bypass\";}}s:5:\"table\";s:10:\"tt_content\";s:9:\"pidInList\";s:4:\"this\";s:7:\"orderBy\";s:7:\"sorting\";s:3:\"max\";s:1:\"1\";s:6:\"where.\";a:1:{s:8:\"dataWrap\";s:53:\"colPos = {field:colPos} AND sorting > {field:sorting}\";}s:2:\"as\";s:18:\"nextContentElement\";}}}s:22:\"menu_categorized_pages\";s:20:\"< lib.contentElement\";s:23:\"menu_categorized_pages.\";a:2:{s:12:\"templateName\";s:20:\"MenuCategorizedPages\";s:15:\"dataProcessing.\";a:4:{i:10;s:47:\"TYPO3\\CMS\\Frontend\\DataProcessing\\MenuProcessor\";s:3:\"10.\";a:3:{s:7:\"special\";s:10:\"categories\";s:8:\"special.\";a:4:{s:6:\"value.\";a:1:{s:5:\"field\";s:19:\"selected_categories\";}s:9:\"relation.\";a:1:{s:5:\"field\";s:14:\"category_field\";}s:7:\"sorting\";s:5:\"title\";s:5:\"order\";s:3:\"asc\";}s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"media\";}}}}i:90;s:56:\"TYPO3\\CMS\\Frontend\\DataProcessing\\DatabaseQueryProcessor\";s:3:\"90.\";a:7:{s:3:\"if.\";a:1:{s:7:\"isTrue.\";a:1:{s:5:\"field\";s:20:\"accessibility_bypass\";}}s:5:\"table\";s:10:\"tt_content\";s:9:\"pidInList\";s:4:\"this\";s:7:\"orderBy\";s:7:\"sorting\";s:3:\"max\";s:1:\"1\";s:6:\"where.\";a:1:{s:8:\"dataWrap\";s:53:\"colPos = {field:colPos} AND sorting > {field:sorting}\";}s:2:\"as\";s:18:\"nextContentElement\";}}}s:10:\"menu_pages\";s:20:\"< lib.contentElement\";s:11:\"menu_pages.\";a:2:{s:12:\"templateName\";s:9:\"MenuPages\";s:15:\"dataProcessing.\";a:4:{i:10;s:47:\"TYPO3\\CMS\\Frontend\\DataProcessing\\MenuProcessor\";s:3:\"10.\";a:4:{s:7:\"special\";s:4:\"list\";s:8:\"special.\";a:1:{s:6:\"value.\";a:1:{s:5:\"field\";s:5:\"pages\";}}s:16:\"includeNotInMenu\";s:1:\"1\";s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"media\";}}}}i:90;s:56:\"TYPO3\\CMS\\Frontend\\DataProcessing\\DatabaseQueryProcessor\";s:3:\"90.\";a:7:{s:3:\"if.\";a:1:{s:7:\"isTrue.\";a:1:{s:5:\"field\";s:20:\"accessibility_bypass\";}}s:5:\"table\";s:10:\"tt_content\";s:9:\"pidInList\";s:4:\"this\";s:7:\"orderBy\";s:7:\"sorting\";s:3:\"max\";s:1:\"1\";s:6:\"where.\";a:1:{s:8:\"dataWrap\";s:53:\"colPos = {field:colPos} AND sorting > {field:sorting}\";}s:2:\"as\";s:18:\"nextContentElement\";}}}s:13:\"menu_subpages\";s:20:\"< lib.contentElement\";s:14:\"menu_subpages.\";a:2:{s:12:\"templateName\";s:12:\"MenuSubpages\";s:15:\"dataProcessing.\";a:4:{i:10;s:47:\"TYPO3\\CMS\\Frontend\\DataProcessing\\MenuProcessor\";s:3:\"10.\";a:3:{s:7:\"special\";s:9:\"directory\";s:8:\"special.\";a:1:{s:6:\"value.\";a:1:{s:5:\"field\";s:5:\"pages\";}}s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"media\";}}}}i:90;s:56:\"TYPO3\\CMS\\Frontend\\DataProcessing\\DatabaseQueryProcessor\";s:3:\"90.\";a:7:{s:3:\"if.\";a:1:{s:7:\"isTrue.\";a:1:{s:5:\"field\";s:20:\"accessibility_bypass\";}}s:5:\"table\";s:10:\"tt_content\";s:9:\"pidInList\";s:4:\"this\";s:7:\"orderBy\";s:7:\"sorting\";s:3:\"max\";s:1:\"1\";s:6:\"where.\";a:1:{s:8:\"dataWrap\";s:53:\"colPos = {field:colPos} AND sorting > {field:sorting}\";}s:2:\"as\";s:18:\"nextContentElement\";}}}s:21:\"menu_recently_updated\";s:20:\"< lib.contentElement\";s:22:\"menu_recently_updated.\";a:2:{s:12:\"templateName\";s:19:\"MenuRecentlyUpdated\";s:15:\"dataProcessing.\";a:4:{i:10;s:47:\"TYPO3\\CMS\\Frontend\\DataProcessing\\MenuProcessor\";s:3:\"10.\";a:3:{s:7:\"special\";s:7:\"updated\";s:8:\"special.\";a:3:{s:6:\"value.\";a:1:{s:5:\"field\";s:5:\"pages\";}s:6:\"maxAge\";s:9:\"3600*24*7\";s:20:\"excludeNoSearchPages\";s:1:\"1\";}s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"media\";}}}}i:90;s:56:\"TYPO3\\CMS\\Frontend\\DataProcessing\\DatabaseQueryProcessor\";s:3:\"90.\";a:7:{s:3:\"if.\";a:1:{s:7:\"isTrue.\";a:1:{s:5:\"field\";s:20:\"accessibility_bypass\";}}s:5:\"table\";s:10:\"tt_content\";s:9:\"pidInList\";s:4:\"this\";s:7:\"orderBy\";s:7:\"sorting\";s:3:\"max\";s:1:\"1\";s:6:\"where.\";a:1:{s:8:\"dataWrap\";s:53:\"colPos = {field:colPos} AND sorting > {field:sorting}\";}s:2:\"as\";s:18:\"nextContentElement\";}}}s:18:\"menu_related_pages\";s:20:\"< lib.contentElement\";s:19:\"menu_related_pages.\";a:2:{s:12:\"templateName\";s:16:\"MenuRelatedPages\";s:15:\"dataProcessing.\";a:4:{i:10;s:47:\"TYPO3\\CMS\\Frontend\\DataProcessing\\MenuProcessor\";s:3:\"10.\";a:3:{s:7:\"special\";s:8:\"keywords\";s:8:\"special.\";a:2:{s:6:\"value.\";a:1:{s:5:\"field\";s:5:\"pages\";}s:20:\"excludeNoSearchPages\";s:1:\"1\";}s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"media\";}}}}i:90;s:56:\"TYPO3\\CMS\\Frontend\\DataProcessing\\DatabaseQueryProcessor\";s:3:\"90.\";a:7:{s:3:\"if.\";a:1:{s:7:\"isTrue.\";a:1:{s:5:\"field\";s:20:\"accessibility_bypass\";}}s:5:\"table\";s:10:\"tt_content\";s:9:\"pidInList\";s:4:\"this\";s:7:\"orderBy\";s:7:\"sorting\";s:3:\"max\";s:1:\"1\";s:6:\"where.\";a:1:{s:8:\"dataWrap\";s:53:\"colPos = {field:colPos} AND sorting > {field:sorting}\";}s:2:\"as\";s:18:\"nextContentElement\";}}}s:12:\"menu_section\";s:20:\"< lib.contentElement\";s:13:\"menu_section.\";a:2:{s:12:\"templateName\";s:11:\"MenuSection\";s:15:\"dataProcessing.\";a:4:{i:10;s:47:\"TYPO3\\CMS\\Frontend\\DataProcessing\\MenuProcessor\";s:3:\"10.\";a:4:{s:7:\"special\";s:4:\"list\";s:8:\"special.\";a:1:{s:6:\"value.\";a:2:{s:5:\"field\";s:5:\"pages\";s:9:\"override.\";a:2:{s:4:\"data\";s:8:\"page:uid\";s:3:\"if.\";a:1:{s:8:\"isFalse.\";a:1:{s:5:\"field\";s:5:\"pages\";}}}}}s:16:\"includeNotInMenu\";s:1:\"1\";s:15:\"dataProcessing.\";a:4:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"media\";}}i:20;s:56:\"TYPO3\\CMS\\Frontend\\DataProcessing\\DatabaseQueryProcessor\";s:3:\"20.\";a:6:{s:5:\"table\";s:10:\"tt_content\";s:10:\"pidInList.\";a:1:{s:5:\"field\";s:3:\"uid\";}s:2:\"as\";s:7:\"content\";s:5:\"where\";s:16:\"sectionIndex = 1\";s:7:\"orderBy\";s:7:\"sorting\";s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"image\";}}}}}}i:90;s:56:\"TYPO3\\CMS\\Frontend\\DataProcessing\\DatabaseQueryProcessor\";s:3:\"90.\";a:7:{s:3:\"if.\";a:1:{s:7:\"isTrue.\";a:1:{s:5:\"field\";s:20:\"accessibility_bypass\";}}s:5:\"table\";s:10:\"tt_content\";s:9:\"pidInList\";s:4:\"this\";s:7:\"orderBy\";s:7:\"sorting\";s:3:\"max\";s:1:\"1\";s:6:\"where.\";a:1:{s:8:\"dataWrap\";s:53:\"colPos = {field:colPos} AND sorting > {field:sorting}\";}s:2:\"as\";s:18:\"nextContentElement\";}}}s:18:\"menu_section_pages\";s:20:\"< lib.contentElement\";s:19:\"menu_section_pages.\";a:2:{s:12:\"templateName\";s:16:\"MenuSectionPages\";s:15:\"dataProcessing.\";a:4:{i:10;s:47:\"TYPO3\\CMS\\Frontend\\DataProcessing\\MenuProcessor\";s:3:\"10.\";a:3:{s:7:\"special\";s:9:\"directory\";s:8:\"special.\";a:1:{s:6:\"value.\";a:1:{s:5:\"field\";s:5:\"pages\";}}s:15:\"dataProcessing.\";a:4:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"media\";}}i:20;s:56:\"TYPO3\\CMS\\Frontend\\DataProcessing\\DatabaseQueryProcessor\";s:3:\"20.\";a:6:{s:5:\"table\";s:10:\"tt_content\";s:10:\"pidInList.\";a:1:{s:5:\"field\";s:3:\"uid\";}s:2:\"as\";s:7:\"content\";s:5:\"where\";s:16:\"sectionIndex = 1\";s:7:\"orderBy\";s:7:\"sorting\";s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"image\";}}}}}}i:90;s:56:\"TYPO3\\CMS\\Frontend\\DataProcessing\\DatabaseQueryProcessor\";s:3:\"90.\";a:7:{s:3:\"if.\";a:1:{s:7:\"isTrue.\";a:1:{s:5:\"field\";s:20:\"accessibility_bypass\";}}s:5:\"table\";s:10:\"tt_content\";s:9:\"pidInList\";s:4:\"this\";s:7:\"orderBy\";s:7:\"sorting\";s:3:\"max\";s:1:\"1\";s:6:\"where.\";a:1:{s:8:\"dataWrap\";s:53:\"colPos = {field:colPos} AND sorting > {field:sorting}\";}s:2:\"as\";s:18:\"nextContentElement\";}}}s:12:\"menu_sitemap\";s:20:\"< lib.contentElement\";s:13:\"menu_sitemap.\";a:2:{s:12:\"templateName\";s:11:\"MenuSitemap\";s:15:\"dataProcessing.\";a:4:{i:10;s:47:\"TYPO3\\CMS\\Frontend\\DataProcessing\\MenuProcessor\";s:3:\"10.\";a:4:{s:7:\"special\";s:4:\"list\";s:8:\"special.\";a:1:{s:6:\"value.\";a:1:{s:5:\"field\";s:5:\"pages\";}}s:6:\"levels\";s:1:\"7\";s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"media\";}}}}i:90;s:56:\"TYPO3\\CMS\\Frontend\\DataProcessing\\DatabaseQueryProcessor\";s:3:\"90.\";a:7:{s:3:\"if.\";a:1:{s:7:\"isTrue.\";a:1:{s:5:\"field\";s:20:\"accessibility_bypass\";}}s:5:\"table\";s:10:\"tt_content\";s:9:\"pidInList\";s:4:\"this\";s:7:\"orderBy\";s:7:\"sorting\";s:3:\"max\";s:1:\"1\";s:6:\"where.\";a:1:{s:8:\"dataWrap\";s:53:\"colPos = {field:colPos} AND sorting > {field:sorting}\";}s:2:\"as\";s:18:\"nextContentElement\";}}}s:18:\"menu_sitemap_pages\";s:20:\"< lib.contentElement\";s:19:\"menu_sitemap_pages.\";a:2:{s:12:\"templateName\";s:16:\"MenuSitemapPages\";s:15:\"dataProcessing.\";a:4:{i:10;s:47:\"TYPO3\\CMS\\Frontend\\DataProcessing\\MenuProcessor\";s:3:\"10.\";a:4:{s:7:\"special\";s:9:\"directory\";s:8:\"special.\";a:1:{s:6:\"value.\";a:1:{s:5:\"field\";s:5:\"pages\";}}s:6:\"levels\";s:1:\"7\";s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"media\";}}}}i:90;s:56:\"TYPO3\\CMS\\Frontend\\DataProcessing\\DatabaseQueryProcessor\";s:3:\"90.\";a:7:{s:3:\"if.\";a:1:{s:7:\"isTrue.\";a:1:{s:5:\"field\";s:20:\"accessibility_bypass\";}}s:5:\"table\";s:10:\"tt_content\";s:9:\"pidInList\";s:4:\"this\";s:7:\"orderBy\";s:7:\"sorting\";s:3:\"max\";s:1:\"1\";s:6:\"where.\";a:1:{s:8:\"dataWrap\";s:53:\"colPos = {field:colPos} AND sorting > {field:sorting}\";}s:2:\"as\";s:18:\"nextContentElement\";}}}s:5:\"quote\";s:20:\"< lib.contentElement\";s:6:\"quote.\";a:1:{s:12:\"templateName\";s:5:\"Quote\";}s:8:\"shortcut\";s:20:\"< lib.contentElement\";s:9:\"shortcut.\";a:2:{s:12:\"templateName\";s:8:\"Shortcut\";s:10:\"variables.\";a:2:{s:9:\"shortcuts\";s:7:\"RECORDS\";s:10:\"shortcuts.\";a:2:{s:7:\"source.\";a:1:{s:5:\"field\";s:7:\"records\";}s:6:\"tables\";s:10:\"tt_content\";}}}s:12:\"social_links\";s:20:\"< lib.contentElement\";s:13:\"social_links.\";a:2:{s:12:\"templateName\";s:11:\"SocialLinks\";s:15:\"dataProcessing.\";a:2:{i:1;s:55:\"BK2K\\BootstrapPackage\\DataProcessing\\ConstantsProcessor\";s:2:\"1.\";a:2:{s:2:\"as\";s:11:\"socialmedia\";s:3:\"key\";s:22:\"page.theme.socialmedia\";}}}s:5:\"table\";s:20:\"< lib.contentElement\";s:6:\"table.\";a:2:{s:12:\"templateName\";s:5:\"Table\";s:15:\"dataProcessing.\";a:2:{i:10;s:62:\"TYPO3\\CMS\\Frontend\\DataProcessing\\CommaSeparatedValueProcessor\";s:3:\"10.\";a:4:{s:9:\"fieldName\";s:8:\"bodytext\";s:15:\"fieldDelimiter.\";a:1:{s:5:\"char.\";a:2:{s:7:\"cObject\";s:4:\"TEXT\";s:8:\"cObject.\";a:1:{s:5:\"field\";s:15:\"table_delimiter\";}}}s:15:\"fieldEnclosure.\";a:1:{s:5:\"char.\";a:2:{s:7:\"cObject\";s:4:\"TEXT\";s:8:\"cObject.\";a:1:{s:5:\"field\";s:15:\"table_enclosure\";}}}s:2:\"as\";s:5:\"table\";}}}s:4:\"text\";s:20:\"< lib.contentElement\";s:5:\"text.\";a:1:{s:12:\"templateName\";s:4:\"Text\";}s:10:\"textcolumn\";s:20:\"< lib.contentElement\";s:11:\"textcolumn.\";a:1:{s:12:\"templateName\";s:10:\"Textcolumn\";}s:10:\"textteaser\";s:20:\"< lib.contentElement\";s:11:\"textteaser.\";a:1:{s:12:\"templateName\";s:10:\"Textteaser\";}s:7:\"textpic\";s:20:\"< lib.contentElement\";s:8:\"textpic.\";a:3:{s:12:\"templateName\";s:4:\"TEXT\";s:13:\"templateName.\";a:1:{s:8:\"stdWrap.\";a:2:{s:7:\"cObject\";s:4:\"CASE\";s:8:\"cObject.\";a:13:{s:4:\"key.\";a:1:{s:5:\"field\";s:11:\"imageorient\";}i:8;s:4:\"TEXT\";s:2:\"8.\";a:1:{s:5:\"value\";s:12:\"TextpicBelow\";}i:25;s:4:\"TEXT\";s:3:\"25.\";a:1:{s:5:\"value\";s:12:\"TextpicRight\";}i:26;s:4:\"TEXT\";s:3:\"26.\";a:1:{s:5:\"value\";s:11:\"TextpicLeft\";}i:125;s:4:\"TEXT\";s:4:\"125.\";a:1:{s:5:\"value\";s:20:\"TextpicCenteredRight\";}i:126;s:4:\"TEXT\";s:4:\"126.\";a:1:{s:5:\"value\";s:19:\"TextpicCenteredLeft\";}s:7:\"default\";s:4:\"TEXT\";s:8:\"default.\";a:1:{s:5:\"value\";s:12:\"TextpicAbove\";}}}}s:15:\"dataProcessing.\";a:4:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:3:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"image\";}s:8:\"folders.\";a:1:{s:5:\"field\";s:11:\"file_folder\";}s:8:\"sorting.\";a:1:{s:5:\"field\";s:16:\"filelink_sorting\";}}i:20;s:56:\"BK2K\\BootstrapPackage\\DataProcessing\\FileFilterProcessor\";s:3:\"20.\";a:1:{s:14:\"predefinedList\";s:5:\"image\";}}}s:9:\"textmedia\";s:20:\"< lib.contentElement\";s:10:\"textmedia.\";a:3:{s:12:\"templateName\";s:4:\"TEXT\";s:13:\"templateName.\";a:1:{s:8:\"stdWrap.\";a:2:{s:7:\"cObject\";s:4:\"CASE\";s:8:\"cObject.\";a:13:{s:4:\"key.\";a:1:{s:5:\"field\";s:11:\"imageorient\";}i:8;s:4:\"TEXT\";s:2:\"8.\";a:1:{s:5:\"value\";s:14:\"TextmediaBelow\";}i:25;s:4:\"TEXT\";s:3:\"25.\";a:1:{s:5:\"value\";s:14:\"TextmediaRight\";}i:26;s:4:\"TEXT\";s:3:\"26.\";a:1:{s:5:\"value\";s:13:\"TextmediaLeft\";}i:125;s:4:\"TEXT\";s:4:\"125.\";a:1:{s:5:\"value\";s:22:\"TextmediaCenteredRight\";}i:126;s:4:\"TEXT\";s:4:\"126.\";a:1:{s:5:\"value\";s:21:\"TextmediaCenteredLeft\";}s:7:\"default\";s:4:\"TEXT\";s:8:\"default.\";a:1:{s:5:\"value\";s:14:\"TextmediaAbove\";}}}}s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:6:\"assets\";}}}}s:7:\"uploads\";s:20:\"< lib.contentElement\";s:8:\"uploads.\";a:2:{s:12:\"templateName\";s:7:\"Uploads\";s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:3:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"media\";}s:12:\"collections.\";a:1:{s:5:\"field\";s:16:\"file_collections\";}s:8:\"sorting.\";a:2:{s:5:\"field\";s:16:\"filelink_sorting\";s:10:\"direction.\";a:1:{s:5:\"field\";s:26:\"filelink_sorting_direction\";}}}}}s:9:\"accordion\";s:20:\"< lib.contentElement\";s:10:\"accordion.\";a:2:{s:12:\"templateName\";s:9:\"Accordion\";s:15:\"dataProcessing.\";a:3:{i:10;s:54:\"BK2K\\BootstrapPackage\\DataProcessing\\FlexFormProcessor\";i:20;s:56:\"TYPO3\\CMS\\Frontend\\DataProcessing\\DatabaseQueryProcessor\";s:3:\"20.\";a:5:{s:5:\"table\";s:34:\"tx_bootstrappackage_accordion_item\";s:10:\"pidInList.\";a:1:{s:5:\"field\";s:3:\"pid\";}s:6:\"where.\";a:3:{s:4:\"data\";s:9:\"field:uid\";s:6:\"intval\";s:1:\"1\";s:4:\"wrap\";s:12:\"tt_content=|\";}s:7:\"orderBy\";s:7:\"sorting\";s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"media\";}}}}}}s:10:\"card_group\";s:20:\"< lib.contentElement\";s:11:\"card_group.\";a:2:{s:12:\"templateName\";s:9:\"CardGroup\";s:15:\"dataProcessing.\";a:3:{i:10;s:54:\"BK2K\\BootstrapPackage\\DataProcessing\\FlexFormProcessor\";i:20;s:56:\"TYPO3\\CMS\\Frontend\\DataProcessing\\DatabaseQueryProcessor\";s:3:\"20.\";a:5:{s:5:\"table\";s:35:\"tx_bootstrappackage_card_group_item\";s:10:\"pidInList.\";a:1:{s:5:\"field\";s:3:\"pid\";}s:6:\"where.\";a:3:{s:4:\"data\";s:9:\"field:uid\";s:6:\"intval\";s:1:\"1\";s:4:\"wrap\";s:12:\"tt_content=|\";}s:7:\"orderBy\";s:7:\"sorting\";s:15:\"dataProcessing.\";a:4:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:2:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"image\";}s:2:\"as\";s:5:\"image\";}i:1628754217;s:55:\"BK2K\\BootstrapPackage\\DataProcessing\\IconsDataProcessor\";s:11:\"1628754217.\";a:4:{s:8:\"iconSet.\";a:1:{s:5:\"field\";s:13:\"link_icon_set\";}s:15:\"iconIdentifier.\";a:1:{s:5:\"field\";s:20:\"link_icon_identifier\";}s:17:\"iconFileFieldName\";s:9:\"link_icon\";s:2:\"as\";s:8:\"linkIcon\";}}}}}s:8:\"carousel\";s:20:\"< lib.contentElement\";s:9:\"carousel.\";a:2:{s:12:\"templateName\";s:8:\"Carousel\";s:15:\"dataProcessing.\";a:3:{i:10;s:54:\"BK2K\\BootstrapPackage\\DataProcessing\\FlexFormProcessor\";i:20;s:56:\"TYPO3\\CMS\\Frontend\\DataProcessing\\DatabaseQueryProcessor\";s:3:\"20.\";a:5:{s:5:\"table\";s:33:\"tx_bootstrappackage_carousel_item\";s:10:\"pidInList.\";a:1:{s:5:\"field\";s:3:\"pid\";}s:6:\"where.\";a:3:{s:4:\"data\";s:9:\"field:uid\";s:6:\"intval\";s:1:\"1\";s:4:\"wrap\";s:12:\"tt_content=|\";}s:7:\"orderBy\";s:7:\"sorting\";s:15:\"dataProcessing.\";a:6:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:2:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:16:\"background_image\";}s:2:\"as\";s:15:\"backgroundImage\";}i:20;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"20.\";a:2:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"image\";}s:2:\"as\";s:6:\"images\";}i:1532633187;s:54:\"BK2K\\BootstrapPackage\\DataProcessing\\FlexFormProcessor\";s:11:\"1532633187.\";a:1:{s:9:\"fieldName\";s:24:\"background_image_options\";}}}}}s:14:\"carousel_small\";s:20:\"< lib.contentElement\";s:15:\"carousel_small.\";a:2:{s:12:\"templateName\";s:13:\"CarouselSmall\";s:15:\"dataProcessing.\";a:3:{i:10;s:54:\"BK2K\\BootstrapPackage\\DataProcessing\\FlexFormProcessor\";i:20;s:56:\"TYPO3\\CMS\\Frontend\\DataProcessing\\DatabaseQueryProcessor\";s:3:\"20.\";a:5:{s:5:\"table\";s:33:\"tx_bootstrappackage_carousel_item\";s:10:\"pidInList.\";a:1:{s:5:\"field\";s:3:\"pid\";}s:6:\"where.\";a:3:{s:4:\"data\";s:9:\"field:uid\";s:6:\"intval\";s:1:\"1\";s:4:\"wrap\";s:12:\"tt_content=|\";}s:7:\"orderBy\";s:7:\"sorting\";s:15:\"dataProcessing.\";a:6:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:2:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:16:\"background_image\";}s:2:\"as\";s:15:\"backgroundImage\";}i:20;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"20.\";a:2:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"image\";}s:2:\"as\";s:6:\"images\";}i:1532633187;s:54:\"BK2K\\BootstrapPackage\\DataProcessing\\FlexFormProcessor\";s:11:\"1532633187.\";a:1:{s:9:\"fieldName\";s:24:\"background_image_options\";}}}}}s:19:\"carousel_fullscreen\";s:20:\"< lib.contentElement\";s:20:\"carousel_fullscreen.\";a:2:{s:12:\"templateName\";s:18:\"CarouselFullscreen\";s:15:\"dataProcessing.\";a:3:{i:10;s:54:\"BK2K\\BootstrapPackage\\DataProcessing\\FlexFormProcessor\";i:20;s:56:\"TYPO3\\CMS\\Frontend\\DataProcessing\\DatabaseQueryProcessor\";s:3:\"20.\";a:5:{s:5:\"table\";s:33:\"tx_bootstrappackage_carousel_item\";s:10:\"pidInList.\";a:1:{s:5:\"field\";s:3:\"pid\";}s:6:\"where.\";a:3:{s:4:\"data\";s:9:\"field:uid\";s:6:\"intval\";s:1:\"1\";s:4:\"wrap\";s:12:\"tt_content=|\";}s:7:\"orderBy\";s:7:\"sorting\";s:15:\"dataProcessing.\";a:6:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:2:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:16:\"background_image\";}s:2:\"as\";s:15:\"backgroundImage\";}i:20;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"20.\";a:2:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"image\";}s:2:\"as\";s:6:\"images\";}i:1532633187;s:54:\"BK2K\\BootstrapPackage\\DataProcessing\\FlexFormProcessor\";s:11:\"1532633187.\";a:1:{s:9:\"fieldName\";s:24:\"background_image_options\";}}}}}s:14:\"external_media\";s:20:\"< lib.contentElement\";s:15:\"external_media.\";a:1:{s:12:\"templateName\";s:13:\"ExternalMedia\";}s:7:\"gallery\";s:20:\"< lib.contentElement\";s:8:\"gallery.\";a:2:{s:12:\"templateName\";s:7:\"Gallery\";s:15:\"dataProcessing.\";a:4:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:3:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"image\";}s:8:\"folders.\";a:1:{s:5:\"field\";s:11:\"file_folder\";}s:8:\"sorting.\";a:1:{s:5:\"field\";s:16:\"filelink_sorting\";}}i:20;s:56:\"BK2K\\BootstrapPackage\\DataProcessing\\FileFilterProcessor\";s:3:\"20.\";a:1:{s:14:\"predefinedList\";s:5:\"image\";}}}s:10:\"icon_group\";s:20:\"< lib.contentElement\";s:11:\"icon_group.\";a:2:{s:12:\"templateName\";s:9:\"IconGroup\";s:15:\"dataProcessing.\";a:3:{i:10;s:54:\"BK2K\\BootstrapPackage\\DataProcessing\\FlexFormProcessor\";i:20;s:56:\"TYPO3\\CMS\\Frontend\\DataProcessing\\DatabaseQueryProcessor\";s:3:\"20.\";a:5:{s:5:\"table\";s:35:\"tx_bootstrappackage_icon_group_item\";s:10:\"pidInList.\";a:1:{s:5:\"field\";s:3:\"pid\";}s:6:\"where.\";a:3:{s:4:\"data\";s:9:\"field:uid\";s:6:\"intval\";s:1:\"1\";s:4:\"wrap\";s:12:\"tt_content=|\";}s:7:\"orderBy\";s:7:\"sorting\";s:15:\"dataProcessing.\";a:2:{i:1628754217;s:55:\"BK2K\\BootstrapPackage\\DataProcessing\\IconsDataProcessor\";s:11:\"1628754217.\";a:4:{s:8:\"iconSet.\";a:1:{s:5:\"field\";s:8:\"icon_set\";}s:15:\"iconIdentifier.\";a:1:{s:5:\"field\";s:15:\"icon_identifier\";}s:17:\"iconFileFieldName\";s:9:\"icon_file\";s:2:\"as\";s:4:\"icon\";}}}}}s:9:\"listgroup\";s:20:\"< lib.contentElement\";s:10:\"listgroup.\";a:2:{s:12:\"templateName\";s:9:\"ListGroup\";s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\SplitProcessor\";s:3:\"10.\";a:3:{s:9:\"fieldName\";s:8:\"bodytext\";s:18:\"removeEmptyEntries\";s:1:\"1\";s:2:\"as\";s:5:\"items\";}}}s:5:\"panel\";s:20:\"< lib.contentElement\";s:6:\"panel.\";a:1:{s:12:\"templateName\";s:5:\"Panel\";}s:3:\"tab\";s:20:\"< lib.contentElement\";s:4:\"tab.\";a:2:{s:12:\"templateName\";s:3:\"Tab\";s:15:\"dataProcessing.\";a:3:{i:10;s:54:\"BK2K\\BootstrapPackage\\DataProcessing\\FlexFormProcessor\";i:20;s:56:\"TYPO3\\CMS\\Frontend\\DataProcessing\\DatabaseQueryProcessor\";s:3:\"20.\";a:5:{s:5:\"table\";s:28:\"tx_bootstrappackage_tab_item\";s:10:\"pidInList.\";a:1:{s:5:\"field\";s:3:\"pid\";}s:6:\"where.\";a:3:{s:4:\"data\";s:9:\"field:uid\";s:6:\"intval\";s:1:\"1\";s:4:\"wrap\";s:12:\"tt_content=|\";}s:7:\"orderBy\";s:7:\"sorting\";s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"media\";}}}}}}s:8:\"texticon\";s:20:\"< lib.contentElement\";s:9:\"texticon.\";a:2:{s:12:\"templateName\";s:8:\"Texticon\";s:15:\"dataProcessing.\";a:2:{i:1628754217;s:55:\"BK2K\\BootstrapPackage\\DataProcessing\\IconsDataProcessor\";s:11:\"1628754217.\";a:4:{s:8:\"iconSet.\";a:1:{s:5:\"field\";s:8:\"icon_set\";}s:15:\"iconIdentifier.\";a:1:{s:5:\"field\";s:4:\"icon\";}s:17:\"iconFileFieldName\";s:9:\"icon_file\";s:2:\"as\";s:4:\"icon\";}}}s:8:\"timeline\";s:20:\"< lib.contentElement\";s:9:\"timeline.\";a:2:{s:12:\"templateName\";s:8:\"Timeline\";s:15:\"dataProcessing.\";a:2:{i:10;s:56:\"TYPO3\\CMS\\Frontend\\DataProcessing\\DatabaseQueryProcessor\";s:3:\"10.\";a:5:{s:5:\"table\";s:33:\"tx_bootstrappackage_timeline_item\";s:10:\"pidInList.\";a:1:{s:5:\"field\";s:3:\"pid\";}s:6:\"where.\";a:3:{s:4:\"data\";s:9:\"field:uid\";s:6:\"intval\";s:1:\"1\";s:4:\"wrap\";s:12:\"tt_content=|\";}s:8:\"orderBy.\";a:1:{s:8:\"stdWrap.\";a:2:{s:7:\"cObject\";s:4:\"TEXT\";s:8:\"cObject.\";a:2:{s:4:\"data\";s:28:\"flexform:pi_flexform:sorting\";s:8:\"ifEmpty.\";a:2:{s:7:\"cObject\";s:4:\"TEXT\";s:8:\"cObject.\";a:2:{s:6:\"value.\";a:1:{s:7:\"current\";s:1:\"1\";}s:7:\"ifEmpty\";s:9:\"date desc\";}}}}}s:15:\"dataProcessing.\";a:4:{i:20;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"20.\";a:2:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:5:\"image\";}s:2:\"as\";s:5:\"image\";}i:1628754217;s:55:\"BK2K\\BootstrapPackage\\DataProcessing\\IconsDataProcessor\";s:11:\"1628754217.\";a:4:{s:8:\"iconSet.\";a:1:{s:5:\"field\";s:8:\"icon_set\";}s:15:\"iconIdentifier.\";a:1:{s:5:\"field\";s:15:\"icon_identifier\";}s:17:\"iconFileFieldName\";s:9:\"icon_file\";s:2:\"as\";s:4:\"icon\";}}}}}s:13:\"menu_card_dir\";s:20:\"< lib.contentElement\";s:14:\"menu_card_dir.\";a:2:{s:12:\"templateName\";s:11:\"MenuCardDir\";s:15:\"dataProcessing.\";a:5:{i:10;s:54:\"BK2K\\BootstrapPackage\\DataProcessing\\FlexFormProcessor\";i:20;s:47:\"TYPO3\\CMS\\Frontend\\DataProcessing\\MenuProcessor\";s:3:\"20.\";a:3:{s:7:\"special\";s:9:\"directory\";s:8:\"special.\";a:1:{s:6:\"value.\";a:1:{s:5:\"field\";s:5:\"pages\";}}s:15:\"dataProcessing.\";a:4:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:2:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:9:\"thumbnail\";}s:3:\"if.\";a:1:{s:6:\"isTrue\";s:70:\"{$plugin.bootstrap_package_contentelements.menu_card.thumbnail.enable}\";}}i:1628754217;s:55:\"BK2K\\BootstrapPackage\\DataProcessing\\IconsDataProcessor\";s:11:\"1628754217.\";a:5:{s:8:\"iconSet.\";a:1:{s:5:\"field\";s:12:\"nav_icon_set\";}s:15:\"iconIdentifier.\";a:1:{s:5:\"field\";s:19:\"nav_icon_identifier\";}s:17:\"iconFileFieldName\";s:8:\"nav_icon\";s:2:\"as\";s:4:\"icon\";s:3:\"if.\";a:1:{s:6:\"isTrue\";s:1:\"0\";}}}}i:90;s:56:\"TYPO3\\CMS\\Frontend\\DataProcessing\\DatabaseQueryProcessor\";s:3:\"90.\";a:7:{s:3:\"if.\";a:1:{s:7:\"isTrue.\";a:1:{s:5:\"field\";s:20:\"accessibility_bypass\";}}s:5:\"table\";s:10:\"tt_content\";s:9:\"pidInList\";s:4:\"this\";s:7:\"orderBy\";s:7:\"sorting\";s:3:\"max\";s:1:\"1\";s:6:\"where.\";a:1:{s:8:\"dataWrap\";s:53:\"colPos = {field:colPos} AND sorting > {field:sorting}\";}s:2:\"as\";s:18:\"nextContentElement\";}}}s:14:\"menu_card_list\";s:20:\"< lib.contentElement\";s:15:\"menu_card_list.\";a:2:{s:12:\"templateName\";s:12:\"MenuCardList\";s:15:\"dataProcessing.\";a:5:{i:10;s:54:\"BK2K\\BootstrapPackage\\DataProcessing\\FlexFormProcessor\";i:20;s:47:\"TYPO3\\CMS\\Frontend\\DataProcessing\\MenuProcessor\";s:3:\"20.\";a:4:{s:7:\"special\";s:4:\"list\";s:8:\"special.\";a:1:{s:6:\"value.\";a:1:{s:5:\"field\";s:5:\"pages\";}}s:16:\"includeNotInMenu\";s:1:\"1\";s:15:\"dataProcessing.\";a:4:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:2:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:9:\"thumbnail\";}s:3:\"if.\";a:1:{s:6:\"isTrue\";s:70:\"{$plugin.bootstrap_package_contentelements.menu_card.thumbnail.enable}\";}}i:1628754217;s:55:\"BK2K\\BootstrapPackage\\DataProcessing\\IconsDataProcessor\";s:11:\"1628754217.\";a:5:{s:8:\"iconSet.\";a:1:{s:5:\"field\";s:12:\"nav_icon_set\";}s:15:\"iconIdentifier.\";a:1:{s:5:\"field\";s:19:\"nav_icon_identifier\";}s:17:\"iconFileFieldName\";s:8:\"nav_icon\";s:2:\"as\";s:4:\"icon\";s:3:\"if.\";a:1:{s:6:\"isTrue\";s:1:\"0\";}}}}i:90;s:56:\"TYPO3\\CMS\\Frontend\\DataProcessing\\DatabaseQueryProcessor\";s:3:\"90.\";a:7:{s:3:\"if.\";a:1:{s:7:\"isTrue.\";a:1:{s:5:\"field\";s:20:\"accessibility_bypass\";}}s:5:\"table\";s:10:\"tt_content\";s:9:\"pidInList\";s:4:\"this\";s:7:\"orderBy\";s:7:\"sorting\";s:3:\"max\";s:1:\"1\";s:6:\"where.\";a:1:{s:8:\"dataWrap\";s:53:\"colPos = {field:colPos} AND sorting > {field:sorting}\";}s:2:\"as\";s:18:\"nextContentElement\";}}}s:18:\"menu_thumbnail_dir\";s:20:\"< lib.contentElement\";s:19:\"menu_thumbnail_dir.\";a:2:{s:12:\"templateName\";s:16:\"MenuThumbnailDir\";s:15:\"dataProcessing.\";a:5:{i:10;s:54:\"BK2K\\BootstrapPackage\\DataProcessing\\FlexFormProcessor\";i:20;s:47:\"TYPO3\\CMS\\Frontend\\DataProcessing\\MenuProcessor\";s:3:\"20.\";a:3:{s:7:\"special\";s:9:\"directory\";s:8:\"special.\";a:1:{s:6:\"value.\";a:1:{s:5:\"field\";s:5:\"pages\";}}s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:9:\"thumbnail\";}}}}i:90;s:56:\"TYPO3\\CMS\\Frontend\\DataProcessing\\DatabaseQueryProcessor\";s:3:\"90.\";a:7:{s:3:\"if.\";a:1:{s:7:\"isTrue.\";a:1:{s:5:\"field\";s:20:\"accessibility_bypass\";}}s:5:\"table\";s:10:\"tt_content\";s:9:\"pidInList\";s:4:\"this\";s:7:\"orderBy\";s:7:\"sorting\";s:3:\"max\";s:1:\"1\";s:6:\"where.\";a:1:{s:8:\"dataWrap\";s:53:\"colPos = {field:colPos} AND sorting > {field:sorting}\";}s:2:\"as\";s:18:\"nextContentElement\";}}}s:19:\"menu_thumbnail_list\";s:20:\"< lib.contentElement\";s:20:\"menu_thumbnail_list.\";a:2:{s:12:\"templateName\";s:17:\"MenuThumbnailList\";s:15:\"dataProcessing.\";a:5:{i:10;s:54:\"BK2K\\BootstrapPackage\\DataProcessing\\FlexFormProcessor\";i:20;s:47:\"TYPO3\\CMS\\Frontend\\DataProcessing\\MenuProcessor\";s:3:\"20.\";a:4:{s:7:\"special\";s:4:\"list\";s:8:\"special.\";a:1:{s:6:\"value.\";a:1:{s:5:\"field\";s:5:\"pages\";}}s:16:\"includeNotInMenu\";s:1:\"1\";s:15:\"dataProcessing.\";a:2:{i:10;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:3:\"10.\";a:1:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:9:\"thumbnail\";}}}}i:90;s:56:\"TYPO3\\CMS\\Frontend\\DataProcessing\\DatabaseQueryProcessor\";s:3:\"90.\";a:7:{s:3:\"if.\";a:1:{s:7:\"isTrue.\";a:1:{s:5:\"field\";s:20:\"accessibility_bypass\";}}s:5:\"table\";s:10:\"tt_content\";s:9:\"pidInList\";s:4:\"this\";s:7:\"orderBy\";s:7:\"sorting\";s:3:\"max\";s:1:\"1\";s:6:\"where.\";a:1:{s:8:\"dataWrap\";s:53:\"colPos = {field:colPos} AND sorting > {field:sorting}\";}s:2:\"as\";s:18:\"nextContentElement\";}}}}s:7:\"module.\";a:4:{s:8:\"tx_form.\";a:2:{s:9:\"settings.\";a:1:{s:19:\"yamlConfigurations.\";a:2:{i:10;s:42:\"EXT:form/Configuration/Yaml/FormSetup.yaml\";i:110;s:51:\"EXT:bootstrap_package/Configuration/Form/Setup.yaml\";}}s:5:\"view.\";a:3:{s:18:\"templateRootPaths.\";a:1:{i:10;s:45:\"EXT:form/Resources/Private/Backend/Templates/\";}s:17:\"partialRootPaths.\";a:1:{i:10;s:44:\"EXT:form/Resources/Private/Backend/Partials/\";}s:16:\"layoutRootPaths.\";a:1:{i:10;s:43:\"EXT:form/Resources/Private/Backend/Layouts/\";}}}s:9:\"tx_belog.\";a:1:{s:9:\"settings.\";a:3:{s:29:\"selectableNumberOfLogEntries.\";a:7:{i:20;s:2:\"20\";i:50;s:2:\"50\";i:100;s:3:\"100\";i:200;s:3:\"200\";i:500;s:3:\"500\";i:1000;s:4:\"1000\";i:1000000;s:3:\"any\";}s:21:\"selectableTimeFrames.\";a:8:{i:0;s:8:\"thisWeek\";i:1;s:8:\"lastWeek\";i:2;s:9:\"last7Days\";i:10;s:9:\"thisMonth\";i:11;s:9:\"lastMonth\";i:12;s:10:\"last31Days\";i:20;s:7:\"noLimit\";i:30;s:11:\"userDefined\";}s:18:\"selectableActions.\";a:7:{i:0;s:3:\"any\";i:1;s:14:\"actionDatabase\";i:2;s:10:\"actionFile\";i:3;s:11:\"actionCache\";i:254;s:14:\"actionSettings\";i:255;s:11:\"actionLogin\";i:-1;s:12:\"actionErrors\";}}}s:10:\"tx_beuser.\";a:2:{s:12:\"persistence.\";a:1:{s:10:\"storagePid\";s:1:\"0\";}s:9:\"settings.\";a:1:{s:5:\"dummy\";s:3:\"foo\";}}s:20:\"tx_extensionmanager.\";a:1:{s:9:\"features.\";a:1:{s:20:\"skipDefaultArguments\";s:1:\"0\";}}}s:7:\"plugin.\";a:5:{s:17:\"tx_felogin_login.\";a:1:{s:9:\"settings.\";a:10:{s:14:\"showPermaLogin\";s:1:\"0\";s:10:\"dateFormat\";s:9:\"Y-m-d H:i\";s:10:\"email_from\";s:0:\"\";s:14:\"email_fromName\";s:0:\"\";s:6:\"email.\";a:4:{s:12:\"templateName\";s:16:\"PasswordRecovery\";s:16:\"layoutRootPaths.\";a:1:{i:20;s:0:\"\";}s:18:\"templateRootPaths.\";a:1:{i:20;s:46:\"EXT:felogin/Resources/Private/Email/Templates/\";}s:17:\"partialRootPaths.\";a:1:{i:20;s:0:\"\";}}s:7:\"replyTo\";s:0:\"\";s:43:\"exposeNonexistentUserInForgotPasswordDialog\";s:1:\"0\";s:23:\"forgotLinkHashValidTime\";s:2:\"12\";s:20:\"newPasswordMinLength\";s:1:\"6\";s:19:\"passwordValidators.\";a:2:{i:10;s:56:\"TYPO3\\CMS\\Extbase\\Validation\\Validator\\NotEmptyValidator\";s:3:\"20.\";a:2:{s:9:\"className\";s:60:\"TYPO3\\CMS\\Extbase\\Validation\\Validator\\StringLengthValidator\";s:8:\"options.\";a:1:{s:7:\"minimum\";s:1:\"6\";}}}}}s:8:\"tx_form.\";a:3:{s:9:\"settings.\";a:1:{s:19:\"yamlConfigurations.\";a:2:{i:110;s:51:\"EXT:bootstrap_package/Configuration/Form/Setup.yaml\";i:10;s:42:\"EXT:form/Configuration/Yaml/FormSetup.yaml\";}}s:5:\"view.\";a:3:{s:18:\"templateRootPaths.\";a:1:{i:0;s:46:\"EXT:form/Resources/Private/Frontend/Templates/\";}s:17:\"partialRootPaths.\";a:1:{i:0;s:45:\"EXT:form/Resources/Private/Frontend/Partials/\";}s:16:\"layoutRootPaths.\";a:1:{i:0;s:44:\"EXT:form/Resources/Private/Frontend/Layouts/\";}}s:4:\"mvc.\";a:1:{s:39:\"callDefaultActionIfActionCantBeResolved\";s:1:\"1\";}}s:15:\"tx_felogin_pi1.\";a:14:{s:22:\"wrapContentInBaseClass\";s:1:\"0\";s:23:\"welcomeMessage_stdWrap.\";a:1:{s:4:\"wrap\";s:8:\"<p>|</p>\";}s:22:\"logoutMessage_stdWrap.\";a:1:{s:4:\"wrap\";s:8:\"<p>|</p>\";}s:21:\"errorMessage_stdWrap.\";a:1:{s:4:\"wrap\";s:28:\"<p class=\"text-danger\">|</p>\";}s:23:\"successMessage_stdWrap.\";a:1:{s:4:\"wrap\";s:29:\"<p class=\"text-success\">|</p>\";}s:22:\"cookieWarning_stdWrap.\";a:1:{s:4:\"wrap\";s:29:\"<p class=\"text-warning\">|</p>\";}s:22:\"forgotMessage_stdWrap.\";a:1:{s:4:\"wrap\";s:8:\"<p>|</p>\";}s:27:\"forgotErrorMessage_stdWrap.\";a:1:{s:4:\"wrap\";s:28:\"<p class=\"text-danger\">|</p>\";}s:43:\"forgotResetMessageEmailSentMessage_stdWrap.\";a:1:{s:4:\"wrap\";s:29:\"<p class=\"text-success\">|</p>\";}s:38:\"changePasswordNotValidMessage_stdWrap.\";a:1:{s:4:\"wrap\";s:28:\"<p class=\"text-danger\">|</p>\";}s:38:\"changePasswordTooShortMessage_stdWrap.\";a:1:{s:4:\"wrap\";s:28:\"<p class=\"text-danger\">|</p>\";}s:38:\"changePasswordNotEqualMessage_stdWrap.\";a:1:{s:4:\"wrap\";s:28:\"<p class=\"text-danger\">|</p>\";}s:30:\"changePasswordMessage_stdWrap.\";a:1:{s:4:\"wrap\";s:8:\"<p>|</p>\";}s:34:\"changePasswordDoneMessage_stdWrap.\";a:1:{s:4:\"wrap\";s:29:\"<p class=\"text-success\">|</p>\";}}s:7:\"tx_seo.\";a:2:{s:5:\"view.\";a:3:{s:18:\"templateRootPaths.\";a:4:{i:0;s:46:\"EXT:seo/Resources/Private/Templates/XmlSitemap\";i:10;s:36:\"EXT:seo/Resources/Private/Templates/\";i:20;s:54:\"EXT:bootstrap_package/Resources/Private/Templates/Seo/\";i:21;s:54:\"EXT:bootstrap_package/Resources/Private/Templates/Seo/\";}s:17:\"partialRootPaths.\";a:4:{i:0;s:45:\"EXT:seo/Resources/Private/Partials/XmlSitemap\";i:10;s:35:\"EXT:seo/Resources/Private/Partials/\";i:20;s:53:\"EXT:bootstrap_package/Resources/Private/Partials/Seo/\";i:21;s:53:\"EXT:bootstrap_package/Resources/Private/Partials/Seo/\";}s:16:\"layoutRootPaths.\";a:4:{i:0;s:44:\"EXT:seo/Resources/Private/Layouts/XmlSitemap\";i:10;s:34:\"EXT:seo/Resources/Private/Layouts/\";i:20;s:52:\"EXT:bootstrap_package/Resources/Private/Layouts/Seo/\";i:21;s:52:\"EXT:bootstrap_package/Resources/Private/Layouts/Seo/\";}}s:7:\"config.\";a:1:{s:11:\"xmlSitemap.\";a:1:{s:9:\"sitemaps.\";a:1:{s:6:\"pages.\";a:2:{s:8:\"provider\";s:52:\"TYPO3\\CMS\\Seo\\XmlSitemap\\PagesXmlSitemapDataProvider\";s:7:\"config.\";a:2:{s:16:\"excludedDoktypes\";s:25:\"3, 4, 6, 7, 199, 254, 255\";s:15:\"additionalWhere\";s:36:\"no_index = 0 AND canonical_link = \'\'\";}}}}}}s:20:\"tx_bootstrappackage.\";a:1:{s:9:\"settings.\";a:2:{s:23:\"overrideParserVariables\";s:1:\"1\";s:16:\"cssSourceMapping\";s:1:\"0\";}}}s:4:\"lib.\";a:12:{s:14:\"contentElement\";s:13:\"FLUIDTEMPLATE\";s:15:\"contentElement.\";a:7:{s:12:\"templateName\";s:7:\"Default\";s:18:\"templateRootPaths.\";a:2:{i:0;s:66:\"EXT:bootstrap_package/Resources/Private/Templates/ContentElements/\";i:10;s:66:\"EXT:bootstrap_package/Resources/Private/Templates/ContentElements/\";}s:17:\"partialRootPaths.\";a:2:{i:0;s:65:\"EXT:bootstrap_package/Resources/Private/Partials/ContentElements/\";i:10;s:65:\"EXT:bootstrap_package/Resources/Private/Partials/ContentElements/\";}s:16:\"layoutRootPaths.\";a:2:{i:0;s:64:\"EXT:bootstrap_package/Resources/Private/Layouts/ContentElements/\";i:10;s:64:\"EXT:bootstrap_package/Resources/Private/Layouts/ContentElements/\";}s:15:\"dataProcessing.\";a:4:{i:1509614342;s:48:\"TYPO3\\CMS\\Frontend\\DataProcessing\\FilesProcessor\";s:11:\"1509614342.\";a:2:{s:11:\"references.\";a:1:{s:9:\"fieldName\";s:16:\"background_image\";}s:2:\"as\";s:15:\"backgroundImage\";}i:1532626753;s:54:\"BK2K\\BootstrapPackage\\DataProcessing\\FlexFormProcessor\";s:11:\"1532626753.\";a:1:{s:9:\"fieldName\";s:24:\"background_image_options\";}}s:10:\"variables.\";a:2:{s:13:\"backendlayout\";s:4:\"TEXT\";s:14:\"backendlayout.\";a:3:{s:4:\"data\";s:10:\"pagelayout\";s:12:\"replacement.\";a:1:{s:3:\"10.\";a:2:{s:6:\"search\";s:8:\"pagets__\";s:7:\"replace\";s:0:\"\";}}s:7:\"ifEmpty\";s:7:\"default\";}}s:9:\"settings.\";a:11:{s:7:\"header.\";a:3:{s:17:\"defaultHeaderType\";s:1:\"2\";s:5:\"class\";s:14:\"element-header\";s:5:\"date.\";a:1:{s:6:\"format\";s:9:\"%B %e, %Y\";}}s:10:\"subheader.\";a:1:{s:5:\"class\";s:17:\"element-subheader\";}s:9:\"lightbox.\";a:3:{s:8:\"cssClass\";s:8:\"lightbox\";s:6:\"prefix\";s:14:\"lightbox-group\";s:6:\"image.\";a:2:{s:9:\"maxHeight\";s:4:\"1200\";s:8:\"maxWidth\";s:4:\"1200\";}}s:6:\"media.\";a:1:{s:17:\"additionalConfig.\";a:7:{s:8:\"autoplay\";s:1:\"0\";s:8:\"controls\";s:1:\"1\";s:4:\"loop\";s:1:\"0\";s:11:\"enablejsapi\";s:1:\"1\";s:8:\"showinfo\";s:1:\"0\";s:13:\"relatedVideos\";s:1:\"0\";s:14:\"modestbranding\";s:1:\"0\";}}s:8:\"gallery.\";a:1:{s:8:\"columns.\";a:6:{s:2:\"1.\";a:1:{s:5:\"class\";s:19:\"gallery-item-size-1\";}s:2:\"2.\";a:3:{s:5:\"class\";s:19:\"gallery-item-size-2\";s:11:\"multiplier.\";a:6:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";s:5:\"small\";s:3:\"0.5\";s:10:\"extrasmall\";s:3:\"0.5\";}s:8:\"gutters.\";a:6:{s:7:\"default\";s:1:\"8\";s:6:\"xlarge\";s:1:\"8\";s:5:\"large\";s:1:\"8\";s:6:\"medium\";s:1:\"8\";s:5:\"small\";s:1:\"8\";s:10:\"extrasmall\";s:1:\"8\";}}s:2:\"3.\";a:3:{s:5:\"class\";s:19:\"gallery-item-size-3\";s:11:\"multiplier.\";a:6:{s:7:\"default\";s:6:\"0.3333\";s:6:\"xlarge\";s:6:\"0.3333\";s:5:\"large\";s:6:\"0.3333\";s:6:\"medium\";s:6:\"0.3333\";s:5:\"small\";s:6:\"0.3333\";s:10:\"extrasmall\";s:6:\"0.3333\";}s:8:\"gutters.\";a:6:{s:7:\"default\";s:2:\"16\";s:6:\"xlarge\";s:2:\"16\";s:5:\"large\";s:2:\"16\";s:6:\"medium\";s:2:\"16\";s:5:\"small\";s:2:\"16\";s:10:\"extrasmall\";s:2:\"16\";}}s:2:\"4.\";a:3:{s:5:\"class\";s:19:\"gallery-item-size-4\";s:11:\"multiplier.\";a:6:{s:7:\"default\";s:4:\"0.25\";s:6:\"xlarge\";s:4:\"0.25\";s:5:\"large\";s:4:\"0.25\";s:6:\"medium\";s:3:\"0.5\";s:5:\"small\";s:3:\"0.5\";s:10:\"extrasmall\";s:3:\"0.5\";}s:8:\"gutters.\";a:6:{s:7:\"default\";s:2:\"24\";s:6:\"xlarge\";s:2:\"24\";s:5:\"large\";s:2:\"24\";s:6:\"medium\";s:1:\"8\";s:5:\"small\";s:1:\"8\";s:10:\"extrasmall\";s:1:\"8\";}}s:2:\"5.\";a:3:{s:5:\"class\";s:19:\"gallery-item-size-5\";s:11:\"multiplier.\";a:6:{s:7:\"default\";s:3:\"0.2\";s:6:\"xlarge\";s:3:\"0.2\";s:5:\"large\";s:3:\"0.2\";s:6:\"medium\";s:6:\"0.3333\";s:5:\"small\";s:6:\"0.3333\";s:10:\"extrasmall\";s:3:\"0.5\";}s:8:\"gutters.\";a:6:{s:7:\"default\";s:2:\"32\";s:6:\"xlarge\";s:2:\"32\";s:5:\"large\";s:2:\"32\";s:6:\"medium\";s:2:\"16\";s:5:\"small\";s:2:\"16\";s:10:\"extrasmall\";s:1:\"8\";}}s:2:\"6.\";a:3:{s:5:\"class\";s:19:\"gallery-item-size-6\";s:11:\"multiplier.\";a:6:{s:7:\"default\";s:6:\"0.1666\";s:6:\"xlarge\";s:7:\"0.16666\";s:5:\"large\";s:7:\"0.16666\";s:6:\"medium\";s:6:\"0.3333\";s:5:\"small\";s:6:\"0.3333\";s:10:\"extrasmall\";s:3:\"0.5\";}s:8:\"gutters.\";a:6:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";s:6:\"medium\";s:2:\"16\";s:5:\"small\";s:2:\"16\";s:10:\"extrasmall\";s:1:\"8\";}}}}s:17:\"responsiveimages.\";a:3:{s:9:\"variants.\";a:6:{s:8:\"default.\";a:2:{s:10:\"breakpoint\";s:4:\"1400\";s:5:\"width\";s:4:\"1280\";}s:7:\"xlarge.\";a:2:{s:10:\"breakpoint\";s:4:\"1200\";s:5:\"width\";s:4:\"1100\";}s:6:\"large.\";a:2:{s:10:\"breakpoint\";s:3:\"992\";s:5:\"width\";s:3:\"920\";}s:7:\"medium.\";a:2:{s:10:\"breakpoint\";s:3:\"768\";s:5:\"width\";s:3:\"680\";}s:6:\"small.\";a:2:{s:10:\"breakpoint\";s:3:\"576\";s:5:\"width\";s:3:\"500\";}s:11:\"extrasmall.\";a:2:{s:10:\"breakpoint\";s:5:\"unset\";s:5:\"width\";s:3:\"374\";}}s:14:\"backendlayout.\";a:11:{s:10:\"2_columns.\";a:2:{s:2:\"0.\";a:2:{s:11:\"multiplier.\";a:3:{s:7:\"default\";s:4:\"0.75\";s:6:\"xlarge\";s:4:\"0.75\";s:5:\"large\";s:4:\"0.75\";}s:8:\"gutters.\";a:3:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";}}s:2:\"2.\";a:2:{s:11:\"multiplier.\";a:3:{s:7:\"default\";s:4:\"0.25\";s:6:\"xlarge\";s:4:\"0.25\";s:5:\"large\";s:4:\"0.25\";}s:8:\"gutters.\";a:3:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";}}}s:16:\"2_columns_25_75.\";a:2:{s:2:\"0.\";a:2:{s:11:\"multiplier.\";a:3:{s:7:\"default\";s:4:\"0.75\";s:6:\"xlarge\";s:4:\"0.75\";s:5:\"large\";s:4:\"0.75\";}s:8:\"gutters.\";a:3:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";}}s:2:\"1.\";a:2:{s:11:\"multiplier.\";a:3:{s:7:\"default\";s:4:\"0.25\";s:6:\"xlarge\";s:4:\"0.25\";s:5:\"large\";s:4:\"0.25\";}s:8:\"gutters.\";a:3:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";}}}s:16:\"2_columns_50_50.\";a:2:{s:2:\"0.\";a:2:{s:11:\"multiplier.\";a:3:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";}s:8:\"gutters.\";a:3:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";}}s:2:\"2.\";a:2:{s:11:\"multiplier.\";a:3:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";}s:8:\"gutters.\";a:3:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";}}}s:19:\"subnavigation_left.\";a:1:{s:2:\"0.\";a:2:{s:11:\"multiplier.\";a:3:{s:7:\"default\";s:4:\"0.75\";s:6:\"xlarge\";s:4:\"0.75\";s:5:\"large\";s:4:\"0.75\";}s:8:\"gutters.\";a:3:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";}}}s:23:\"2_columns_offset_right.\";a:2:{s:2:\"0.\";a:2:{s:11:\"multiplier.\";a:3:{s:7:\"default\";s:6:\"0.6666\";s:6:\"xlarge\";s:6:\"0.6666\";s:5:\"large\";s:6:\"0.6666\";}s:8:\"gutters.\";a:3:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";}}s:2:\"2.\";a:2:{s:11:\"multiplier.\";a:3:{s:7:\"default\";s:4:\"0.25\";s:6:\"xlarge\";s:4:\"0.25\";s:5:\"large\";s:4:\"0.25\";}s:8:\"gutters.\";a:3:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";}}}s:10:\"3_columns.\";a:3:{s:2:\"0.\";a:2:{s:11:\"multiplier.\";a:3:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";}s:8:\"gutters.\";a:3:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";}}s:2:\"1.\";a:2:{s:11:\"multiplier.\";a:3:{s:7:\"default\";s:4:\"0.25\";s:6:\"xlarge\";s:4:\"0.25\";s:5:\"large\";s:4:\"0.25\";}s:8:\"gutters.\";a:3:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";}}s:2:\"2.\";a:2:{s:11:\"multiplier.\";a:3:{s:7:\"default\";s:4:\"0.25\";s:6:\"xlarge\";s:4:\"0.25\";s:5:\"large\";s:4:\"0.25\";}s:8:\"gutters.\";a:3:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";}}}s:16:\"special_feature.\";a:8:{s:3:\"30.\";a:2:{s:11:\"multiplier.\";a:5:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";s:5:\"small\";s:3:\"0.5\";}s:8:\"gutters.\";a:5:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";s:6:\"medium\";s:2:\"40\";s:5:\"small\";s:2:\"40\";}}s:3:\"31.\";a:2:{s:11:\"multiplier.\";a:5:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";s:5:\"small\";s:3:\"0.5\";}s:8:\"gutters.\";a:5:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";s:6:\"medium\";s:2:\"40\";s:5:\"small\";s:2:\"40\";}}s:3:\"32.\";a:2:{s:11:\"multiplier.\";a:5:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";s:5:\"small\";s:3:\"0.5\";}s:8:\"gutters.\";a:5:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";s:6:\"medium\";s:2:\"40\";s:5:\"small\";s:2:\"40\";}}s:3:\"33.\";a:2:{s:11:\"multiplier.\";a:5:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";s:5:\"small\";s:3:\"0.5\";}s:8:\"gutters.\";a:5:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";s:6:\"medium\";s:2:\"40\";s:5:\"small\";s:2:\"40\";}}s:3:\"34.\";a:2:{s:11:\"multiplier.\";a:5:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";s:5:\"small\";s:3:\"0.5\";}s:8:\"gutters.\";a:5:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";s:6:\"medium\";s:2:\"40\";s:5:\"small\";s:2:\"40\";}}s:3:\"35.\";a:2:{s:11:\"multiplier.\";a:5:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";s:5:\"small\";s:3:\"0.5\";}s:8:\"gutters.\";a:5:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";s:6:\"medium\";s:2:\"40\";s:5:\"small\";s:2:\"40\";}}s:3:\"36.\";a:2:{s:11:\"multiplier.\";a:5:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";s:5:\"small\";s:3:\"0.5\";}s:8:\"gutters.\";a:5:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";s:6:\"medium\";s:2:\"40\";s:5:\"small\";s:2:\"40\";}}s:3:\"37.\";a:2:{s:11:\"multiplier.\";a:5:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";s:5:\"small\";s:3:\"0.5\";}s:8:\"gutters.\";a:5:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";s:6:\"medium\";s:2:\"40\";s:5:\"small\";s:2:\"40\";}}}s:14:\"special_start.\";a:3:{s:3:\"20.\";a:2:{s:11:\"multiplier.\";a:4:{s:7:\"default\";s:6:\"0.3333\";s:6:\"xlarge\";s:6:\"0.3333\";s:5:\"large\";s:6:\"0.3333\";s:6:\"medium\";s:6:\"0.3333\";}s:8:\"gutters.\";a:4:{s:7:\"default\";s:2:\"80\";s:6:\"xlarge\";s:2:\"80\";s:5:\"large\";s:2:\"80\";s:6:\"medium\";s:2:\"80\";}}s:3:\"21.\";a:2:{s:11:\"multiplier.\";a:4:{s:7:\"default\";s:6:\"0.3333\";s:6:\"xlarge\";s:6:\"0.3333\";s:5:\"large\";s:6:\"0.3333\";s:6:\"medium\";s:6:\"0.3333\";}s:8:\"gutters.\";a:4:{s:7:\"default\";s:2:\"80\";s:6:\"xlarge\";s:2:\"80\";s:5:\"large\";s:2:\"80\";s:6:\"medium\";s:2:\"80\";}}s:3:\"22.\";a:2:{s:11:\"multiplier.\";a:4:{s:7:\"default\";s:6:\"0.3333\";s:6:\"xlarge\";s:6:\"0.3333\";s:5:\"large\";s:6:\"0.3333\";s:6:\"medium\";s:6:\"0.3333\";}s:8:\"gutters.\";a:4:{s:7:\"default\";s:2:\"80\";s:6:\"xlarge\";s:2:\"80\";s:5:\"large\";s:2:\"80\";s:6:\"medium\";s:2:\"80\";}}}s:29:\"subnavigation_left_2_columns.\";a:2:{s:2:\"0.\";a:2:{s:11:\"multiplier.\";a:3:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";}s:8:\"gutters.\";a:3:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";}}s:2:\"1.\";a:2:{s:11:\"multiplier.\";a:3:{s:7:\"default\";s:4:\"0.25\";s:6:\"xlarge\";s:4:\"0.25\";s:5:\"large\";s:4:\"0.25\";}s:8:\"gutters.\";a:3:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";}}}s:20:\"subnavigation_right.\";a:1:{s:2:\"0.\";a:2:{s:11:\"multiplier.\";a:3:{s:7:\"default\";s:4:\"0.75\";s:6:\"xlarge\";s:4:\"0.75\";s:5:\"large\";s:4:\"0.75\";}s:8:\"gutters.\";a:3:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";}}}s:30:\"subnavigation_right_2_columns.\";a:2:{s:2:\"0.\";a:2:{s:11:\"multiplier.\";a:3:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";}s:8:\"gutters.\";a:3:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";}}s:2:\"2.\";a:2:{s:11:\"multiplier.\";a:3:{s:7:\"default\";s:4:\"0.25\";s:6:\"xlarge\";s:4:\"0.25\";s:5:\"large\";s:4:\"0.25\";}s:8:\"gutters.\";a:3:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";}}}}s:16:\"contentelements.\";a:13:{s:8:\"textpic.\";a:4:{s:14:\"centered_left.\";a:2:{s:11:\"multiplier.\";a:4:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";}s:8:\"gutters.\";a:4:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";s:6:\"medium\";s:2:\"40\";}}s:15:\"centered_right.\";a:2:{s:11:\"multiplier.\";a:4:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";}s:8:\"gutters.\";a:4:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";s:6:\"medium\";s:2:\"40\";}}s:5:\"left.\";a:2:{s:11:\"multiplier.\";a:4:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";}s:8:\"gutters.\";a:4:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";s:6:\"medium\";s:2:\"40\";}}s:6:\"right.\";a:2:{s:11:\"multiplier.\";a:4:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";}s:8:\"gutters.\";a:4:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";s:6:\"medium\";s:2:\"40\";}}}s:10:\"textmedia.\";a:4:{s:14:\"centered_left.\";a:2:{s:11:\"multiplier.\";a:4:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";}s:8:\"gutters.\";a:4:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";s:6:\"medium\";s:2:\"40\";}}s:15:\"centered_right.\";a:2:{s:11:\"multiplier.\";a:4:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";}s:8:\"gutters.\";a:4:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";s:6:\"medium\";s:2:\"40\";}}s:5:\"left.\";a:2:{s:11:\"multiplier.\";a:4:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";}s:8:\"gutters.\";a:4:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";s:6:\"medium\";s:2:\"40\";}}s:6:\"right.\";a:2:{s:11:\"multiplier.\";a:4:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";}s:8:\"gutters.\";a:4:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";s:6:\"medium\";s:2:\"40\";}}}s:10:\"accordion.\";a:4:{s:5:\"left.\";a:3:{s:11:\"multiplier.\";a:4:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";}s:8:\"gutters.\";a:4:{s:7:\"default\";s:2:\"24\";s:6:\"xlarge\";s:2:\"24\";s:5:\"large\";s:2:\"24\";s:6:\"medium\";s:2:\"24\";}s:12:\"corrections.\";a:6:{s:7:\"default\";s:2:\"25\";s:6:\"xlarge\";s:2:\"25\";s:5:\"large\";s:2:\"25\";s:6:\"medium\";s:2:\"25\";s:5:\"small\";s:2:\"50\";s:10:\"extrasmall\";s:2:\"50\";}}s:4:\"top.\";a:1:{s:12:\"corrections.\";a:5:{s:7:\"default\";s:2:\"50\";s:5:\"large\";s:2:\"50\";s:6:\"medium\";s:2:\"50\";s:5:\"small\";s:2:\"50\";s:10:\"extrasmall\";s:2:\"50\";}}s:6:\"right.\";a:3:{s:11:\"multiplier.\";a:4:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";}s:8:\"gutters.\";a:4:{s:7:\"default\";s:2:\"24\";s:6:\"xlarge\";s:2:\"24\";s:5:\"large\";s:2:\"24\";s:6:\"medium\";s:2:\"24\";}s:12:\"corrections.\";a:6:{s:7:\"default\";s:2:\"25\";s:6:\"xlarge\";s:2:\"25\";s:5:\"large\";s:2:\"25\";s:6:\"medium\";s:2:\"25\";s:5:\"small\";s:2:\"50\";s:10:\"extrasmall\";s:2:\"50\";}}s:7:\"bottom.\";a:1:{s:12:\"corrections.\";a:5:{s:7:\"default\";s:2:\"50\";s:5:\"large\";s:2:\"50\";s:6:\"medium\";s:2:\"50\";s:5:\"small\";s:2:\"50\";s:10:\"extrasmall\";s:2:\"50\";}}}s:11:\"card_group.\";a:4:{s:2:\"1.\";a:1:{s:12:\"corrections.\";a:6:{s:7:\"default\";s:1:\"2\";s:6:\"xlarge\";s:1:\"2\";s:5:\"large\";s:1:\"2\";s:6:\"medium\";s:1:\"2\";s:5:\"small\";s:1:\"2\";s:10:\"extrasmall\";s:1:\"2\";}}s:2:\"2.\";a:3:{s:11:\"multiplier.\";a:5:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";s:5:\"small\";s:3:\"0.5\";}s:8:\"gutters.\";a:5:{s:7:\"default\";s:2:\"20\";s:6:\"xlarge\";s:2:\"20\";s:5:\"large\";s:2:\"20\";s:6:\"medium\";s:2:\"20\";s:5:\"small\";s:2:\"20\";}s:12:\"corrections.\";a:6:{s:7:\"default\";s:1:\"2\";s:6:\"xlarge\";s:1:\"2\";s:5:\"large\";s:1:\"2\";s:6:\"medium\";s:1:\"2\";s:5:\"small\";s:1:\"2\";s:10:\"extrasmall\";s:1:\"2\";}}s:2:\"3.\";a:3:{s:11:\"multiplier.\";a:4:{s:7:\"default\";s:6:\"0.3333\";s:6:\"xlarge\";s:6:\"0.3333\";s:5:\"large\";s:6:\"0.3333\";s:6:\"medium\";s:6:\"0.3333\";}s:8:\"gutters.\";a:4:{s:7:\"default\";s:2:\"20\";s:6:\"xlarge\";s:2:\"20\";s:5:\"large\";s:2:\"20\";s:6:\"medium\";s:2:\"20\";}s:12:\"corrections.\";a:6:{s:7:\"default\";s:1:\"2\";s:6:\"xlarge\";s:1:\"2\";s:5:\"large\";s:1:\"2\";s:6:\"medium\";s:1:\"2\";s:5:\"small\";s:1:\"2\";s:10:\"extrasmall\";s:1:\"2\";}}s:2:\"4.\";a:3:{s:11:\"multiplier.\";a:5:{s:7:\"default\";s:4:\"0.25\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";s:5:\"small\";s:3:\"0.5\";}s:8:\"gutters.\";a:5:{s:7:\"default\";s:2:\"20\";s:6:\"xlarge\";s:2:\"20\";s:5:\"large\";s:2:\"20\";s:6:\"medium\";s:2:\"20\";s:5:\"small\";s:2:\"20\";}s:12:\"corrections.\";a:6:{s:7:\"default\";s:1:\"2\";s:6:\"xlarge\";s:1:\"2\";s:5:\"large\";s:1:\"2\";s:6:\"medium\";s:1:\"2\";s:5:\"small\";s:1:\"2\";s:10:\"extrasmall\";s:1:\"2\";}}}s:9:\"carousel.\";a:2:{s:17:\"background_image.\";a:1:{s:11:\"multiplier.\";a:3:{s:7:\"default\";s:3:\"1.5\";s:6:\"xlarge\";s:3:\"1.5\";s:5:\"large\";s:3:\"1.5\";}}s:15:\"text_and_image.\";a:1:{s:11:\"multiplier.\";a:5:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";s:5:\"small\";s:3:\"0.5\";}}}s:15:\"carousel_small.\";a:2:{s:17:\"background_image.\";a:1:{s:11:\"multiplier.\";a:3:{s:7:\"default\";s:3:\"1.5\";s:6:\"xlarge\";s:3:\"1.5\";s:5:\"large\";s:3:\"1.5\";}}s:15:\"text_and_image.\";a:1:{s:11:\"multiplier.\";a:5:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";s:5:\"small\";s:3:\"0.5\";}}}s:20:\"carousel_fullscreen.\";a:2:{s:17:\"background_image.\";a:1:{s:11:\"multiplier.\";a:3:{s:7:\"default\";s:3:\"1.5\";s:6:\"xlarge\";s:3:\"1.5\";s:5:\"large\";s:3:\"1.5\";}}s:15:\"text_and_image.\";a:1:{s:11:\"multiplier.\";a:5:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";s:5:\"small\";s:3:\"0.5\";}}}s:4:\"tab.\";a:2:{s:5:\"left.\";a:2:{s:11:\"multiplier.\";a:4:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";}s:8:\"gutters.\";a:4:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";s:6:\"medium\";s:2:\"40\";}}s:6:\"right.\";a:2:{s:11:\"multiplier.\";a:4:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";}s:8:\"gutters.\";a:4:{s:7:\"default\";s:2:\"40\";s:6:\"xlarge\";s:2:\"40\";s:5:\"large\";s:2:\"40\";s:6:\"medium\";s:2:\"40\";}}}s:9:\"timeline.\";a:2:{s:11:\"multiplier.\";a:4:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";}s:12:\"corrections.\";a:6:{s:7:\"default\";s:2:\"49\";s:6:\"xlarge\";s:2:\"49\";s:5:\"large\";s:2:\"49\";s:6:\"medium\";s:2:\"49\";s:5:\"small\";s:2:\"72\";s:10:\"extrasmall\";s:2:\"72\";}}s:14:\"menu_card_dir.\";a:4:{s:2:\"1.\";a:1:{s:12:\"corrections.\";a:6:{s:7:\"default\";s:1:\"2\";s:6:\"xlarge\";s:1:\"2\";s:5:\"large\";s:1:\"2\";s:6:\"medium\";s:1:\"2\";s:5:\"small\";s:1:\"2\";s:10:\"extrasmall\";s:1:\"2\";}}s:2:\"2.\";a:3:{s:11:\"multiplier.\";a:5:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";s:5:\"small\";s:3:\"0.5\";}s:8:\"gutters.\";a:5:{s:7:\"default\";s:2:\"20\";s:6:\"xlarge\";s:2:\"20\";s:5:\"large\";s:2:\"20\";s:6:\"medium\";s:2:\"20\";s:5:\"small\";s:2:\"20\";}s:12:\"corrections.\";a:6:{s:7:\"default\";s:1:\"2\";s:6:\"xlarge\";s:1:\"2\";s:5:\"large\";s:1:\"2\";s:6:\"medium\";s:1:\"2\";s:5:\"small\";s:1:\"2\";s:10:\"extrasmall\";s:1:\"2\";}}s:2:\"3.\";a:3:{s:11:\"multiplier.\";a:4:{s:7:\"default\";s:6:\"0.3333\";s:6:\"xlarge\";s:6:\"0.3333\";s:5:\"large\";s:6:\"0.3333\";s:6:\"medium\";s:6:\"0.3333\";}s:8:\"gutters.\";a:4:{s:7:\"default\";s:2:\"20\";s:6:\"xlarge\";s:2:\"20\";s:5:\"large\";s:2:\"20\";s:6:\"medium\";s:2:\"20\";}s:12:\"corrections.\";a:6:{s:7:\"default\";s:1:\"2\";s:6:\"xlarge\";s:1:\"2\";s:5:\"large\";s:1:\"2\";s:6:\"medium\";s:1:\"2\";s:5:\"small\";s:1:\"2\";s:10:\"extrasmall\";s:1:\"2\";}}s:2:\"4.\";a:3:{s:11:\"multiplier.\";a:5:{s:7:\"default\";s:4:\"0.25\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";s:5:\"small\";s:3:\"0.5\";}s:8:\"gutters.\";a:5:{s:7:\"default\";s:2:\"20\";s:6:\"xlarge\";s:2:\"20\";s:5:\"large\";s:2:\"20\";s:6:\"medium\";s:2:\"20\";s:5:\"small\";s:2:\"20\";}s:12:\"corrections.\";a:6:{s:7:\"default\";s:1:\"2\";s:6:\"xlarge\";s:1:\"2\";s:5:\"large\";s:1:\"2\";s:6:\"medium\";s:1:\"2\";s:5:\"small\";s:1:\"2\";s:10:\"extrasmall\";s:1:\"2\";}}}s:15:\"menu_card_list.\";a:4:{s:2:\"1.\";a:1:{s:12:\"corrections.\";a:6:{s:7:\"default\";s:1:\"2\";s:6:\"xlarge\";s:1:\"2\";s:5:\"large\";s:1:\"2\";s:6:\"medium\";s:1:\"2\";s:5:\"small\";s:1:\"2\";s:10:\"extrasmall\";s:1:\"2\";}}s:2:\"2.\";a:3:{s:11:\"multiplier.\";a:5:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";s:5:\"small\";s:3:\"0.5\";}s:8:\"gutters.\";a:5:{s:7:\"default\";s:2:\"20\";s:6:\"xlarge\";s:2:\"20\";s:5:\"large\";s:2:\"20\";s:6:\"medium\";s:2:\"20\";s:5:\"small\";s:2:\"20\";}s:12:\"corrections.\";a:6:{s:7:\"default\";s:1:\"2\";s:6:\"xlarge\";s:1:\"2\";s:5:\"large\";s:1:\"2\";s:6:\"medium\";s:1:\"2\";s:5:\"small\";s:1:\"2\";s:10:\"extrasmall\";s:1:\"2\";}}s:2:\"3.\";a:3:{s:11:\"multiplier.\";a:4:{s:7:\"default\";s:6:\"0.3333\";s:6:\"xlarge\";s:6:\"0.3333\";s:5:\"large\";s:6:\"0.3333\";s:6:\"medium\";s:6:\"0.3333\";}s:8:\"gutters.\";a:4:{s:7:\"default\";s:2:\"20\";s:6:\"xlarge\";s:2:\"20\";s:5:\"large\";s:2:\"20\";s:6:\"medium\";s:2:\"20\";}s:12:\"corrections.\";a:6:{s:7:\"default\";s:1:\"2\";s:6:\"xlarge\";s:1:\"2\";s:5:\"large\";s:1:\"2\";s:6:\"medium\";s:1:\"2\";s:5:\"small\";s:1:\"2\";s:10:\"extrasmall\";s:1:\"2\";}}s:2:\"4.\";a:3:{s:11:\"multiplier.\";a:5:{s:7:\"default\";s:4:\"0.25\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";s:5:\"small\";s:3:\"0.5\";}s:8:\"gutters.\";a:5:{s:7:\"default\";s:2:\"20\";s:6:\"xlarge\";s:2:\"20\";s:5:\"large\";s:2:\"20\";s:6:\"medium\";s:2:\"20\";s:5:\"small\";s:2:\"20\";}s:12:\"corrections.\";a:6:{s:7:\"default\";s:1:\"2\";s:6:\"xlarge\";s:1:\"2\";s:5:\"large\";s:1:\"2\";s:6:\"medium\";s:1:\"2\";s:5:\"small\";s:1:\"2\";s:10:\"extrasmall\";s:1:\"2\";}}}s:19:\"menu_thumbnail_dir.\";a:3:{s:2:\"2.\";a:2:{s:11:\"multiplier.\";a:5:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";s:5:\"small\";s:3:\"0.5\";}s:8:\"gutters.\";a:5:{s:7:\"default\";s:2:\"10\";s:6:\"xlarge\";s:2:\"10\";s:5:\"large\";s:2:\"10\";s:6:\"medium\";s:2:\"10\";s:5:\"small\";s:2:\"10\";}}s:2:\"3.\";a:2:{s:11:\"multiplier.\";a:5:{s:7:\"default\";s:6:\"0.3333\";s:6:\"xlarge\";s:6:\"0.3333\";s:5:\"large\";s:6:\"0.3333\";s:6:\"medium\";s:6:\"0.3333\";s:5:\"small\";s:6:\"0.3333\";}s:8:\"gutters.\";a:5:{s:7:\"default\";s:2:\"10\";s:6:\"xlarge\";s:2:\"10\";s:5:\"large\";s:2:\"10\";s:6:\"medium\";s:2:\"10\";s:5:\"small\";s:2:\"10\";}}s:2:\"4.\";a:2:{s:11:\"multiplier.\";a:5:{s:7:\"default\";s:4:\"0.25\";s:6:\"xlarge\";s:4:\"0.25\";s:5:\"large\";s:4:\"0.25\";s:6:\"medium\";s:3:\"0.5\";s:5:\"small\";s:3:\"0.5\";}s:8:\"gutters.\";a:5:{s:7:\"default\";s:2:\"10\";s:6:\"xlarge\";s:2:\"10\";s:5:\"large\";s:2:\"10\";s:6:\"medium\";s:2:\"10\";s:5:\"small\";s:2:\"10\";}}}s:20:\"menu_thumbnail_list.\";a:3:{s:2:\"2.\";a:2:{s:11:\"multiplier.\";a:5:{s:7:\"default\";s:3:\"0.5\";s:6:\"xlarge\";s:3:\"0.5\";s:5:\"large\";s:3:\"0.5\";s:6:\"medium\";s:3:\"0.5\";s:5:\"small\";s:3:\"0.5\";}s:8:\"gutters.\";a:5:{s:7:\"default\";s:2:\"10\";s:6:\"xlarge\";s:2:\"10\";s:5:\"large\";s:2:\"10\";s:6:\"medium\";s:2:\"10\";s:5:\"small\";s:2:\"10\";}}s:2:\"3.\";a:2:{s:11:\"multiplier.\";a:5:{s:7:\"default\";s:6:\"0.3333\";s:6:\"xlarge\";s:6:\"0.3333\";s:5:\"large\";s:6:\"0.3333\";s:6:\"medium\";s:6:\"0.3333\";s:5:\"small\";s:6:\"0.3333\";}s:8:\"gutters.\";a:5:{s:7:\"default\";s:2:\"10\";s:6:\"xlarge\";s:2:\"10\";s:5:\"large\";s:2:\"10\";s:6:\"medium\";s:2:\"10\";s:5:\"small\";s:2:\"10\";}}s:2:\"4.\";a:2:{s:11:\"multiplier.\";a:5:{s:7:\"default\";s:4:\"0.25\";s:6:\"xlarge\";s:4:\"0.25\";s:5:\"large\";s:4:\"0.25\";s:6:\"medium\";s:3:\"0.5\";s:5:\"small\";s:3:\"0.5\";}s:8:\"gutters.\";a:5:{s:7:\"default\";s:2:\"10\";s:6:\"xlarge\";s:2:\"10\";s:5:\"large\";s:2:\"10\";s:6:\"medium\";s:2:\"10\";s:5:\"small\";s:2:\"10\";}}}}}s:14:\"menuthumbnail.\";a:2:{s:6:\"title.\";a:1:{s:4:\"crop\";s:3:\"100\";}s:9:\"subtitle.\";a:1:{s:4:\"crop\";s:2:\"80\";}}s:9:\"menucard.\";a:4:{s:5:\"icon.\";a:3:{s:6:\"enable\";s:1:\"0\";s:6:\"height\";s:2:\"32\";s:5:\"width\";s:3:\"32c\";}s:6:\"title.\";a:1:{s:4:\"crop\";s:3:\"100\";}s:9:\"subtitle.\";a:1:{s:4:\"crop\";s:3:\"100\";}s:9:\"abstract.\";a:1:{s:4:\"crop\";s:3:\"250\";}}s:9:\"texticon.\";a:1:{s:5:\"icon.\";a:4:{s:8:\"default.\";a:2:{s:6:\"height\";s:2:\"32\";s:5:\"width\";s:2:\"32\";}s:7:\"medium.\";a:2:{s:6:\"height\";s:2:\"48\";s:5:\"width\";s:2:\"48\";}s:6:\"large.\";a:2:{s:6:\"height\";s:2:\"64\";s:5:\"width\";s:2:\"64\";}s:8:\"awesome.\";a:2:{s:6:\"height\";s:2:\"80\";s:5:\"width\";s:2:\"80\";}}}s:9:\"timeline.\";a:1:{s:5:\"date.\";a:1:{s:6:\"format\";s:17:\"%B %e, %Y - %H:%M\";}}s:8:\"uploads.\";a:1:{s:8:\"preview.\";a:2:{s:6:\"height\";s:4:\"100c\";s:5:\"width\";s:4:\"100c\";}}}}s:14:\"dynamicContent\";s:3:\"COA\";s:15:\"dynamicContent.\";a:5:{i:5;s:13:\"LOAD_REGISTER\";s:2:\"5.\";a:6:{s:7:\"colPos.\";a:2:{s:7:\"cObject\";s:4:\"TEXT\";s:8:\"cObject.\";a:2:{s:5:\"field\";s:6:\"colPos\";s:8:\"ifEmpty.\";a:2:{s:7:\"cObject\";s:4:\"TEXT\";s:8:\"cObject.\";a:2:{s:6:\"value.\";a:1:{s:7:\"current\";s:1:\"1\";}s:7:\"ifEmpty\";s:1:\"0\";}}}}s:6:\"slide.\";a:2:{s:7:\"cObject\";s:4:\"TEXT\";s:8:\"cObject.\";a:2:{s:9:\"override.\";a:2:{s:5:\"field\";s:5:\"slide\";s:3:\"if.\";a:2:{s:9:\"isInList.\";a:1:{s:5:\"field\";s:5:\"slide\";}s:5:\"value\";s:11:\"-1, 0, 1, 2\";}}s:7:\"ifEmpty\";s:1:\"0\";}}s:8:\"pageUid.\";a:2:{s:7:\"cObject\";s:4:\"TEXT\";s:8:\"cObject.\";a:2:{s:5:\"field\";s:7:\"pageUid\";s:8:\"ifEmpty.\";a:1:{s:4:\"data\";s:7:\"TSFE:id\";}}}s:15:\"contentFromPid.\";a:2:{s:7:\"cObject\";s:4:\"TEXT\";s:8:\"cObject.\";a:2:{s:4:\"data\";s:44:\"DB:pages:{register:pageUid}:content_from_pid\";s:5:\"data.\";a:1:{s:10:\"insertData\";s:1:\"1\";}}}s:5:\"wrap.\";a:2:{s:7:\"cObject\";s:4:\"TEXT\";s:8:\"cObject.\";a:1:{s:5:\"field\";s:4:\"wrap\";}}s:12:\"elementWrap.\";a:2:{s:7:\"cObject\";s:4:\"TEXT\";s:8:\"cObject.\";a:1:{s:5:\"field\";s:11:\"elementWrap\";}}}i:20;s:7:\"CONTENT\";s:3:\"20.\";a:6:{s:5:\"table\";s:10:\"tt_content\";s:7:\"select.\";a:5:{s:39:\"includeRecordsWithoutDefaultTranslation\";s:1:\"1\";s:7:\"orderBy\";s:7:\"sorting\";s:5:\"where\";s:27:\"{#colPos}={register:colPos}\";s:6:\"where.\";a:1:{s:10:\"insertData\";s:1:\"1\";}s:10:\"pidInList.\";a:2:{s:4:\"data\";s:16:\"register:pageUid\";s:9:\"override.\";a:1:{s:4:\"data\";s:23:\"register:contentFromPid\";}}}s:5:\"slide\";s:16:\"{register:slide}\";s:6:\"slide.\";a:1:{s:10:\"insertData\";s:1:\"1\";}s:10:\"renderObj.\";a:1:{s:8:\"stdWrap.\";a:2:{s:8:\"dataWrap\";s:22:\"{register:elementWrap}\";s:8:\"required\";s:1:\"1\";}}s:8:\"stdWrap.\";a:2:{s:8:\"dataWrap\";s:15:\"{register:wrap}\";s:8:\"required\";s:1:\"1\";}}i:90;s:16:\"RESTORE_REGISTER\";}s:19:\"dynamicContentSlide\";s:20:\"< lib.dynamicContent\";s:20:\"dynamicContentSlide.\";a:1:{s:3:\"20.\";a:1:{s:5:\"slide\";s:2:\"-1\";}}s:10:\"parseFunc.\";a:8:{s:9:\"makelinks\";s:1:\"1\";s:10:\"makelinks.\";a:2:{s:5:\"http.\";a:2:{s:4:\"keep\";s:4:\"path\";s:9:\"extTarget\";s:6:\"_blank\";}s:7:\"mailto.\";a:1:{s:4:\"keep\";s:4:\"path\";}}s:5:\"tags.\";a:4:{s:4:\"link\";s:4:\"TEXT\";s:5:\"link.\";a:3:{s:7:\"current\";s:1:\"1\";s:9:\"typolink.\";a:2:{s:10:\"parameter.\";a:1:{s:4:\"data\";s:22:\"parameters : allParams\";}s:9:\"extTarget\";s:6:\"_blank\";}s:10:\"parseFunc.\";a:1:{s:9:\"constants\";s:1:\"1\";}}s:1:\"a\";s:4:\"TEXT\";s:2:\"a.\";a:2:{s:7:\"current\";s:1:\"1\";s:9:\"typolink.\";a:6:{s:10:\"parameter.\";a:1:{s:4:\"data\";s:15:\"parameters:href\";}s:6:\"title.\";a:1:{s:4:\"data\";s:16:\"parameters:title\";}s:11:\"ATagParams.\";a:1:{s:4:\"data\";s:20:\"parameters:allParams\";}s:7:\"target.\";a:1:{s:4:\"data\";s:17:\"parameters:target\";}s:9:\"extTarget\";s:6:\"_blank\";s:10:\"extTarget.\";a:1:{s:9:\"override.\";a:1:{s:4:\"data\";s:17:\"parameters:target\";}}}}}s:9:\"allowTags\";s:1148:\"a, abbr, acronym, address, article, aside, b, bdo,big, blockquote, br, caption, center, cite, code, col,colgroup, dd, del, dfn, dl, div, dt, em, font,footer, header, h1, h2, h3, h4, h5, h6, hr, i, img,ins, kbd, label, li, link, meta, nav, ol, p, pre, q,samp, sdfield, section, small, span, strike, strong,style, sub, sup, table, thead, tbody, tfoot, td, th,tr, title, tt, u, ul, var,a, abbr, acronym, address, article, aside, b, bdo,big, blockquote, br, caption, center, cite, code, col,colgroup, dd, del, dfn, dl, div, dt, em, font,footer, header, h1, h2, h3, h4, h5, h6, hr, i, img,ins, kbd, label, li, link, meta, nav, ol, p, pre, q,samp, sdfield, section, small, span, strike, strong,style, sub, sup, table, thead, tbody, tfoot, td, th,tr, title, tt, u, ul, var,a, abbr, acronym, address, article, aside, b, bdo,big, blockquote, br, caption, center, cite, code, col,colgroup, dd, del, dfn, dl, div, dt, em, font,footer, header, h1, h2, h3, h4, h5, h6, hr, i, img,ins, kbd, label, li, link, meta, nav, ol, p, pre, q,samp, sdfield, section, small, span, strike, strong,style, sub, sup, table, thead, tbody, tfoot, td, th,tr, title, tt, u, ul, var\";s:8:\"denyTags\";s:1:\"*\";s:5:\"sword\";s:37:\"<span class=\"text-highlight\">|</span>\";s:9:\"constants\";s:1:\"1\";s:18:\"nonTypoTagStdWrap.\";a:2:{s:10:\"HTMLparser\";s:1:\"1\";s:11:\"HTMLparser.\";a:2:{s:18:\"keepNonMatchedTags\";s:1:\"1\";s:16:\"htmlSpecialChars\";s:1:\"2\";}}}s:14:\"parseFunc_RTE.\";a:10:{s:9:\"makelinks\";s:1:\"1\";s:10:\"makelinks.\";a:2:{s:5:\"http.\";a:2:{s:4:\"keep\";s:4:\"path\";s:9:\"extTarget\";s:6:\"_blank\";}s:7:\"mailto.\";a:1:{s:4:\"keep\";s:4:\"path\";}}s:5:\"tags.\";a:4:{s:4:\"link\";s:4:\"TEXT\";s:5:\"link.\";a:3:{s:7:\"current\";s:1:\"1\";s:9:\"typolink.\";a:2:{s:10:\"parameter.\";a:1:{s:4:\"data\";s:22:\"parameters : allParams\";}s:9:\"extTarget\";s:6:\"_blank\";}s:10:\"parseFunc.\";a:1:{s:9:\"constants\";s:1:\"1\";}}s:1:\"a\";s:4:\"TEXT\";s:2:\"a.\";a:2:{s:7:\"current\";s:1:\"1\";s:9:\"typolink.\";a:6:{s:10:\"parameter.\";a:1:{s:4:\"data\";s:15:\"parameters:href\";}s:6:\"title.\";a:1:{s:4:\"data\";s:16:\"parameters:title\";}s:11:\"ATagParams.\";a:1:{s:4:\"data\";s:20:\"parameters:allParams\";}s:7:\"target.\";a:1:{s:4:\"data\";s:17:\"parameters:target\";}s:9:\"extTarget\";s:6:\"_blank\";s:10:\"extTarget.\";a:1:{s:9:\"override.\";a:1:{s:4:\"data\";s:17:\"parameters:target\";}}}}}s:9:\"allowTags\";s:1148:\"a, abbr, acronym, address, article, aside, b, bdo,big, blockquote, br, caption, center, cite, code, col,colgroup, dd, del, dfn, dl, div, dt, em, font,footer, header, h1, h2, h3, h4, h5, h6, hr, i, img,ins, kbd, label, li, link, meta, nav, ol, p, pre, q,samp, sdfield, section, small, span, strike, strong,style, sub, sup, table, thead, tbody, tfoot, td, th,tr, title, tt, u, ul, var,a, abbr, acronym, address, article, aside, b, bdo,big, blockquote, br, caption, center, cite, code, col,colgroup, dd, del, dfn, dl, div, dt, em, font,footer, header, h1, h2, h3, h4, h5, h6, hr, i, img,ins, kbd, label, li, link, meta, nav, ol, p, pre, q,samp, sdfield, section, small, span, strike, strong,style, sub, sup, table, thead, tbody, tfoot, td, th,tr, title, tt, u, ul, var,a, abbr, acronym, address, article, aside, b, bdo,big, blockquote, br, caption, center, cite, code, col,colgroup, dd, del, dfn, dl, div, dt, em, font,footer, header, h1, h2, h3, h4, h5, h6, hr, i, img,ins, kbd, label, li, link, meta, nav, ol, p, pre, q,samp, sdfield, section, small, span, strike, strong,style, sub, sup, table, thead, tbody, tfoot, td, th,tr, title, tt, u, ul, var\";s:8:\"denyTags\";s:1:\"*\";s:5:\"sword\";s:37:\"<span class=\"text-highlight\">|</span>\";s:9:\"constants\";s:1:\"1\";s:18:\"nonTypoTagStdWrap.\";a:3:{s:10:\"HTMLparser\";s:1:\"1\";s:11:\"HTMLparser.\";a:2:{s:18:\"keepNonMatchedTags\";s:1:\"1\";s:16:\"htmlSpecialChars\";s:1:\"2\";}s:12:\"encapsLines.\";a:4:{s:13:\"encapsTagList\";s:38:\"p, pre, h1, h2, h3, h4, h5, h6, hr, dt\";s:9:\"remapTag.\";a:1:{s:3:\"DIV\";s:1:\"P\";}s:13:\"nonWrappedTag\";s:1:\"P\";s:17:\"innerStdWrap_all.\";a:1:{s:7:\"ifBlank\";s:6:\"&nbsp;\";}}}s:14:\"externalBlocks\";s:97:\"article, address, aside, blockquote, div, dd, dl, footer,header, nav, ol, section, table, ul, pre\";s:15:\"externalBlocks.\";a:15:{s:3:\"ol.\";a:2:{s:7:\"stripNL\";s:1:\"1\";s:8:\"stdWrap.\";a:1:{s:9:\"parseFunc\";s:15:\"< lib.parseFunc\";}}s:3:\"ul.\";a:2:{s:7:\"stripNL\";s:1:\"1\";s:8:\"stdWrap.\";a:3:{s:9:\"parseFunc\";s:15:\"< lib.parseFunc\";s:10:\"HTMLparser\";s:1:\"1\";s:11:\"HTMLparser.\";a:2:{s:5:\"tags.\";a:1:{s:3:\"ul.\";a:1:{s:10:\"fixAttrib.\";a:1:{s:6:\"class.\";a:1:{s:7:\"default\";s:11:\"list-normal\";}}}}s:18:\"keepNonMatchedTags\";s:1:\"1\";}}}s:6:\"table.\";a:4:{s:7:\"stripNL\";s:1:\"1\";s:8:\"stdWrap.\";a:1:{s:4:\"wrap\";s:37:\"<div class=\"table-responsive\">|</div>\";}s:14:\"HTMLtableCells\";s:1:\"1\";s:15:\"HTMLtableCells.\";a:1:{s:8:\"default.\";a:1:{s:8:\"stdWrap.\";a:2:{s:9:\"parseFunc\";s:19:\"< lib.parseFunc_RTE\";s:10:\"parseFunc.\";a:1:{s:18:\"nonTypoTagStdWrap.\";a:1:{s:12:\"encapsLines.\";a:1:{s:13:\"nonWrappedTag\";s:0:\"\";}}}}}}}s:4:\"pre.\";a:2:{s:7:\"stripNL\";s:1:\"1\";s:8:\"stdWrap.\";a:1:{s:10:\"parseFunc.\";a:8:{s:9:\"makelinks\";s:1:\"1\";s:10:\"makelinks.\";a:2:{s:5:\"http.\";a:2:{s:4:\"keep\";s:4:\"path\";s:9:\"extTarget\";s:6:\"_blank\";}s:7:\"mailto.\";a:1:{s:4:\"keep\";s:4:\"path\";}}s:5:\"tags.\";a:4:{s:4:\"link\";s:4:\"TEXT\";s:5:\"link.\";a:3:{s:7:\"current\";s:1:\"1\";s:9:\"typolink.\";a:2:{s:10:\"parameter.\";a:1:{s:4:\"data\";s:22:\"parameters : allParams\";}s:9:\"extTarget\";s:6:\"_blank\";}s:10:\"parseFunc.\";a:1:{s:9:\"constants\";s:1:\"1\";}}s:1:\"a\";s:4:\"TEXT\";s:2:\"a.\";a:2:{s:7:\"current\";s:1:\"1\";s:9:\"typolink.\";a:6:{s:10:\"parameter.\";a:1:{s:4:\"data\";s:15:\"parameters:href\";}s:6:\"title.\";a:1:{s:4:\"data\";s:16:\"parameters:title\";}s:11:\"ATagParams.\";a:1:{s:4:\"data\";s:20:\"parameters:allParams\";}s:7:\"target.\";a:1:{s:4:\"data\";s:17:\"parameters:target\";}s:9:\"extTarget\";s:6:\"_blank\";s:10:\"extTarget.\";a:1:{s:9:\"override.\";a:1:{s:4:\"data\";s:17:\"parameters:target\";}}}}}s:9:\"allowTags\";s:1148:\"a, abbr, acronym, address, article, aside, b, bdo,big, blockquote, br, caption, center, cite, code, col,colgroup, dd, del, dfn, dl, div, dt, em, font,footer, header, h1, h2, h3, h4, h5, h6, hr, i, img,ins, kbd, label, li, link, meta, nav, ol, p, pre, q,samp, sdfield, section, small, span, strike, strong,style, sub, sup, table, thead, tbody, tfoot, td, th,tr, title, tt, u, ul, var,a, abbr, acronym, address, article, aside, b, bdo,big, blockquote, br, caption, center, cite, code, col,colgroup, dd, del, dfn, dl, div, dt, em, font,footer, header, h1, h2, h3, h4, h5, h6, hr, i, img,ins, kbd, label, li, link, meta, nav, ol, p, pre, q,samp, sdfield, section, small, span, strike, strong,style, sub, sup, table, thead, tbody, tfoot, td, th,tr, title, tt, u, ul, var,a, abbr, acronym, address, article, aside, b, bdo,big, blockquote, br, caption, center, cite, code, col,colgroup, dd, del, dfn, dl, div, dt, em, font,footer, header, h1, h2, h3, h4, h5, h6, hr, i, img,ins, kbd, label, li, link, meta, nav, ol, p, pre, q,samp, sdfield, section, small, span, strike, strong,style, sub, sup, table, thead, tbody, tfoot, td, th,tr, title, tt, u, ul, var\";s:8:\"denyTags\";s:1:\"*\";s:5:\"sword\";s:37:\"<span class=\"text-highlight\">|</span>\";s:9:\"constants\";s:1:\"1\";s:18:\"nonTypoTagStdWrap.\";a:2:{s:10:\"HTMLparser\";s:1:\"1\";s:11:\"HTMLparser.\";a:2:{s:18:\"keepNonMatchedTags\";s:1:\"1\";s:16:\"htmlSpecialChars\";s:1:\"2\";}}}}}s:4:\"div.\";a:2:{s:7:\"stripNL\";s:1:\"1\";s:13:\"callRecursive\";s:1:\"1\";}s:8:\"address.\";a:2:{s:7:\"stripNL\";s:1:\"1\";s:13:\"callRecursive\";s:1:\"1\";}s:11:\"blockquote.\";a:2:{s:7:\"stripNL\";s:1:\"1\";s:13:\"callRecursive\";s:1:\"1\";}s:8:\"article.\";a:2:{s:7:\"stripNL\";s:1:\"1\";s:13:\"callRecursive\";s:1:\"1\";}s:6:\"aside.\";a:2:{s:7:\"stripNL\";s:1:\"1\";s:13:\"callRecursive\";s:1:\"1\";}s:7:\"footer.\";a:2:{s:7:\"stripNL\";s:1:\"1\";s:13:\"callRecursive\";s:1:\"1\";}s:7:\"header.\";a:2:{s:7:\"stripNL\";s:1:\"1\";s:13:\"callRecursive\";s:1:\"1\";}s:4:\"nav.\";a:2:{s:7:\"stripNL\";s:1:\"1\";s:13:\"callRecursive\";s:1:\"1\";}s:8:\"section.\";a:2:{s:7:\"stripNL\";s:1:\"1\";s:13:\"callRecursive\";s:1:\"1\";}s:3:\"dl.\";a:2:{s:7:\"stripNL\";s:1:\"1\";s:13:\"callRecursive\";s:1:\"1\";}s:3:\"dd.\";a:2:{s:7:\"stripNL\";s:1:\"1\";s:13:\"callRecursive\";s:1:\"1\";}}}s:5:\"block\";s:13:\"FLUIDTEMPLATE\";s:6:\"block.\";a:6:{s:12:\"templateName\";s:7:\"Default\";s:13:\"templateName.\";a:1:{s:9:\"override.\";a:1:{s:5:\"field\";s:8:\"template\";}}s:18:\"templateRootPaths.\";a:2:{i:0;s:57:\"EXT:bootstrap_package/Resources/Private/Templates/Blocks/\";i:10;s:57:\"EXT:bootstrap_package/Resources/Private/Templates/Blocks/\";}s:17:\"partialRootPaths.\";a:2:{i:0;s:56:\"EXT:bootstrap_package/Resources/Private/Partials/Blocks/\";i:10;s:56:\"EXT:bootstrap_package/Resources/Private/Partials/Blocks/\";}s:16:\"layoutRootPaths.\";a:2:{i:0;s:55:\"EXT:bootstrap_package/Resources/Private/Layouts/Blocks/\";i:10;s:55:\"EXT:bootstrap_package/Resources/Private/Layouts/Blocks/\";}s:15:\"dataProcessing.\";a:2:{i:1;s:55:\"BK2K\\BootstrapPackage\\DataProcessing\\ConstantsProcessor\";s:2:\"1.\";a:2:{s:2:\"as\";s:5:\"theme\";s:3:\"key\";s:10:\"page.theme\";}}}s:5:\"page.\";a:2:{s:5:\"class\";s:3:\"COA\";s:6:\"class.\";a:10:{i:10;s:4:\"TEXT\";s:3:\"10.\";a:2:{s:5:\"field\";s:12:\"alias // uid\";s:10:\"noTrimWrap\";s:8:\"|page-||\";}i:20;s:4:\"TEXT\";s:3:\"20.\";a:2:{s:4:\"data\";s:7:\"level:1\";s:10:\"noTrimWrap\";s:14:\"| pagelevel-||\";}i:30;s:4:\"TEXT\";s:3:\"30.\";a:2:{s:4:\"data\";s:23:\"siteLanguage:languageId\";s:10:\"noTrimWrap\";s:13:\"| language-||\";}i:40;s:4:\"TEXT\";s:3:\"40.\";a:4:{s:4:\"data\";s:10:\"pagelayout\";s:12:\"replacement.\";a:1:{s:3:\"10.\";a:2:{s:6:\"search\";s:8:\"pagets__\";s:7:\"replace\";s:0:\"\";}}s:7:\"ifEmpty\";s:7:\"default\";s:10:\"noTrimWrap\";s:18:\"| backendlayout-||\";}i:50;s:4:\"TEXT\";s:3:\"50.\";a:3:{s:5:\"field\";s:6:\"layout\";s:10:\"noTrimWrap\";s:11:\"| layout-||\";s:7:\"ifEmpty\";s:7:\"default\";}}}s:8:\"tx_form.\";a:2:{s:23:\"contentElementRendering\";s:7:\"RECORDS\";s:24:\"contentElementRendering.\";a:3:{s:6:\"tables\";s:10:\"tt_content\";s:7:\"source.\";a:1:{s:7:\"current\";s:1:\"1\";}s:12:\"dontCheckPid\";s:1:\"1\";}}}s:11:\"seo_sitemap\";s:4:\"PAGE\";s:12:\"seo_sitemap.\";a:4:{s:7:\"typeNum\";s:10:\"1533906435\";s:7:\"config.\";a:7:{s:12:\"cache_period\";s:3:\"900\";s:20:\"disableAllHeaderCode\";s:1:\"1\";s:8:\"admPanel\";s:1:\"0\";s:15:\"removeDefaultJS\";s:1:\"1\";s:16:\"removeDefaultCss\";s:1:\"1\";s:13:\"removePageCss\";s:1:\"1\";s:18:\"additionalHeaders.\";a:2:{s:3:\"10.\";a:1:{s:6:\"header\";s:42:\"Content-Type:application/xml;charset=utf-8\";}s:3:\"20.\";a:1:{s:6:\"header\";s:20:\"X-Robots-Tag:noindex\";}}}i:10;s:4:\"USER\";s:3:\"10.\";a:1:{s:8:\"userFunc\";s:51:\"TYPO3\\CMS\\Seo\\XmlSitemap\\XmlSitemapRenderer->render\";}}s:5:\"page.\";a:15:{s:11:\"includeCSS.\";a:1:{s:5:\"theme\";s:65:\"EXT:bootstrap_package/Resources/Public/Scss/bootstrap5/theme.scss\";}s:20:\"includeJSFooterlibs.\";a:14:{s:6:\"popper\";s:72:\"EXT:bootstrap_package/Resources/Public/Contrib/popper-core/popper.min.js\";s:9:\"bootstrap\";s:77:\"EXT:bootstrap_package/Resources/Public/Contrib/bootstrap5/js/bootstrap.min.js\";s:6:\"jquery\";s:67:\"EXT:bootstrap_package/Resources/Public/Contrib/jquery/jquery.min.js\";s:7:\"jquery.\";a:1:{s:10:\"forceOnTop\";s:1:\"1\";}s:15:\"photoswipe_core\";s:75:\"EXT:bootstrap_package/Resources/Public/Contrib/photoswipe/photoswipe.min.js\";s:13:\"photoswipe_ui\";s:86:\"EXT:bootstrap_package/Resources/Public/Contrib/photoswipe/photoswipe-ui-default.min.js\";s:19:\"bootstrap_accordion\";s:81:\"EXT:bootstrap_package/Resources/Public/JavaScript/Dist/bootstrap.accordion.min.js\";s:17:\"bootstrap_popover\";s:79:\"EXT:bootstrap_package/Resources/Public/JavaScript/Dist/bootstrap.popover.min.js\";s:22:\"bootstrap_stickyheader\";s:84:\"EXT:bootstrap_package/Resources/Public/JavaScript/Dist/bootstrap.stickyheader.min.js\";s:22:\"bootstrap_smoothscroll\";s:84:\"EXT:bootstrap_package/Resources/Public/JavaScript/Dist/bootstrap.smoothscroll.min.js\";s:18:\"bootstrap_lightbox\";s:80:\"EXT:bootstrap_package/Resources/Public/JavaScript/Dist/bootstrap.lightbox.min.js\";s:16:\"bootstrap_navbar\";s:78:\"EXT:bootstrap_package/Resources/Public/JavaScript/Dist/bootstrap.navbar.min.js\";s:21:\"contrib_cookieconsent\";s:81:\"EXT:bootstrap_package/Resources/Public/Contrib/cookieconsent/cookieconsent.min.js\";s:23:\"bootstrap_cookieconsent\";s:85:\"EXT:bootstrap_package/Resources/Public/JavaScript/Dist/bootstrap.cookieconsent.min.js\";}s:7:\"typeNum\";s:1:\"0\";s:12:\"shortcutIcon\";s:56:\"EXT:bootstrap_package/Resources/Public/Icons/favicon.ico\";s:14:\"bodyTagCObject\";s:3:\"COA\";s:15:\"bodyTagCObject.\";a:5:{i:10;s:4:\"TEXT\";s:3:\"10.\";a:2:{s:4:\"data\";s:7:\"TSFE:id\";s:10:\"noTrimWrap\";s:10:\"| id=\"p|\"|\";}i:20;s:16:\"< lib.page.class\";s:3:\"20.\";a:1:{s:8:\"stdWrap.\";a:1:{s:10:\"noTrimWrap\";s:12:\"| class=\"|\"|\";}}s:4:\"wrap\";s:7:\"<body|>\";}s:11:\"headerData.\";a:2:{i:10;s:5:\"HMENU\";s:3:\"10.\";a:4:{s:7:\"special\";s:6:\"browse\";s:8:\"special.\";a:1:{s:5:\"items\";s:9:\"prev|next\";}i:1;s:5:\"TMENU\";s:2:\"1.\";a:1:{s:3:\"NO.\";a:3:{s:7:\"allWrap\";s:57:\"<link rel=\"prev\" href=\"|\"> |*| <link rel=\"next\" href=\"|\">\";s:11:\"doNotLinkIt\";s:1:\"1\";s:8:\"stdWrap.\";a:1:{s:9:\"typolink.\";a:2:{s:10:\"parameter.\";a:1:{s:4:\"data\";s:9:\"field:uid\";}s:10:\"returnLast\";s:3:\"url\";}}}}}}i:10;s:13:\"FLUIDTEMPLATE\";s:3:\"10.\";a:9:{s:12:\"templateName\";s:4:\"TEXT\";s:13:\"templateName.\";a:3:{s:7:\"cObject\";s:4:\"TEXT\";s:8:\"cObject.\";a:4:{s:4:\"data\";s:10:\"pagelayout\";s:8:\"required\";s:1:\"1\";s:4:\"case\";s:14:\"uppercamelcase\";s:6:\"split.\";a:3:{s:5:\"token\";s:8:\"pagets__\";s:7:\"cObjNum\";s:1:\"1\";s:2:\"1.\";a:1:{s:7:\"current\";s:1:\"1\";}}}s:7:\"ifEmpty\";s:7:\"Default\";}s:18:\"templateRootPaths.\";a:2:{i:0;s:55:\"EXT:bootstrap_package/Resources/Private/Templates/Page/\";i:1;s:55:\"EXT:bootstrap_package/Resources/Private/Templates/Page/\";}s:17:\"partialRootPaths.\";a:2:{i:0;s:54:\"EXT:bootstrap_package/Resources/Private/Partials/Page/\";i:1;s:54:\"EXT:bootstrap_package/Resources/Private/Partials/Page/\";}s:16:\"layoutRootPaths.\";a:2:{i:0;s:53:\"EXT:bootstrap_package/Resources/Private/Layouts/Page/\";i:1;s:53:\"EXT:bootstrap_package/Resources/Private/Layouts/Page/\";}s:15:\"dataProcessing.\";a:14:{i:1;s:55:\"BK2K\\BootstrapPackage\\DataProcessing\\ConstantsProcessor\";s:2:\"1.\";a:2:{s:2:\"as\";s:5:\"theme\";s:3:\"key\";s:10:\"page.theme\";}i:10;s:47:\"TYPO3\\CMS\\Frontend\\DataProcessing\\MenuProcessor\";s:3:\"10.\";a:4:{s:6:\"levels\";s:1:\"2\";s:13:\"includeSpacer\";s:1:\"1\";s:2:\"as\";s:14:\"mainnavigation\";s:15:\"dataProcessing.\";a:2:{i:1628754217;s:55:\"BK2K\\BootstrapPackage\\DataProcessing\\IconsDataProcessor\";s:11:\"1628754217.\";a:5:{s:8:\"iconSet.\";a:1:{s:5:\"field\";s:12:\"nav_icon_set\";}s:15:\"iconIdentifier.\";a:1:{s:5:\"field\";s:19:\"nav_icon_identifier\";}s:17:\"iconFileFieldName\";s:8:\"nav_icon\";s:2:\"as\";s:4:\"icon\";s:3:\"if.\";a:1:{s:7:\"isTrue.\";a:1:{s:8:\"stdWrap.\";a:2:{s:7:\"cObject\";s:3:\"COA\";s:8:\"cObject.\";a:4:{i:10;s:4:\"TEXT\";s:3:\"10.\";a:2:{s:5:\"value\";s:1:\"1\";s:3:\"if.\";a:1:{s:6:\"isTrue\";s:1:\"1\";}}i:20;s:4:\"TEXT\";s:3:\"20.\";a:2:{s:5:\"value\";s:1:\"1\";s:3:\"if.\";a:1:{s:6:\"isTrue\";s:1:\"1\";}}}}}}}}}i:20;s:47:\"TYPO3\\CMS\\Frontend\\DataProcessing\\MenuProcessor\";s:3:\"20.\";a:6:{s:10:\"entryLevel\";s:1:\"1\";s:6:\"levels\";s:1:\"2\";s:9:\"expandAll\";s:1:\"0\";s:13:\"includeSpacer\";s:1:\"1\";s:2:\"as\";s:13:\"subnavigation\";s:15:\"dataProcessing.\";a:2:{i:1628754217;s:55:\"BK2K\\BootstrapPackage\\DataProcessing\\IconsDataProcessor\";s:11:\"1628754217.\";a:5:{s:8:\"iconSet.\";a:1:{s:5:\"field\";s:12:\"nav_icon_set\";}s:15:\"iconIdentifier.\";a:1:{s:5:\"field\";s:19:\"nav_icon_identifier\";}s:17:\"iconFileFieldName\";s:8:\"nav_icon\";s:2:\"as\";s:4:\"icon\";s:3:\"if.\";a:1:{s:6:\"isTrue\";s:1:\"1\";}}}}i:30;s:47:\"TYPO3\\CMS\\Frontend\\DataProcessing\\MenuProcessor\";s:3:\"30.\";a:6:{s:7:\"special\";s:8:\"rootline\";s:8:\"special.\";a:1:{s:5:\"range\";s:4:\"0|-1\";}s:16:\"includeNotInMenu\";s:1:\"1\";s:2:\"as\";s:10:\"breadcrumb\";s:3:\"if.\";a:3:{s:5:\"value\";s:1:\"2\";s:6:\"value.\";a:3:{s:10:\"insertData\";s:1:\"1\";s:10:\"prioriCalc\";s:1:\"1\";s:8:\"stdWrap.\";a:1:{s:4:\"wrap\";s:3:\"|-1\";}}s:14:\"isGreaterThan.\";a:1:{s:4:\"data\";s:5:\"level\";}}s:15:\"dataProcessing.\";a:2:{i:1628754217;s:55:\"BK2K\\BootstrapPackage\\DataProcessing\\IconsDataProcessor\";s:11:\"1628754217.\";a:4:{s:8:\"iconSet.\";a:1:{s:5:\"field\";s:12:\"nav_icon_set\";}s:15:\"iconIdentifier.\";a:1:{s:5:\"field\";s:19:\"nav_icon_identifier\";}s:17:\"iconFileFieldName\";s:8:\"nav_icon\";s:2:\"as\";s:4:\"icon\";}}}i:40;s:55:\"TYPO3\\CMS\\Frontend\\DataProcessing\\LanguageMenuProcessor\";s:3:\"40.\";a:2:{s:9:\"languages\";s:4:\"auto\";s:2:\"as\";s:18:\"languagenavigation\";}i:50;s:47:\"TYPO3\\CMS\\Frontend\\DataProcessing\\MenuProcessor\";s:3:\"50.\";a:5:{s:7:\"special\";s:4:\"list\";s:8:\"special.\";a:1:{s:5:\"value\";s:0:\"\";}s:16:\"includeNotInMenu\";s:1:\"1\";s:2:\"as\";s:14:\"metanavigation\";s:3:\"if.\";a:1:{s:6:\"isTrue\";s:0:\"\";}}i:1553883874;s:57:\"BK2K\\BootstrapPackage\\DataProcessing\\StaticFilesProcessor\";s:11:\"1553883874.\";a:2:{s:6:\"files.\";a:2:{s:6:\"normal\";s:66:\"EXT:bootstrap_package/Resources/Public/Images/BootstrapPackage.svg\";s:8:\"inverted\";s:74:\"EXT:bootstrap_package/Resources/Public/Images/BootstrapPackageInverted.svg\";}s:2:\"as\";s:4:\"logo\";}}s:9:\"settings.\";a:1:{s:5:\"logo.\";a:3:{s:6:\"height\";s:2:\"52\";s:5:\"width\";s:3:\"180\";s:9:\"linktitle\";s:0:\"\";}}s:10:\"variables.\";a:12:{s:9:\"pageTitle\";s:4:\"TEXT\";s:10:\"pageTitle.\";a:1:{s:4:\"data\";s:10:\"page:title\";}s:9:\"siteTitle\";s:4:\"TEXT\";s:10:\"siteTitle.\";a:1:{s:4:\"data\";s:61:\"siteLanguage:websiteTitle//site:websiteTitle//site:identifier\";}s:8:\"rootPage\";s:4:\"TEXT\";s:9:\"rootPage.\";a:1:{s:4:\"data\";s:10:\"leveluid:0\";}s:10:\"pagelayout\";s:4:\"TEXT\";s:11:\"pagelayout.\";a:3:{s:4:\"data\";s:10:\"pagelayout\";s:12:\"replacement.\";a:1:{s:3:\"10.\";a:2:{s:6:\"search\";s:8:\"pagets__\";s:7:\"replace\";s:0:\"\";}}s:7:\"ifEmpty\";s:7:\"default\";}s:7:\"logoAlt\";s:3:\"COA\";s:8:\"logoAlt.\";a:4:{i:10;s:4:\"TEXT\";s:3:\"10.\";a:3:{s:4:\"data\";s:61:\"siteLanguage:websiteTitle//site:websiteTitle//site:identifier\";s:10:\"noTrimWrap\";s:8:\"|| logo|\";s:3:\"if.\";a:1:{s:7:\"isFalse\";s:0:\"\";}}i:20;s:4:\"TEXT\";s:3:\"20.\";a:2:{s:5:\"value\";s:0:\"\";s:3:\"if.\";a:1:{s:6:\"isTrue\";s:0:\"\";}}}s:23:\"breadcrumbExtendedValue\";s:3:\"COA\";s:24:\"breadcrumbExtendedValue.\";a:0:{}}s:8:\"stdWrap.\";a:1:{s:12:\"replacement.\";a:5:{s:2:\"1.\";a:2:{s:6:\"search\";s:25:\"http://###BACKEND_URL###/\";s:8:\"replace.\";a:1:{s:9:\"typolink.\";a:2:{s:9:\"parameter\";s:6:\"typo3/\";s:10:\"returnLast\";s:3:\"url\";}}}s:2:\"2.\";a:2:{s:6:\"search\";s:18:\"###FRONTEND_URL###\";s:8:\"replace.\";a:1:{s:9:\"typolink.\";a:2:{s:10:\"parameter.\";a:1:{s:4:\"data\";s:10:\"leveluid:0\";}s:10:\"returnLast\";s:3:\"url\";}}}s:2:\"3.\";a:2:{s:6:\"search\";s:17:\"###CURRENTYEAR###\";s:8:\"replace.\";a:2:{s:4:\"data\";s:6:\"date:U\";s:8:\"strftime\";s:2:\"%Y\";}}s:2:\"4.\";a:2:{s:6:\"search\";s:11:\"###SPACE###\";s:8:\"replace.\";a:1:{s:4:\"char\";s:2:\"32\";}}s:3:\"99.\";a:2:{s:6:\"search\";s:27:\"###GoogleAnalyticsStatus###\";s:8:\"replace.\";a:2:{s:7:\"cObject\";s:13:\"FLUIDTEMPLATE\";s:8:\"cObject.\";a:6:{s:12:\"templateName\";s:21:\"GoogleAnalyticsStatus\";s:13:\"templateName.\";a:1:{s:9:\"override.\";a:1:{s:5:\"field\";s:8:\"template\";}}s:18:\"templateRootPaths.\";a:2:{i:0;s:57:\"EXT:bootstrap_package/Resources/Private/Templates/Blocks/\";i:10;s:57:\"EXT:bootstrap_package/Resources/Private/Templates/Blocks/\";}s:17:\"partialRootPaths.\";a:2:{i:0;s:56:\"EXT:bootstrap_package/Resources/Private/Partials/Blocks/\";i:10;s:56:\"EXT:bootstrap_package/Resources/Private/Partials/Blocks/\";}s:16:\"layoutRootPaths.\";a:2:{i:0;s:55:\"EXT:bootstrap_package/Resources/Private/Layouts/Blocks/\";i:10;s:55:\"EXT:bootstrap_package/Resources/Private/Layouts/Blocks/\";}s:15:\"dataProcessing.\";a:2:{i:1;s:55:\"BK2K\\BootstrapPackage\\DataProcessing\\ConstantsProcessor\";s:2:\"1.\";a:2:{s:2:\"as\";s:5:\"theme\";s:3:\"key\";s:10:\"page.theme\";}}}}}}}}s:5:\"meta.\";a:7:{s:8:\"viewport\";s:52:\"width=device-width, initial-scale=1, minimum-scale=1\";s:6:\"robots\";s:12:\"index,follow\";s:28:\"apple-mobile-web-app-capable\";s:2:\"no\";s:15:\"X-UA-Compatible\";s:7:\"IE=edge\";s:16:\"X-UA-Compatible.\";a:1:{s:9:\"attribute\";s:10:\"http-equiv\";}s:6:\"google\";s:11:\"notranslate\";s:24:\"google-site-verification\";s:0:\"\";}s:15:\"includeCSSLibs.\";a:3:{s:13:\"googlewebfont\";s:80:\"https://fonts.googleapis.com/css?display=swap&family=Source Sans Pro:300,400,700\";s:14:\"googlewebfont.\";a:4:{s:8:\"external\";s:1:\"1\";s:18:\"disableCompression\";s:1:\"1\";s:24:\"excludeFromConcatenation\";s:1:\"1\";s:3:\"if.\";a:1:{s:6:\"isTrue\";s:1:\"1\";}}s:20:\"bootstrappackageicon\";s:73:\"EXT:bootstrap_package/Resources/Public/Fonts/bootstrappackageicon.min.css\";}s:14:\"includeJSLibs.\";a:2:{s:9:\"modernizr\";s:73:\"EXT:bootstrap_package/Resources/Public/Contrib/modernizr/modernizr.min.js\";s:10:\"modernizr.\";a:2:{s:10:\"forceOnTop\";s:1:\"1\";s:5:\"async\";s:1:\"1\";}}s:9:\"jsInline.\";a:2:{i:99;s:3:\"COA\";s:3:\"99.\";a:5:{s:3:\"if.\";a:1:{s:6:\"isTrue\";s:0:\"\";}i:10;s:4:\"TEXT\";s:3:\"10.\";a:1:{s:5:\"value\";s:1986:\"    var gaProperty = \'\';\n    var disableStr = \'ga-disable-\' + gaProperty;\n    if (document.cookie.indexOf(disableStr + \'=true\') > -1) {\n        window[disableStr] = true;\n    }\n    function googleAnalyticsToggle(event) {\n        if (document.cookie.indexOf(disableStr + \'=true\') > -1) {\n            event.target.innerHTML = event.target.getAttribute(\'data-label-disable\');\n            googleAnalyticsOptIn();\n        } else {\n            event.target.innerHTML = event.target.getAttribute(\'data-label-enable\');\n            googleAnalyticsOptOut();\n        }\n    }\n    function googleAnalyticsOptOut() {\n        document.cookie = disableStr + \'=true; expires=Thu, 31 Dec 2099 23:59:59 UTC; path=/\';\n        window[disableStr] = true;\n    }\n    function googleAnalyticsOptIn() {\n        document.cookie = disableStr + \'=; expires=Thu, 01 Jan 1970 00:00:01 UTC; path=/\';\n        window[disableStr] = false;\n    }\n    document.addEventListener(\'DOMContentLoaded\', function() {\n        var matches = document.querySelectorAll(\'[data-action=\"googleAnalyticsToggle\"]\');\n        for (i=0; i<matches.length; i++) {\n            if (document.cookie.indexOf(disableStr + \'=true\') > -1) {\n                matches[i].innerHTML = matches[i].getAttribute(\'data-label-enable\');\n            } else {\n                matches[i].innerHTML = matches[i].getAttribute(\'data-label-disable\');\n            }\n            matches[i].onclick = function(event) {\n                event.preventDefault();\n                event.stopPropagation();\n                googleAnalyticsToggle(event);\n            }\n        }\n    });\n    (function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[r]=i[r]||function(){\n    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),\n    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)\n    })(window,document,\'script\',\'//www.google-analytics.com/analytics.js\',\'ga\');\n    ga(\'create\', \'\', \'auto\');\n    ga(\'set\', \'anonymizeIp\', true);\";}i:90;s:4:\"TEXT\";s:3:\"90.\";a:1:{s:5:\"value\";s:28:\"\n    ga(\'send\', \'pageview\');\";}}}s:10:\"includeJS.\";a:0:{}s:16:\"includeJSFooter.\";a:1:{s:22:\"my_sitepackage_scripts\";s:62:\"EXT:my_sitepackage/Resources/Public/JavaScript/Dist/scripts.js\";}}s:4:\"page\";s:4:\"PAGE\";s:23:\"fluidAjaxWidgetResponse\";s:4:\"PAGE\";s:24:\"fluidAjaxWidgetResponse.\";a:4:{s:7:\"typeNum\";s:4:\"7076\";s:7:\"config.\";a:4:{s:8:\"no_cache\";s:1:\"1\";s:20:\"disableAllHeaderCode\";s:1:\"1\";s:18:\"additionalHeaders.\";a:1:{s:3:\"10.\";a:2:{s:6:\"header\";s:24:\"Content-Type: text/plain\";s:7:\"replace\";s:1:\"1\";}}s:5:\"debug\";s:1:\"0\";}i:10;s:8:\"USER_INT\";s:3:\"10.\";a:1:{s:8:\"userFunc\";s:42:\"TYPO3\\CMS\\Fluid\\Core\\Widget\\Bootstrap->run\";}}s:9:\"sitetitle\";s:0:\"\";s:6:\"types.\";a:3:{i:1533906435;s:11:\"seo_sitemap\";i:0;s:4:\"page\";i:7076;s:23:\"fluidAjaxWidgetResponse\";}}}'),(3,'ae17c0809aeff68300a79c4ba3157375',2145909600,'a:1:{s:32:\"ffb7c399fe1d1c6c494fdaf47b419bd4\";s:8:\"[1 == 1]\";}'),(4,'4c016b0241af84857eab5a57446249e9',1639145717,'a:0:{}'),(5,'3bf4f6c578689d38935bc2ec133dd8af',1639145717,'a:1:{i:0;a:3:{s:11:\"doNotLinkIt\";s:1:\"1\";s:14:\"wrapItemAndSub\";s:3:\"{|}\";s:8:\"stdWrap.\";a:2:{s:7:\"cObject\";s:3:\"COA\";s:8:\"cObject.\";a:27:{i:1;s:13:\"LOAD_REGISTER\";s:2:\"1.\";a:1:{s:11:\"languageId.\";a:2:{s:7:\"cObject\";s:4:\"TEXT\";s:8:\"cObject.\";a:2:{s:6:\"value.\";a:1:{s:4:\"data\";s:24:\"register:languages_HMENU\";}s:8:\"listNum.\";a:2:{s:8:\"stdWrap.\";a:2:{s:4:\"data\";s:28:\"register:count_HMENU_MENUOBJ\";s:4:\"wrap\";s:3:\"|-1\";}s:9:\"splitChar\";s:1:\",\";}}}}i:10;s:4:\"TEXT\";s:3:\"10.\";a:2:{s:8:\"stdWrap.\";a:1:{s:4:\"data\";s:19:\"register:languageId\";}s:4:\"wrap\";s:14:\"\"languageId\":|\";}i:11;s:4:\"USER\";s:3:\"11.\";a:4:{s:8:\"userFunc\";s:71:\"TYPO3\\CMS\\Frontend\\DataProcessing\\LanguageMenuProcessor->getFieldAsJson\";s:9:\"language.\";a:1:{s:4:\"data\";s:19:\"register:languageId\";}s:5:\"field\";s:6:\"locale\";s:8:\"stdWrap.\";a:1:{s:4:\"wrap\";s:11:\",\"locale\":|\";}}i:20;s:4:\"USER\";s:3:\"20.\";a:4:{s:8:\"userFunc\";s:71:\"TYPO3\\CMS\\Frontend\\DataProcessing\\LanguageMenuProcessor->getFieldAsJson\";s:9:\"language.\";a:1:{s:4:\"data\";s:19:\"register:languageId\";}s:5:\"field\";s:5:\"title\";s:8:\"stdWrap.\";a:1:{s:4:\"wrap\";s:10:\",\"title\":|\";}}i:21;s:4:\"USER\";s:3:\"21.\";a:4:{s:8:\"userFunc\";s:71:\"TYPO3\\CMS\\Frontend\\DataProcessing\\LanguageMenuProcessor->getFieldAsJson\";s:9:\"language.\";a:1:{s:4:\"data\";s:19:\"register:languageId\";}s:5:\"field\";s:15:\"navigationTitle\";s:8:\"stdWrap.\";a:1:{s:4:\"wrap\";s:20:\",\"navigationTitle\":|\";}}i:22;s:4:\"USER\";s:3:\"22.\";a:4:{s:8:\"userFunc\";s:71:\"TYPO3\\CMS\\Frontend\\DataProcessing\\LanguageMenuProcessor->getFieldAsJson\";s:9:\"language.\";a:1:{s:4:\"data\";s:19:\"register:languageId\";}s:5:\"field\";s:16:\"twoLetterIsoCode\";s:8:\"stdWrap.\";a:1:{s:4:\"wrap\";s:21:\",\"twoLetterIsoCode\":|\";}}i:23;s:4:\"USER\";s:3:\"23.\";a:4:{s:8:\"userFunc\";s:71:\"TYPO3\\CMS\\Frontend\\DataProcessing\\LanguageMenuProcessor->getFieldAsJson\";s:9:\"language.\";a:1:{s:4:\"data\";s:19:\"register:languageId\";}s:5:\"field\";s:8:\"hreflang\";s:8:\"stdWrap.\";a:1:{s:4:\"wrap\";s:13:\",\"hreflang\":|\";}}i:24;s:4:\"USER\";s:3:\"24.\";a:4:{s:8:\"userFunc\";s:71:\"TYPO3\\CMS\\Frontend\\DataProcessing\\LanguageMenuProcessor->getFieldAsJson\";s:9:\"language.\";a:1:{s:4:\"data\";s:19:\"register:languageId\";}s:5:\"field\";s:9:\"direction\";s:8:\"stdWrap.\";a:1:{s:4:\"wrap\";s:14:\",\"direction\":|\";}}i:25;s:4:\"USER\";s:3:\"25.\";a:4:{s:8:\"userFunc\";s:71:\"TYPO3\\CMS\\Frontend\\DataProcessing\\LanguageMenuProcessor->getFieldAsJson\";s:9:\"language.\";a:1:{s:4:\"data\";s:19:\"register:languageId\";}s:5:\"field\";s:4:\"flag\";s:8:\"stdWrap.\";a:1:{s:4:\"wrap\";s:9:\",\"flag\":|\";}}i:90;s:4:\"TEXT\";s:3:\"90.\";a:2:{s:5:\"value\";s:21:\"###LINKPLACEHOLDER###\";s:4:\"wrap\";s:9:\",\"link\":|\";}i:91;s:4:\"TEXT\";s:3:\"91.\";a:2:{s:5:\"value\";s:1:\"1\";s:4:\"wrap\";s:11:\",\"active\":|\";}i:92;s:4:\"TEXT\";s:3:\"92.\";a:2:{s:5:\"value\";s:1:\"0\";s:4:\"wrap\";s:12:\",\"current\":|\";}i:93;s:4:\"TEXT\";s:3:\"93.\";a:2:{s:5:\"value\";s:1:\"1\";s:4:\"wrap\";s:14:\",\"available\":|\";}i:99;s:16:\"RESTORE_REGISTER\";}}}}'),(6,'44de090abc9448d6f75574d58d9319db',1639145717,'a:0:{}'),(7,'8dead708ac2d1dff4ea3197518fe0b7f',2145909600,'a:2:{i:0;a:3:{s:8:\"TSconfig\";a:5:{s:4:\"mod.\";a:5:{s:9:\"web_list.\";a:4:{s:28:\"enableDisplayBigControlPanel\";s:10:\"selectable\";s:15:\"enableClipBoard\";s:10:\"selectable\";s:18:\"tableDisplayOrder.\";a:9:{s:9:\"be_users.\";a:1:{s:5:\"after\";s:9:\"be_groups\";}s:15:\"sys_filemounts.\";a:1:{s:5:\"after\";s:8:\"be_users\";}s:17:\"sys_file_storage.\";a:1:{s:5:\"after\";s:14:\"sys_filemounts\";}s:13:\"sys_language.\";a:1:{s:5:\"after\";s:16:\"sys_file_storage\";}s:9:\"fe_users.\";a:2:{s:5:\"after\";s:9:\"fe_groups\";s:6:\"before\";s:5:\"pages\";}s:13:\"sys_template.\";a:1:{s:5:\"after\";s:5:\"pages\";}s:15:\"backend_layout.\";a:1:{s:5:\"after\";s:5:\"pages\";}s:11:\"tt_content.\";a:1:{s:5:\"after\";s:33:\"pages,backend_layout,sys_template\";}s:13:\"sys_category.\";a:1:{s:5:\"after\";s:10:\"tt_content\";}}s:12:\"searchLevel.\";a:1:{s:6:\"items.\";a:6:{i:-1;s:82:\"EXT:core/Resources/Private/Language/locallang_core.xlf:labels.searchLevel.infinite\";i:0;s:75:\"EXT:core/Resources/Private/Language/locallang_core.xlf:labels.searchLevel.0\";i:1;s:75:\"EXT:core/Resources/Private/Language/locallang_core.xlf:labels.searchLevel.1\";i:2;s:75:\"EXT:core/Resources/Private/Language/locallang_core.xlf:labels.searchLevel.2\";i:3;s:75:\"EXT:core/Resources/Private/Language/locallang_core.xlf:labels.searchLevel.3\";i:4;s:75:\"EXT:core/Resources/Private/Language/locallang_core.xlf:labels.searchLevel.4\";}}}s:8:\"wizards.\";a:2:{s:10:\"newRecord.\";a:1:{s:6:\"pages.\";a:1:{s:5:\"show.\";a:3:{s:10:\"pageInside\";s:1:\"1\";s:9:\"pageAfter\";s:1:\"1\";s:18:\"pageSelectPosition\";s:1:\"1\";}}}s:18:\"newContentElement.\";a:1:{s:12:\"wizardItems.\";a:10:{s:7:\"common.\";a:3:{s:9:\"elements.\";a:8:{s:7:\"header.\";a:4:{s:14:\"iconIdentifier\";s:14:\"content-header\";s:5:\"title\";s:98:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_headerOnly_title\";s:11:\"description\";s:104:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_headerOnly_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:6:\"header\";}}s:5:\"text.\";a:4:{s:14:\"iconIdentifier\";s:12:\"content-text\";s:5:\"title\";s:99:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_regularText_title\";s:11:\"description\";s:105:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_regularText_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:4:\"text\";}}s:8:\"textpic.\";a:4:{s:14:\"iconIdentifier\";s:15:\"content-textpic\";s:5:\"title\";s:97:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_textImage_title\";s:11:\"description\";s:103:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_textImage_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:7:\"textpic\";}}s:6:\"image.\";a:4:{s:14:\"iconIdentifier\";s:13:\"content-image\";s:5:\"title\";s:98:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_imagesOnly_title\";s:11:\"description\";s:104:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_imagesOnly_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:5:\"image\";}}s:10:\"textmedia.\";a:4:{s:14:\"iconIdentifier\";s:17:\"content-textmedia\";s:5:\"title\";s:97:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_textMedia_title\";s:11:\"description\";s:103:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_textMedia_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:9:\"textmedia\";}}s:8:\"bullets.\";a:4:{s:14:\"iconIdentifier\";s:15:\"content-bullets\";s:5:\"title\";s:98:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_bulletList_title\";s:11:\"description\";s:104:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_bulletList_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:7:\"bullets\";}}s:6:\"table.\";a:4:{s:14:\"iconIdentifier\";s:13:\"content-table\";s:5:\"title\";s:93:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_table_title\";s:11:\"description\";s:99:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_table_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:5:\"table\";}}s:8:\"uploads.\";a:4:{s:14:\"iconIdentifier\";s:23:\"content-special-uploads\";s:5:\"title\";s:98:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:special_filelinks_title\";s:11:\"description\";s:104:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:special_filelinks_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:7:\"uploads\";}}}s:4:\"show\";s:57:\"header,text,textpic,image,textmedia,bullets,table,uploads\";s:6:\"header\";s:81:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common\";}s:5:\"menu.\";a:3:{s:9:\"elements.\";a:15:{s:14:\"menu_abstract.\";a:4:{s:14:\"iconIdentifier\";s:21:\"content-menu-abstract\";s:5:\"title\";s:94:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_abstract.title\";s:11:\"description\";s:100:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_abstract.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:13:\"menu_abstract\";}}s:25:\"menu_categorized_content.\";a:4:{s:14:\"iconIdentifier\";s:24:\"content-menu-categorized\";s:5:\"title\";s:105:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_categorized_content.title\";s:11:\"description\";s:111:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_categorized_content.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:24:\"menu_categorized_content\";}}s:23:\"menu_categorized_pages.\";a:4:{s:14:\"iconIdentifier\";s:24:\"content-menu-categorized\";s:5:\"title\";s:103:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_categorized_pages.title\";s:11:\"description\";s:109:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_categorized_pages.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:22:\"menu_categorized_pages\";}}s:11:\"menu_pages.\";a:4:{s:14:\"iconIdentifier\";s:18:\"content-menu-pages\";s:5:\"title\";s:91:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_pages.title\";s:11:\"description\";s:97:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_pages.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:10:\"menu_pages\";}}s:14:\"menu_subpages.\";a:4:{s:14:\"iconIdentifier\";s:18:\"content-menu-pages\";s:5:\"title\";s:94:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_subpages.title\";s:11:\"description\";s:100:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_subpages.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:13:\"menu_subpages\";}}s:22:\"menu_recently_updated.\";a:4:{s:14:\"iconIdentifier\";s:29:\"content-menu-recently-updated\";s:5:\"title\";s:102:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_recently_updated.title\";s:11:\"description\";s:108:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_recently_updated.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:21:\"menu_recently_updated\";}}s:19:\"menu_related_pages.\";a:4:{s:14:\"iconIdentifier\";s:20:\"content-menu-related\";s:5:\"title\";s:99:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_related_pages.title\";s:11:\"description\";s:105:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_related_pages.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:18:\"menu_related_pages\";}}s:13:\"menu_section.\";a:4:{s:14:\"iconIdentifier\";s:20:\"content-menu-section\";s:5:\"title\";s:93:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_section.title\";s:11:\"description\";s:99:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_section.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:12:\"menu_section\";}}s:19:\"menu_section_pages.\";a:4:{s:14:\"iconIdentifier\";s:20:\"content-menu-section\";s:5:\"title\";s:99:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_section_pages.title\";s:11:\"description\";s:105:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_section_pages.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:18:\"menu_section_pages\";}}s:13:\"menu_sitemap.\";a:4:{s:14:\"iconIdentifier\";s:20:\"content-menu-sitemap\";s:5:\"title\";s:93:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_sitemap.title\";s:11:\"description\";s:99:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_sitemap.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:12:\"menu_sitemap\";}}s:19:\"menu_sitemap_pages.\";a:4:{s:14:\"iconIdentifier\";s:26:\"content-menu-sitemap-pages\";s:5:\"title\";s:99:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_sitemap_pages.title\";s:11:\"description\";s:105:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_sitemap_pages.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:18:\"menu_sitemap_pages\";}}s:14:\"menu_card_dir.\";a:4:{s:14:\"iconIdentifier\";s:34:\"content-bootstrappackage-menu-card\";s:5:\"title\";s:78:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:menu.card_dir\";s:11:\"description\";s:90:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:menu.card_dir.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:13:\"menu_card_dir\";}}s:15:\"menu_card_list.\";a:4:{s:14:\"iconIdentifier\";s:34:\"content-bootstrappackage-menu-card\";s:5:\"title\";s:79:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:menu.card_list\";s:11:\"description\";s:91:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:menu.card_list.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:14:\"menu_card_list\";}}s:19:\"menu_thumbnail_dir.\";a:4:{s:14:\"iconIdentifier\";s:22:\"content-menu-thumbnail\";s:5:\"title\";s:83:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:menu.thumbnail_dir\";s:11:\"description\";s:95:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:menu.thumbnail_dir.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:18:\"menu_thumbnail_dir\";}}s:20:\"menu_thumbnail_list.\";a:4:{s:14:\"iconIdentifier\";s:22:\"content-menu-thumbnail\";s:5:\"title\";s:84:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:menu.thumbnail_list\";s:11:\"description\";s:96:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:menu.thumbnail_list.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:19:\"menu_thumbnail_list\";}}}s:4:\"show\";s:259:\"menu_abstract,menu_categorized_content,menu_categorized_pages,menu_pages,menu_subpages,menu_recently_updated,menu_related_pages,menu_section,menu_section_pages,menu_sitemap,menu_sitemap_pages,menu_card_dir,menu_card_list,menu_thumbnail_dir,menu_thumbnail_list\";s:6:\"header\";s:79:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu\";}s:8:\"special.\";a:3:{s:9:\"elements.\";a:3:{s:5:\"html.\";a:4:{s:14:\"iconIdentifier\";s:20:\"content-special-html\";s:5:\"title\";s:98:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:special_plainHTML_title\";s:11:\"description\";s:104:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:special_plainHTML_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:4:\"html\";}}s:4:\"div.\";a:5:{s:14:\"iconIdentifier\";s:19:\"content-special-div\";s:5:\"title\";s:96:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:special_divider_title\";s:11:\"description\";s:102:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:special_divider_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:3:\"div\";}s:12:\"saveAndClose\";s:4:\"true\";}s:9:\"shortcut.\";a:4:{s:14:\"iconIdentifier\";s:24:\"content-special-shortcut\";s:5:\"title\";s:97:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:special_shortcut_title\";s:11:\"description\";s:103:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:special_shortcut_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:8:\"shortcut\";}}}s:4:\"show\";s:17:\"html,div,shortcut\";s:6:\"header\";s:82:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:special\";}s:6:\"forms.\";a:3:{s:4:\"show\";s:27:\"formframework,felogin_login\";s:9:\"elements.\";a:2:{s:14:\"formframework.\";a:4:{s:14:\"iconIdentifier\";s:12:\"content-form\";s:5:\"title\";s:75:\"LLL:EXT:form/Resources/Private/Language/locallang.xlf:form_new_wizard_title\";s:11:\"description\";s:77:\"LLL:EXT:form/Resources/Private/Language/locallang:form_new_wizard_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:18:\"form_formframework\";}}s:14:\"felogin_login.\";a:4:{s:14:\"iconIdentifier\";s:22:\"content-elements-login\";s:5:\"title\";s:92:\"LLL:EXT:felogin/Resources/Private/Language/Database.xlf:tt_content.CType.felogin_login.title\";s:11:\"description\";s:98:\"LLL:EXT:felogin/Resources/Private/Language/Database.xlf:tt_content.CType.felogin_login.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:13:\"felogin_login\";}}}s:6:\"header\";s:80:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:forms\";}s:8:\"plugins.\";a:3:{s:6:\"header\";s:82:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:plugins\";s:9:\"elements.\";a:1:{s:8:\"general.\";a:4:{s:14:\"iconIdentifier\";s:14:\"content-plugin\";s:5:\"title\";s:96:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:plugins_general_title\";s:11:\"description\";s:102:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:plugins_general_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:4:\"list\";}}}s:4:\"show\";s:1:\"*\";}s:12:\"interactive.\";a:3:{s:6:\"header\";s:90:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_group.interactive\";s:9:\"elements.\";a:5:{s:10:\"accordion.\";a:4:{s:14:\"iconIdentifier\";s:34:\"content-bootstrappackage-accordion\";s:5:\"title\";s:90:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.accordion\";s:11:\"description\";s:102:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.accordion.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:9:\"accordion\";}}s:9:\"carousel.\";a:4:{s:14:\"iconIdentifier\";s:33:\"content-bootstrappackage-carousel\";s:5:\"title\";s:89:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.carousel\";s:11:\"description\";s:101:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.carousel.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:8:\"carousel\";}}s:20:\"carousel_fullscreen.\";a:4:{s:14:\"iconIdentifier\";s:33:\"content-bootstrappackage-carousel\";s:5:\"title\";s:100:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.carousel_fullscreen\";s:11:\"description\";s:112:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.carousel_fullscreen.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:19:\"carousel_fullscreen\";}}s:15:\"carousel_small.\";a:4:{s:14:\"iconIdentifier\";s:33:\"content-bootstrappackage-carousel\";s:5:\"title\";s:95:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.carousel_small\";s:11:\"description\";s:107:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.carousel_small.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:14:\"carousel_small\";}}s:9:\"timeline.\";a:4:{s:14:\"iconIdentifier\";s:33:\"content-bootstrappackage-timeline\";s:5:\"title\";s:89:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.timeline\";s:11:\"description\";s:101:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.timeline.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:8:\"timeline\";}}}s:4:\"show\";s:62:\"accordion,carousel,carousel_fullscreen,carousel_small,timeline\";}s:6:\"media.\";a:3:{s:6:\"header\";s:84:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_group.media\";s:9:\"elements.\";a:11:{s:6:\"audio.\";a:4:{s:14:\"iconIdentifier\";s:13:\"content-audio\";s:5:\"title\";s:86:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.audio\";s:11:\"description\";s:98:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.audio.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:5:\"audio\";}}s:11:\"card_group.\";a:4:{s:14:\"iconIdentifier\";s:35:\"content-bootstrappackage-card-group\";s:5:\"title\";s:91:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.card_group\";s:11:\"description\";s:103:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.card_group.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:10:\"card_group\";}}s:15:\"external_media.\";a:4:{s:14:\"iconIdentifier\";s:38:\"content-bootstrappackage-externalmedia\";s:5:\"title\";s:95:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.external_media\";s:11:\"description\";s:107:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.external_media.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:14:\"external_media\";}}s:8:\"gallery.\";a:4:{s:14:\"iconIdentifier\";s:32:\"content-bootstrappackage-gallery\";s:5:\"title\";s:88:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.gallery\";s:11:\"description\";s:100:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.gallery.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:7:\"gallery\";}}s:11:\"icon_group.\";a:4:{s:14:\"iconIdentifier\";s:35:\"content-bootstrappackage-icon-group\";s:5:\"title\";s:91:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.icon_group\";s:11:\"description\";s:103:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.icon_group.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:10:\"icon_group\";}}s:6:\"image.\";a:4:{s:14:\"iconIdentifier\";s:13:\"content-image\";s:5:\"title\";s:98:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_imagesOnly_title\";s:11:\"description\";s:104:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_imagesOnly_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:5:\"image\";}}s:6:\"media.\";a:4:{s:14:\"iconIdentifier\";s:30:\"mimetypes-x-content-multimedia\";s:5:\"title\";s:86:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.media\";s:11:\"description\";s:98:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.media.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:5:\"media\";}}s:4:\"tab.\";a:4:{s:14:\"iconIdentifier\";s:28:\"content-bootstrappackage-tab\";s:5:\"title\";s:84:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.tab\";s:11:\"description\";s:96:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.tab.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:3:\"tab\";}}s:10:\"textmedia.\";a:4:{s:14:\"iconIdentifier\";s:17:\"content-textmedia\";s:5:\"title\";s:97:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_textMedia_title\";s:11:\"description\";s:103:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_textMedia_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:9:\"textmedia\";}}s:8:\"textpic.\";a:4:{s:14:\"iconIdentifier\";s:15:\"content-textpic\";s:5:\"title\";s:97:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_textImage_title\";s:11:\"description\";s:103:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_textImage_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:7:\"textpic\";}}s:8:\"uploads.\";a:4:{s:14:\"iconIdentifier\";s:23:\"content-special-uploads\";s:5:\"title\";s:98:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:special_filelinks_title\";s:11:\"description\";s:104:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:special_filelinks_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:7:\"uploads\";}}}s:4:\"show\";s:92:\"audio,card_group,external_media,gallery,icon_group,image,media,tab,textmedia,textpic,uploads\";}s:5:\"text.\";a:3:{s:6:\"header\";s:83:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_group.text\";s:9:\"elements.\";a:13:{s:8:\"bullets.\";a:4:{s:14:\"iconIdentifier\";s:15:\"content-bullets\";s:5:\"title\";s:98:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_bulletList_title\";s:11:\"description\";s:104:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_bulletList_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:7:\"bullets\";}}s:11:\"card_group.\";a:4:{s:14:\"iconIdentifier\";s:35:\"content-bootstrappackage-card-group\";s:5:\"title\";s:91:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.card_group\";s:11:\"description\";s:103:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.card_group.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:10:\"card_group\";}}s:7:\"header.\";a:4:{s:14:\"iconIdentifier\";s:14:\"content-header\";s:5:\"title\";s:98:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_headerOnly_title\";s:11:\"description\";s:104:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_headerOnly_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:6:\"header\";}}s:10:\"listgroup.\";a:4:{s:14:\"iconIdentifier\";s:34:\"content-bootstrappackage-listgroup\";s:5:\"title\";s:90:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.listgroup\";s:11:\"description\";s:102:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.listgroup.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:9:\"listgroup\";}}s:6:\"panel.\";a:4:{s:14:\"iconIdentifier\";s:13:\"content-panel\";s:5:\"title\";s:86:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.panel\";s:11:\"description\";s:98:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.panel.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:5:\"panel\";}}s:6:\"quote.\";a:4:{s:14:\"iconIdentifier\";s:13:\"content-quote\";s:5:\"title\";s:86:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.quote\";s:11:\"description\";s:98:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.quote.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:5:\"quote\";}}s:6:\"table.\";a:4:{s:14:\"iconIdentifier\";s:13:\"content-table\";s:5:\"title\";s:93:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_table_title\";s:11:\"description\";s:99:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_table_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:5:\"table\";}}s:5:\"text.\";a:4:{s:14:\"iconIdentifier\";s:12:\"content-text\";s:5:\"title\";s:99:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_regularText_title\";s:11:\"description\";s:105:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_regularText_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:4:\"text\";}}s:11:\"textcolumn.\";a:4:{s:14:\"iconIdentifier\";s:20:\"content-text-columns\";s:5:\"title\";s:91:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.textcolumn\";s:11:\"description\";s:103:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.textcolumn.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:10:\"textcolumn\";}}s:9:\"texticon.\";a:4:{s:14:\"iconIdentifier\";s:33:\"content-bootstrappackage-texticon\";s:5:\"title\";s:89:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.texticon\";s:11:\"description\";s:101:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.texticon.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:8:\"texticon\";}}s:10:\"textmedia.\";a:4:{s:14:\"iconIdentifier\";s:17:\"content-textmedia\";s:5:\"title\";s:97:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_textMedia_title\";s:11:\"description\";s:103:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_textMedia_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:9:\"textmedia\";}}s:8:\"textpic.\";a:4:{s:14:\"iconIdentifier\";s:15:\"content-textpic\";s:5:\"title\";s:97:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_textImage_title\";s:11:\"description\";s:103:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_textImage_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:7:\"textpic\";}}s:11:\"textteaser.\";a:4:{s:14:\"iconIdentifier\";s:19:\"content-text-teaser\";s:5:\"title\";s:91:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.textteaser\";s:11:\"description\";s:103:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.textteaser.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:10:\"textteaser\";}}}s:4:\"show\";s:107:\"bullets,card_group,header,listgroup,panel,quote,table,text,textcolumn,texticon,textmedia,textpic,textteaser\";}s:7:\"social.\";a:3:{s:6:\"header\";s:91:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_group.social_media\";s:9:\"elements.\";a:1:{s:13:\"social_links.\";a:4:{s:14:\"iconIdentifier\";s:37:\"content-bootstrappackage-social-links\";s:5:\"title\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.social_links\";s:11:\"description\";s:105:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.social_links.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:12:\"social_links\";}}}s:4:\"show\";s:12:\"social_links\";}s:5:\"data.\";a:3:{s:6:\"header\";s:83:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_group.data\";s:9:\"elements.\";a:2:{s:4:\"csv.\";a:4:{s:14:\"iconIdentifier\";s:28:\"content-bootstrappackage-csv\";s:5:\"title\";s:84:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.csv\";s:11:\"description\";s:96:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.csv.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:3:\"csv\";}}s:6:\"table.\";a:4:{s:14:\"iconIdentifier\";s:13:\"content-table\";s:5:\"title\";s:93:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_table_title\";s:11:\"description\";s:99:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_table_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:5:\"table\";}}}s:4:\"show\";s:9:\"csv,table\";}}}}s:9:\"web_view.\";a:1:{s:19:\"previewFrameWidths.\";a:12:{s:5:\"1920.\";a:4:{s:5:\"label\";s:66:\"LLL:EXT:viewpage/Resources/Private/Language/locallang.xlf:computer\";s:4:\"type\";s:7:\"desktop\";s:5:\"width\";s:4:\"1920\";s:6:\"height\";s:4:\"1080\";}s:5:\"1366.\";a:4:{s:5:\"label\";s:66:\"LLL:EXT:viewpage/Resources/Private/Language/locallang.xlf:computer\";s:4:\"type\";s:7:\"desktop\";s:5:\"width\";s:4:\"1366\";s:6:\"height\";s:3:\"768\";}s:5:\"1280.\";a:4:{s:5:\"label\";s:66:\"LLL:EXT:viewpage/Resources/Private/Language/locallang.xlf:computer\";s:4:\"type\";s:7:\"desktop\";s:5:\"width\";s:4:\"1280\";s:6:\"height\";s:4:\"1024\";}s:5:\"1024.\";a:4:{s:5:\"label\";s:66:\"LLL:EXT:viewpage/Resources/Private/Language/locallang.xlf:computer\";s:4:\"type\";s:7:\"desktop\";s:5:\"width\";s:4:\"1024\";s:6:\"height\";s:3:\"768\";}s:7:\"nexus7.\";a:4:{s:5:\"label\";s:7:\"Nexus 7\";s:4:\"type\";s:6:\"tablet\";s:5:\"width\";s:3:\"600\";s:6:\"height\";s:3:\"960\";}s:8:\"nexus6p.\";a:4:{s:5:\"label\";s:8:\"Nexus 6P\";s:4:\"type\";s:6:\"mobile\";s:5:\"width\";s:3:\"411\";s:6:\"height\";s:3:\"731\";}s:8:\"ipadpro.\";a:4:{s:5:\"label\";s:8:\"iPad Pro\";s:4:\"type\";s:6:\"tablet\";s:5:\"width\";s:4:\"1024\";s:6:\"height\";s:4:\"1366\";}s:8:\"ipadair.\";a:4:{s:5:\"label\";s:8:\"iPad Air\";s:4:\"type\";s:6:\"tablet\";s:5:\"width\";s:3:\"768\";s:6:\"height\";s:4:\"1024\";}s:12:\"iphone7plus.\";a:4:{s:5:\"label\";s:13:\"iPhone 7 Plus\";s:4:\"type\";s:6:\"mobile\";s:5:\"width\";s:3:\"414\";s:6:\"height\";s:3:\"736\";}s:8:\"iphone6.\";a:4:{s:5:\"label\";s:8:\"iPhone 6\";s:4:\"type\";s:6:\"mobile\";s:5:\"width\";s:3:\"375\";s:6:\"height\";s:3:\"667\";}s:8:\"iphone5.\";a:4:{s:5:\"label\";s:8:\"iPhone 5\";s:4:\"type\";s:6:\"mobile\";s:5:\"width\";s:3:\"320\";s:6:\"height\";s:3:\"568\";}s:8:\"iphone4.\";a:4:{s:5:\"label\";s:8:\"iPhone 4\";s:4:\"type\";s:6:\"mobile\";s:5:\"width\";s:3:\"320\";s:6:\"height\";s:3:\"480\";}}}s:9:\"web_info.\";a:1:{s:17:\"fieldDefinitions.\";a:5:{s:2:\"0.\";a:2:{s:5:\"label\";s:69:\"LLL:EXT:info/Resources/Private/Language/locallang_webinfo.xlf:pages_0\";s:6:\"fields\";s:75:\"title,uid,slug,starttime,endtime,fe_group,target,url,shortcut,shortcut_mode\";}s:2:\"1.\";a:2:{s:5:\"label\";s:69:\"LLL:EXT:info/Resources/Private/Language/locallang_webinfo.xlf:pages_1\";s:6:\"fields\";s:26:\"title,uid,###ALL_TABLES###\";}s:2:\"2.\";a:2:{s:5:\"label\";s:69:\"LLL:EXT:info/Resources/Private/Language/locallang_webinfo.xlf:pages_2\";s:6:\"fields\";s:93:\"title,uid,lastUpdated,newUntil,cache_timeout,php_tree_stop,TSconfig,is_siteroot,fe_login_mode\";}s:4:\"seo.\";a:2:{s:5:\"label\";s:64:\"LLL:EXT:seo/Resources/Private/Language/locallang_webinfo.xlf:seo\";s:6:\"fields\";s:106:\"title,uid,slug,seo_title,description,no_index,no_follow,canonical_link,sitemap_changefreq,sitemap_priority\";}s:13:\"social_media.\";a:2:{s:5:\"label\";s:73:\"LLL:EXT:seo/Resources/Private/Language/locallang_webinfo.xlf:social_media\";s:6:\"fields\";s:67:\"title,uid,og_title,og_description,twitter_title,twitter_description\";}}}s:11:\"web_layout.\";a:2:{s:11:\"tt_content.\";a:1:{s:8:\"preview.\";a:4:{s:3:\"csv\";s:66:\"EXT:bootstrap_package/Resources/Private/Templates/Preview/Csv.html\";s:14:\"external_media\";s:76:\"EXT:bootstrap_package/Resources/Private/Templates/Preview/ExternalMedia.html\";s:9:\"listgroup\";s:72:\"EXT:bootstrap_package/Resources/Private/Templates/Preview/ListGroup.html\";s:5:\"quote\";s:68:\"EXT:bootstrap_package/Resources/Private/Templates/Preview/Quote.html\";}}s:15:\"BackendLayouts.\";a:14:{s:10:\"2_columns.\";a:3:{s:5:\"title\";s:89:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.2_columns\";s:7:\"config.\";a:1:{s:15:\"backend_layout.\";a:3:{s:8:\"colCount\";s:2:\"12\";s:8:\"rowCount\";s:1:\"5\";s:5:\"rows.\";a:5:{s:2:\"1.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.border\";s:6:\"colPos\";s:1:\"3\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"2.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:100:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentbefore\";s:6:\"colPos\";s:1:\"8\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"3.\";a:1:{s:8:\"columns.\";a:2:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.normal\";s:6:\"colPos\";s:1:\"0\";s:7:\"colspan\";s:1:\"8\";}s:2:\"2.\";a:3:{s:4:\"name\";s:92:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.right\";s:6:\"colPos\";s:1:\"2\";s:7:\"colspan\";s:1:\"4\";}}}s:2:\"4.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:99:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentafter\";s:6:\"colPos\";s:1:\"9\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"5.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer1\";s:6:\"colPos\";s:2:\"10\";s:7:\"colspan\";s:1:\"4\";}s:2:\"2.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer2\";s:6:\"colPos\";s:2:\"11\";s:7:\"colspan\";s:1:\"4\";}s:2:\"3.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer3\";s:6:\"colPos\";s:2:\"12\";s:7:\"colspan\";s:1:\"4\";}}}}}}s:4:\"icon\";s:73:\"EXT:bootstrap_package/Resources/Public/Icons/BackendLayouts/2_columns.svg\";}s:16:\"2_columns_25_75.\";a:3:{s:5:\"title\";s:95:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.2_columns_25_75\";s:7:\"config.\";a:1:{s:15:\"backend_layout.\";a:3:{s:8:\"colCount\";s:2:\"12\";s:8:\"rowCount\";s:1:\"5\";s:5:\"rows.\";a:5:{s:2:\"1.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.border\";s:6:\"colPos\";s:1:\"3\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"2.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:100:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentbefore\";s:6:\"colPos\";s:1:\"8\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"3.\";a:1:{s:8:\"columns.\";a:2:{s:2:\"1.\";a:3:{s:4:\"name\";s:91:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.left\";s:6:\"colPos\";s:1:\"1\";s:7:\"colspan\";s:1:\"4\";}s:2:\"2.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.normal\";s:6:\"colPos\";s:1:\"0\";s:7:\"colspan\";s:1:\"8\";}}}s:2:\"4.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:99:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentafter\";s:6:\"colPos\";s:1:\"9\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"5.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer1\";s:6:\"colPos\";s:2:\"10\";s:7:\"colspan\";s:1:\"4\";}s:2:\"2.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer2\";s:6:\"colPos\";s:2:\"11\";s:7:\"colspan\";s:1:\"4\";}s:2:\"3.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer3\";s:6:\"colPos\";s:2:\"12\";s:7:\"colspan\";s:1:\"4\";}}}}}}s:4:\"icon\";s:79:\"EXT:bootstrap_package/Resources/Public/Icons/BackendLayouts/2_columns_25_75.svg\";}s:16:\"2_columns_50_50.\";a:3:{s:5:\"title\";s:95:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.2_columns_50_50\";s:7:\"config.\";a:1:{s:15:\"backend_layout.\";a:3:{s:8:\"colCount\";s:2:\"12\";s:8:\"rowCount\";s:1:\"5\";s:5:\"rows.\";a:5:{s:2:\"1.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.border\";s:6:\"colPos\";s:1:\"3\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"2.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:100:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentbefore\";s:6:\"colPos\";s:1:\"8\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"3.\";a:1:{s:8:\"columns.\";a:2:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.normal\";s:6:\"colPos\";s:1:\"0\";s:7:\"colspan\";s:1:\"6\";}s:2:\"2.\";a:3:{s:4:\"name\";s:92:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.right\";s:6:\"colPos\";s:1:\"2\";s:7:\"colspan\";s:1:\"6\";}}}s:2:\"4.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:99:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentafter\";s:6:\"colPos\";s:1:\"9\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"5.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer1\";s:6:\"colPos\";s:2:\"10\";s:7:\"colspan\";s:1:\"4\";}s:2:\"2.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer2\";s:6:\"colPos\";s:2:\"11\";s:7:\"colspan\";s:1:\"4\";}s:2:\"3.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer3\";s:6:\"colPos\";s:2:\"12\";s:7:\"colspan\";s:1:\"4\";}}}}}}s:4:\"icon\";s:79:\"EXT:bootstrap_package/Resources/Public/Icons/BackendLayouts/2_columns_50_50.svg\";}s:23:\"2_columns_offset_right.\";a:3:{s:5:\"title\";s:102:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.2_columns_offset_right\";s:7:\"config.\";a:1:{s:15:\"backend_layout.\";a:3:{s:8:\"colCount\";s:2:\"12\";s:8:\"rowCount\";s:1:\"5\";s:5:\"rows.\";a:5:{s:2:\"1.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.border\";s:6:\"colPos\";s:1:\"3\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"2.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:100:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentbefore\";s:6:\"colPos\";s:1:\"8\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"3.\";a:1:{s:8:\"columns.\";a:2:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.normal\";s:6:\"colPos\";s:1:\"0\";s:7:\"colspan\";s:1:\"8\";}s:2:\"2.\";a:3:{s:4:\"name\";s:92:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.right\";s:6:\"colPos\";s:1:\"2\";s:7:\"colspan\";s:1:\"4\";}}}s:2:\"4.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:99:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentafter\";s:6:\"colPos\";s:1:\"9\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"5.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer1\";s:6:\"colPos\";s:2:\"10\";s:7:\"colspan\";s:1:\"4\";}s:2:\"2.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer2\";s:6:\"colPos\";s:2:\"11\";s:7:\"colspan\";s:1:\"4\";}s:2:\"3.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer3\";s:6:\"colPos\";s:2:\"12\";s:7:\"colspan\";s:1:\"4\";}}}}}}s:4:\"icon\";s:86:\"EXT:bootstrap_package/Resources/Public/Icons/BackendLayouts/2_columns_offset_right.svg\";}s:10:\"3_columns.\";a:3:{s:5:\"title\";s:89:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.3_columns\";s:7:\"config.\";a:1:{s:15:\"backend_layout.\";a:3:{s:8:\"colCount\";s:2:\"12\";s:8:\"rowCount\";s:1:\"5\";s:5:\"rows.\";a:5:{s:2:\"1.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.border\";s:6:\"colPos\";s:1:\"3\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"2.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:100:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentbefore\";s:6:\"colPos\";s:1:\"8\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"3.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:3:{s:4:\"name\";s:91:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.left\";s:6:\"colPos\";s:1:\"1\";s:7:\"colspan\";s:1:\"3\";}s:2:\"2.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.normal\";s:6:\"colPos\";s:1:\"0\";s:7:\"colspan\";s:1:\"6\";}s:2:\"3.\";a:3:{s:4:\"name\";s:92:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.right\";s:6:\"colPos\";s:1:\"2\";s:7:\"colspan\";s:1:\"3\";}}}s:2:\"4.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:99:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentafter\";s:6:\"colPos\";s:1:\"9\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"5.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer1\";s:6:\"colPos\";s:2:\"10\";s:7:\"colspan\";s:1:\"4\";}s:2:\"2.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer2\";s:6:\"colPos\";s:2:\"11\";s:7:\"colspan\";s:1:\"4\";}s:2:\"3.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer3\";s:6:\"colPos\";s:2:\"12\";s:7:\"colspan\";s:1:\"4\";}}}}}}s:4:\"icon\";s:73:\"EXT:bootstrap_package/Resources/Public/Icons/BackendLayouts/3_columns.svg\";}s:8:\"default.\";a:3:{s:5:\"title\";s:87:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.default\";s:7:\"config.\";a:1:{s:15:\"backend_layout.\";a:3:{s:8:\"colCount\";s:2:\"12\";s:8:\"rowCount\";s:1:\"5\";s:5:\"rows.\";a:5:{s:2:\"1.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.border\";s:6:\"colPos\";s:1:\"3\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"2.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:100:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentbefore\";s:6:\"colPos\";s:1:\"8\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"3.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.normal\";s:6:\"colPos\";s:1:\"0\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"4.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:99:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentafter\";s:6:\"colPos\";s:1:\"9\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"5.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer1\";s:6:\"colPos\";s:2:\"10\";s:7:\"colspan\";s:1:\"4\";}s:2:\"2.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer2\";s:6:\"colPos\";s:2:\"11\";s:7:\"colspan\";s:1:\"4\";}s:2:\"3.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer3\";s:6:\"colPos\";s:2:\"12\";s:7:\"colspan\";s:1:\"4\";}}}}}}s:4:\"icon\";s:71:\"EXT:bootstrap_package/Resources/Public/Icons/BackendLayouts/default.svg\";}s:7:\"simple.\";a:3:{s:5:\"title\";s:86:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.simple\";s:7:\"config.\";a:1:{s:15:\"backend_layout.\";a:3:{s:8:\"colCount\";s:2:\"12\";s:8:\"rowCount\";s:1:\"4\";s:5:\"rows.\";a:4:{s:2:\"1.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.border\";s:6:\"colPos\";s:1:\"3\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"2.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:100:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentbefore\";s:6:\"colPos\";s:1:\"8\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"3.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.normal\";s:6:\"colPos\";s:1:\"0\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"4.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:99:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentafter\";s:6:\"colPos\";s:1:\"9\";s:7:\"colspan\";s:2:\"12\";}}}}}}s:4:\"icon\";s:70:\"EXT:bootstrap_package/Resources/Public/Icons/BackendLayouts/simple.svg\";}s:16:\"special_feature.\";a:3:{s:5:\"title\";s:95:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.special_feature\";s:7:\"config.\";a:1:{s:15:\"backend_layout.\";a:3:{s:8:\"colCount\";s:2:\"12\";s:8:\"rowCount\";s:2:\"10\";s:5:\"rows.\";a:10:{s:2:\"1.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.border\";s:6:\"colPos\";s:1:\"3\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"2.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:100:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentbefore\";s:6:\"colPos\";s:1:\"8\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"3.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.normal\";s:6:\"colPos\";s:1:\"0\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"4.\";a:1:{s:8:\"columns.\";a:2:{s:2:\"1.\";a:3:{s:4:\"name\";s:95:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.special1\";s:6:\"colPos\";s:2:\"30\";s:7:\"colspan\";s:1:\"6\";}s:2:\"2.\";a:3:{s:4:\"name\";s:95:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.special2\";s:6:\"colPos\";s:2:\"31\";s:7:\"colspan\";s:1:\"6\";}}}s:2:\"5.\";a:1:{s:8:\"columns.\";a:2:{s:2:\"1.\";a:3:{s:4:\"name\";s:95:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.special3\";s:6:\"colPos\";s:2:\"32\";s:7:\"colspan\";s:1:\"6\";}s:2:\"2.\";a:3:{s:4:\"name\";s:95:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.special4\";s:6:\"colPos\";s:2:\"33\";s:7:\"colspan\";s:1:\"6\";}}}s:2:\"6.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:92:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.main2\";s:6:\"colPos\";s:1:\"4\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"7.\";a:1:{s:8:\"columns.\";a:2:{s:2:\"1.\";a:3:{s:4:\"name\";s:95:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.special5\";s:6:\"colPos\";s:2:\"34\";s:7:\"colspan\";s:1:\"6\";}s:2:\"2.\";a:3:{s:4:\"name\";s:95:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.special6\";s:6:\"colPos\";s:2:\"35\";s:7:\"colspan\";s:1:\"6\";}}}s:2:\"8.\";a:1:{s:8:\"columns.\";a:2:{s:2:\"1.\";a:3:{s:4:\"name\";s:95:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.special7\";s:6:\"colPos\";s:2:\"36\";s:7:\"colspan\";s:1:\"6\";}s:2:\"2.\";a:3:{s:4:\"name\";s:95:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.special8\";s:6:\"colPos\";s:2:\"37\";s:7:\"colspan\";s:1:\"6\";}}}s:2:\"9.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:99:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentafter\";s:6:\"colPos\";s:1:\"9\";s:7:\"colspan\";s:2:\"12\";}}}s:3:\"10.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer1\";s:6:\"colPos\";s:2:\"10\";s:7:\"colspan\";s:1:\"4\";}s:2:\"2.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer2\";s:6:\"colPos\";s:2:\"11\";s:7:\"colspan\";s:1:\"4\";}s:2:\"3.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer3\";s:6:\"colPos\";s:2:\"12\";s:7:\"colspan\";s:1:\"4\";}}}}}}s:4:\"icon\";s:79:\"EXT:bootstrap_package/Resources/Public/Icons/BackendLayouts/special_feature.svg\";}s:14:\"special_start.\";a:3:{s:5:\"title\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.special_start\";s:7:\"config.\";a:1:{s:15:\"backend_layout.\";a:3:{s:8:\"colCount\";s:2:\"12\";s:8:\"rowCount\";s:1:\"6\";s:5:\"rows.\";a:6:{s:2:\"1.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.border\";s:6:\"colPos\";s:1:\"3\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"2.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:100:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentbefore\";s:6:\"colPos\";s:1:\"8\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"3.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.middle1\";s:6:\"colPos\";s:2:\"20\";s:7:\"colspan\";s:1:\"4\";}s:2:\"2.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.middle2\";s:6:\"colPos\";s:2:\"21\";s:7:\"colspan\";s:1:\"4\";}s:2:\"3.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.middle3\";s:6:\"colPos\";s:2:\"22\";s:7:\"colspan\";s:1:\"4\";}}}s:2:\"4.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.normal\";s:6:\"colPos\";s:1:\"0\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"5.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:99:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentafter\";s:6:\"colPos\";s:1:\"9\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"6.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer1\";s:6:\"colPos\";s:2:\"10\";s:7:\"colspan\";s:1:\"4\";}s:2:\"2.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer2\";s:6:\"colPos\";s:2:\"11\";s:7:\"colspan\";s:1:\"4\";}s:2:\"3.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer3\";s:6:\"colPos\";s:2:\"12\";s:7:\"colspan\";s:1:\"4\";}}}}}}s:4:\"icon\";s:77:\"EXT:bootstrap_package/Resources/Public/Icons/BackendLayouts/special_start.svg\";}s:19:\"subnavigation_left.\";a:3:{s:5:\"title\";s:98:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.subnavigation_left\";s:7:\"config.\";a:1:{s:15:\"backend_layout.\";a:3:{s:8:\"colCount\";s:2:\"12\";s:8:\"rowCount\";s:1:\"5\";s:5:\"rows.\";a:5:{s:2:\"1.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.border\";s:6:\"colPos\";s:1:\"3\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"2.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:100:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentbefore\";s:6:\"colPos\";s:1:\"8\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"3.\";a:1:{s:8:\"columns.\";a:2:{s:2:\"1.\";a:2:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.subnav\";s:7:\"colspan\";s:1:\"3\";}s:2:\"2.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.normal\";s:6:\"colPos\";s:1:\"0\";s:7:\"colspan\";s:1:\"9\";}}}s:2:\"4.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:99:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentafter\";s:6:\"colPos\";s:1:\"9\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"5.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer1\";s:6:\"colPos\";s:2:\"10\";s:7:\"colspan\";s:1:\"4\";}s:2:\"2.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer2\";s:6:\"colPos\";s:2:\"11\";s:7:\"colspan\";s:1:\"4\";}s:2:\"3.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer3\";s:6:\"colPos\";s:2:\"12\";s:7:\"colspan\";s:1:\"4\";}}}}}}s:4:\"icon\";s:82:\"EXT:bootstrap_package/Resources/Public/Icons/BackendLayouts/subnavigation_left.svg\";}s:29:\"subnavigation_left_2_columns.\";a:3:{s:5:\"title\";s:108:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.subnavigation_left_2_columns\";s:7:\"config.\";a:1:{s:15:\"backend_layout.\";a:3:{s:8:\"colCount\";s:2:\"12\";s:8:\"rowCount\";s:1:\"5\";s:5:\"rows.\";a:5:{s:2:\"1.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.border\";s:6:\"colPos\";s:1:\"3\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"2.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:100:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentbefore\";s:6:\"colPos\";s:1:\"8\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"3.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:2:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.subnav\";s:7:\"colspan\";s:1:\"3\";}s:2:\"2.\";a:3:{s:4:\"name\";s:91:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.left\";s:6:\"colPos\";s:1:\"1\";s:7:\"colspan\";s:1:\"3\";}s:2:\"3.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.normal\";s:6:\"colPos\";s:1:\"0\";s:7:\"colspan\";s:1:\"6\";}}}s:2:\"4.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:99:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentafter\";s:6:\"colPos\";s:1:\"9\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"5.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer1\";s:6:\"colPos\";s:2:\"10\";s:7:\"colspan\";s:1:\"4\";}s:2:\"2.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer2\";s:6:\"colPos\";s:2:\"11\";s:7:\"colspan\";s:1:\"4\";}s:2:\"3.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer3\";s:6:\"colPos\";s:2:\"12\";s:7:\"colspan\";s:1:\"4\";}}}}}}s:4:\"icon\";s:92:\"EXT:bootstrap_package/Resources/Public/Icons/BackendLayouts/subnavigation_left_2_columns.svg\";}s:20:\"subnavigation_right.\";a:3:{s:5:\"title\";s:99:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.subnavigation_right\";s:7:\"config.\";a:1:{s:15:\"backend_layout.\";a:3:{s:8:\"colCount\";s:2:\"12\";s:8:\"rowCount\";s:1:\"5\";s:5:\"rows.\";a:5:{s:2:\"1.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.border\";s:6:\"colPos\";s:1:\"3\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"2.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:100:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentbefore\";s:6:\"colPos\";s:1:\"8\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"3.\";a:1:{s:8:\"columns.\";a:2:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.normal\";s:6:\"colPos\";s:1:\"0\";s:7:\"colspan\";s:1:\"9\";}s:2:\"2.\";a:2:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.subnav\";s:7:\"colspan\";s:1:\"3\";}}}s:2:\"4.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:99:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentafter\";s:6:\"colPos\";s:1:\"9\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"5.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer1\";s:6:\"colPos\";s:2:\"10\";s:7:\"colspan\";s:1:\"4\";}s:2:\"2.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer2\";s:6:\"colPos\";s:2:\"11\";s:7:\"colspan\";s:1:\"4\";}s:2:\"3.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer3\";s:6:\"colPos\";s:2:\"12\";s:7:\"colspan\";s:1:\"4\";}}}}}}s:4:\"icon\";s:83:\"EXT:bootstrap_package/Resources/Public/Icons/BackendLayouts/subnavigation_right.svg\";}s:30:\"subnavigation_right_2_columns.\";a:3:{s:5:\"title\";s:109:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.subnavigation_right_2_columns\";s:7:\"config.\";a:1:{s:15:\"backend_layout.\";a:3:{s:8:\"colCount\";s:2:\"12\";s:8:\"rowCount\";s:1:\"5\";s:5:\"rows.\";a:5:{s:2:\"1.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.border\";s:6:\"colPos\";s:1:\"3\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"2.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:100:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentbefore\";s:6:\"colPos\";s:1:\"8\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"3.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.normal\";s:6:\"colPos\";s:1:\"0\";s:7:\"colspan\";s:1:\"6\";}s:2:\"2.\";a:3:{s:4:\"name\";s:92:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.right\";s:6:\"colPos\";s:1:\"2\";s:7:\"colspan\";s:1:\"3\";}s:2:\"3.\";a:2:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.subnav\";s:7:\"colspan\";s:1:\"3\";}}}s:2:\"4.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:99:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentafter\";s:6:\"colPos\";s:1:\"9\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"5.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer1\";s:6:\"colPos\";s:2:\"10\";s:7:\"colspan\";s:1:\"4\";}s:2:\"2.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer2\";s:6:\"colPos\";s:2:\"11\";s:7:\"colspan\";s:1:\"4\";}s:2:\"3.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer3\";s:6:\"colPos\";s:2:\"12\";s:7:\"colspan\";s:1:\"4\";}}}}}}s:4:\"icon\";s:93:\"EXT:bootstrap_package/Resources/Public/Icons/BackendLayouts/subnavigation_right_2_columns.svg\";}s:8:\"example.\";a:3:{s:5:\"title\";s:89:\"LLL:EXT:my_sitepackage/Resources/Private/Language/locallang_be.xlf:backend_layout.example\";s:7:\"config.\";a:1:{s:15:\"backend_layout.\";a:3:{s:8:\"colCount\";s:1:\"1\";s:8:\"rowCount\";s:1:\"1\";s:5:\"rows.\";a:1:{s:2:\"1.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:2:{s:4:\"name\";s:95:\"LLL:EXT:my_sitepackage/Resources/Private/Language/locallang_be.xlf:backend_layout.column.normal\";s:6:\"colPos\";s:1:\"0\";}}}}}}s:4:\"icon\";s:68:\"EXT:my_sitepackage/Resources/Public/Icons/BackendLayouts/example.svg\";}}}}s:8:\"TCEMAIN.\";a:3:{s:18:\"translateToMessage\";s:16:\"Translate to %s:\";s:12:\"linkHandler.\";a:6:{s:5:\"page.\";a:2:{s:7:\"handler\";s:48:\"TYPO3\\CMS\\Recordlist\\LinkHandler\\PageLinkHandler\";s:5:\"label\";s:77:\"LLL:EXT:recordlist/Resources/Private/Language/locallang_browse_links.xlf:page\";}s:5:\"file.\";a:4:{s:7:\"handler\";s:48:\"TYPO3\\CMS\\Recordlist\\LinkHandler\\FileLinkHandler\";s:5:\"label\";s:77:\"LLL:EXT:recordlist/Resources/Private/Language/locallang_browse_links.xlf:file\";s:12:\"displayAfter\";s:4:\"page\";s:9:\"scanAfter\";s:4:\"page\";}s:7:\"folder.\";a:4:{s:7:\"handler\";s:50:\"TYPO3\\CMS\\Recordlist\\LinkHandler\\FolderLinkHandler\";s:5:\"label\";s:79:\"LLL:EXT:recordlist/Resources/Private/Language/locallang_browse_links.xlf:folder\";s:12:\"displayAfter\";s:9:\"page,file\";s:9:\"scanAfter\";s:9:\"page,file\";}s:4:\"url.\";a:4:{s:7:\"handler\";s:47:\"TYPO3\\CMS\\Recordlist\\LinkHandler\\UrlLinkHandler\";s:5:\"label\";s:79:\"LLL:EXT:recordlist/Resources/Private/Language/locallang_browse_links.xlf:extUrl\";s:12:\"displayAfter\";s:16:\"page,file,folder\";s:9:\"scanAfter\";s:9:\"telephone\";}s:5:\"mail.\";a:4:{s:7:\"handler\";s:48:\"TYPO3\\CMS\\Recordlist\\LinkHandler\\MailLinkHandler\";s:5:\"label\";s:78:\"LLL:EXT:recordlist/Resources/Private/Language/locallang_browse_links.xlf:email\";s:12:\"displayAfter\";s:20:\"page,file,folder,url\";s:10:\"scanBefore\";s:3:\"url\";}s:10:\"telephone.\";a:4:{s:7:\"handler\";s:53:\"TYPO3\\CMS\\Recordlist\\LinkHandler\\TelephoneLinkHandler\";s:5:\"label\";s:82:\"LLL:EXT:recordlist/Resources/Private/Language/locallang_browse_links.xlf:telephone\";s:12:\"displayAfter\";s:25:\"page,file,folder,url,mail\";s:10:\"scanBefore\";s:3:\"url\";}}s:12:\"permissions.\";a:4:{s:7:\"groupid\";s:1:\"1\";s:4:\"user\";s:36:\"show, editcontent, edit, new, delete\";s:5:\"group\";s:36:\"show, editcontent, edit, new, delete\";s:9:\"everybody\";s:0:\"\";}}s:8:\"TCEFORM.\";a:2:{s:11:\"tt_content.\";a:10:{s:12:\"imageorient.\";a:2:{s:6:\"types.\";a:2:{s:6:\"image.\";a:2:{s:11:\"removeItems\";s:18:\"8,9,10,17,18,25,26\";s:8:\"disabled\";s:1:\"1\";}s:6:\"media.\";a:1:{s:8:\"disabled\";s:1:\"1\";}}s:11:\"removeItems\";s:14:\"1,2,9,10,17,18\";}s:14:\"header_layout.\";a:1:{s:10:\"altLabels.\";a:5:{i:1;s:2:\"H1\";i:2;s:2:\"H2\";i:3;s:2:\"H3\";i:4;s:2:\"H4\";i:5;s:2:\"H5\";}}s:7:\"layout.\";a:3:{s:11:\"removeItems\";s:5:\"1,2,3\";s:29:\"disableNoMatchingValueElement\";s:1:\"1\";s:6:\"types.\";a:1:{s:8:\"uploads.\";a:2:{s:11:\"removeItems\";s:1:\"3\";s:10:\"altLabels.\";a:3:{i:0;s:86:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:uploadslayout.default\";i:1;s:84:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:uploadslayout.icons\";i:2;s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:uploadslayout.iconsandpreview\";}}}}s:12:\"table_class.\";a:1:{s:9:\"addItems.\";a:2:{s:5:\"hover\";s:82:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:tablelayout.hover\";s:9:\"condensed\";s:86:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:tablelayout.condensed\";}}s:12:\"imageborder.\";a:1:{s:8:\"disabled\";s:1:\"1\";}s:10:\"imagecols.\";a:1:{s:11:\"removeItems\";s:3:\"7,8\";}s:11:\"image_zoom.\";a:1:{s:6:\"types.\";a:1:{s:6:\"media.\";a:1:{s:8:\"disabled\";s:1:\"1\";}}}s:20:\"accessibility_title.\";a:1:{s:8:\"disabled\";s:1:\"1\";}s:12:\"imageheight.\";a:1:{s:8:\"disabled\";s:1:\"1\";}s:11:\"imagewidth.\";a:1:{s:8:\"disabled\";s:1:\"1\";}}s:6:\"pages.\";a:1:{s:7:\"layout.\";a:1:{s:11:\"removeItems\";s:5:\"1,2,3\";}}}s:4:\"RTE.\";a:1:{s:8:\"default.\";a:1:{s:6:\"preset\";s:14:\"my_sitepackage\";}}s:12:\"TCAdefaults.\";a:1:{s:11:\"tt_content.\";a:1:{s:9:\"imagecols\";s:1:\"1\";}}}s:8:\"sections\";a:0:{}s:5:\"match\";a:0:{}}i:1;s:32:\"f8342b40331360151d86fdd2df88e47a\";}'),(8,'989101fd1e8a9bdb09b1375f9ebe9e55',2145909600,'a:2:{i:0;a:3:{s:8:\"TSconfig\";a:5:{s:4:\"mod.\";a:5:{s:9:\"web_list.\";a:4:{s:28:\"enableDisplayBigControlPanel\";s:10:\"selectable\";s:15:\"enableClipBoard\";s:10:\"selectable\";s:18:\"tableDisplayOrder.\";a:9:{s:9:\"be_users.\";a:1:{s:5:\"after\";s:9:\"be_groups\";}s:15:\"sys_filemounts.\";a:1:{s:5:\"after\";s:8:\"be_users\";}s:17:\"sys_file_storage.\";a:1:{s:5:\"after\";s:14:\"sys_filemounts\";}s:13:\"sys_language.\";a:1:{s:5:\"after\";s:16:\"sys_file_storage\";}s:9:\"fe_users.\";a:2:{s:5:\"after\";s:9:\"fe_groups\";s:6:\"before\";s:5:\"pages\";}s:13:\"sys_template.\";a:1:{s:5:\"after\";s:5:\"pages\";}s:15:\"backend_layout.\";a:1:{s:5:\"after\";s:5:\"pages\";}s:11:\"tt_content.\";a:1:{s:5:\"after\";s:33:\"pages,backend_layout,sys_template\";}s:13:\"sys_category.\";a:1:{s:5:\"after\";s:10:\"tt_content\";}}s:12:\"searchLevel.\";a:1:{s:6:\"items.\";a:6:{i:-1;s:82:\"EXT:core/Resources/Private/Language/locallang_core.xlf:labels.searchLevel.infinite\";i:0;s:75:\"EXT:core/Resources/Private/Language/locallang_core.xlf:labels.searchLevel.0\";i:1;s:75:\"EXT:core/Resources/Private/Language/locallang_core.xlf:labels.searchLevel.1\";i:2;s:75:\"EXT:core/Resources/Private/Language/locallang_core.xlf:labels.searchLevel.2\";i:3;s:75:\"EXT:core/Resources/Private/Language/locallang_core.xlf:labels.searchLevel.3\";i:4;s:75:\"EXT:core/Resources/Private/Language/locallang_core.xlf:labels.searchLevel.4\";}}}s:8:\"wizards.\";a:2:{s:10:\"newRecord.\";a:1:{s:6:\"pages.\";a:1:{s:5:\"show.\";a:3:{s:10:\"pageInside\";s:1:\"1\";s:9:\"pageAfter\";s:1:\"1\";s:18:\"pageSelectPosition\";s:1:\"1\";}}}s:18:\"newContentElement.\";a:1:{s:12:\"wizardItems.\";a:10:{s:7:\"common.\";a:3:{s:9:\"elements.\";a:8:{s:7:\"header.\";a:4:{s:14:\"iconIdentifier\";s:14:\"content-header\";s:5:\"title\";s:98:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_headerOnly_title\";s:11:\"description\";s:104:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_headerOnly_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:6:\"header\";}}s:5:\"text.\";a:4:{s:14:\"iconIdentifier\";s:12:\"content-text\";s:5:\"title\";s:99:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_regularText_title\";s:11:\"description\";s:105:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_regularText_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:4:\"text\";}}s:8:\"textpic.\";a:4:{s:14:\"iconIdentifier\";s:15:\"content-textpic\";s:5:\"title\";s:97:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_textImage_title\";s:11:\"description\";s:103:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_textImage_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:7:\"textpic\";}}s:6:\"image.\";a:4:{s:14:\"iconIdentifier\";s:13:\"content-image\";s:5:\"title\";s:98:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_imagesOnly_title\";s:11:\"description\";s:104:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_imagesOnly_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:5:\"image\";}}s:10:\"textmedia.\";a:4:{s:14:\"iconIdentifier\";s:17:\"content-textmedia\";s:5:\"title\";s:97:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_textMedia_title\";s:11:\"description\";s:103:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_textMedia_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:9:\"textmedia\";}}s:8:\"bullets.\";a:4:{s:14:\"iconIdentifier\";s:15:\"content-bullets\";s:5:\"title\";s:98:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_bulletList_title\";s:11:\"description\";s:104:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_bulletList_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:7:\"bullets\";}}s:6:\"table.\";a:4:{s:14:\"iconIdentifier\";s:13:\"content-table\";s:5:\"title\";s:93:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_table_title\";s:11:\"description\";s:99:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_table_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:5:\"table\";}}s:8:\"uploads.\";a:4:{s:14:\"iconIdentifier\";s:23:\"content-special-uploads\";s:5:\"title\";s:98:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:special_filelinks_title\";s:11:\"description\";s:104:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:special_filelinks_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:7:\"uploads\";}}}s:4:\"show\";s:57:\"header,text,textpic,image,textmedia,bullets,table,uploads\";s:6:\"header\";s:81:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common\";}s:5:\"menu.\";a:3:{s:9:\"elements.\";a:15:{s:14:\"menu_abstract.\";a:4:{s:14:\"iconIdentifier\";s:21:\"content-menu-abstract\";s:5:\"title\";s:94:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_abstract.title\";s:11:\"description\";s:100:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_abstract.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:13:\"menu_abstract\";}}s:25:\"menu_categorized_content.\";a:4:{s:14:\"iconIdentifier\";s:24:\"content-menu-categorized\";s:5:\"title\";s:105:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_categorized_content.title\";s:11:\"description\";s:111:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_categorized_content.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:24:\"menu_categorized_content\";}}s:23:\"menu_categorized_pages.\";a:4:{s:14:\"iconIdentifier\";s:24:\"content-menu-categorized\";s:5:\"title\";s:103:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_categorized_pages.title\";s:11:\"description\";s:109:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_categorized_pages.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:22:\"menu_categorized_pages\";}}s:11:\"menu_pages.\";a:4:{s:14:\"iconIdentifier\";s:18:\"content-menu-pages\";s:5:\"title\";s:91:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_pages.title\";s:11:\"description\";s:97:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_pages.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:10:\"menu_pages\";}}s:14:\"menu_subpages.\";a:4:{s:14:\"iconIdentifier\";s:18:\"content-menu-pages\";s:5:\"title\";s:94:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_subpages.title\";s:11:\"description\";s:100:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_subpages.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:13:\"menu_subpages\";}}s:22:\"menu_recently_updated.\";a:4:{s:14:\"iconIdentifier\";s:29:\"content-menu-recently-updated\";s:5:\"title\";s:102:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_recently_updated.title\";s:11:\"description\";s:108:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_recently_updated.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:21:\"menu_recently_updated\";}}s:19:\"menu_related_pages.\";a:4:{s:14:\"iconIdentifier\";s:20:\"content-menu-related\";s:5:\"title\";s:99:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_related_pages.title\";s:11:\"description\";s:105:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_related_pages.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:18:\"menu_related_pages\";}}s:13:\"menu_section.\";a:4:{s:14:\"iconIdentifier\";s:20:\"content-menu-section\";s:5:\"title\";s:93:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_section.title\";s:11:\"description\";s:99:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_section.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:12:\"menu_section\";}}s:19:\"menu_section_pages.\";a:4:{s:14:\"iconIdentifier\";s:20:\"content-menu-section\";s:5:\"title\";s:99:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_section_pages.title\";s:11:\"description\";s:105:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_section_pages.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:18:\"menu_section_pages\";}}s:13:\"menu_sitemap.\";a:4:{s:14:\"iconIdentifier\";s:20:\"content-menu-sitemap\";s:5:\"title\";s:93:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_sitemap.title\";s:11:\"description\";s:99:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_sitemap.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:12:\"menu_sitemap\";}}s:19:\"menu_sitemap_pages.\";a:4:{s:14:\"iconIdentifier\";s:26:\"content-menu-sitemap-pages\";s:5:\"title\";s:99:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_sitemap_pages.title\";s:11:\"description\";s:105:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu_sitemap_pages.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:18:\"menu_sitemap_pages\";}}s:14:\"menu_card_dir.\";a:4:{s:14:\"iconIdentifier\";s:34:\"content-bootstrappackage-menu-card\";s:5:\"title\";s:78:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:menu.card_dir\";s:11:\"description\";s:90:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:menu.card_dir.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:13:\"menu_card_dir\";}}s:15:\"menu_card_list.\";a:4:{s:14:\"iconIdentifier\";s:34:\"content-bootstrappackage-menu-card\";s:5:\"title\";s:79:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:menu.card_list\";s:11:\"description\";s:91:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:menu.card_list.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:14:\"menu_card_list\";}}s:19:\"menu_thumbnail_dir.\";a:4:{s:14:\"iconIdentifier\";s:22:\"content-menu-thumbnail\";s:5:\"title\";s:83:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:menu.thumbnail_dir\";s:11:\"description\";s:95:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:menu.thumbnail_dir.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:18:\"menu_thumbnail_dir\";}}s:20:\"menu_thumbnail_list.\";a:4:{s:14:\"iconIdentifier\";s:22:\"content-menu-thumbnail\";s:5:\"title\";s:84:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:menu.thumbnail_list\";s:11:\"description\";s:96:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:menu.thumbnail_list.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:19:\"menu_thumbnail_list\";}}}s:4:\"show\";s:259:\"menu_abstract,menu_categorized_content,menu_categorized_pages,menu_pages,menu_subpages,menu_recently_updated,menu_related_pages,menu_section,menu_section_pages,menu_sitemap,menu_sitemap_pages,menu_card_dir,menu_card_list,menu_thumbnail_dir,menu_thumbnail_list\";s:6:\"header\";s:79:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:menu\";}s:8:\"special.\";a:3:{s:9:\"elements.\";a:3:{s:5:\"html.\";a:4:{s:14:\"iconIdentifier\";s:20:\"content-special-html\";s:5:\"title\";s:98:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:special_plainHTML_title\";s:11:\"description\";s:104:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:special_plainHTML_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:4:\"html\";}}s:4:\"div.\";a:5:{s:14:\"iconIdentifier\";s:19:\"content-special-div\";s:5:\"title\";s:96:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:special_divider_title\";s:11:\"description\";s:102:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:special_divider_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:3:\"div\";}s:12:\"saveAndClose\";s:4:\"true\";}s:9:\"shortcut.\";a:4:{s:14:\"iconIdentifier\";s:24:\"content-special-shortcut\";s:5:\"title\";s:97:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:special_shortcut_title\";s:11:\"description\";s:103:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:special_shortcut_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:8:\"shortcut\";}}}s:4:\"show\";s:17:\"html,div,shortcut\";s:6:\"header\";s:82:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:special\";}s:6:\"forms.\";a:3:{s:4:\"show\";s:27:\"formframework,felogin_login\";s:9:\"elements.\";a:2:{s:14:\"formframework.\";a:4:{s:14:\"iconIdentifier\";s:12:\"content-form\";s:5:\"title\";s:75:\"LLL:EXT:form/Resources/Private/Language/locallang.xlf:form_new_wizard_title\";s:11:\"description\";s:77:\"LLL:EXT:form/Resources/Private/Language/locallang:form_new_wizard_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:18:\"form_formframework\";}}s:14:\"felogin_login.\";a:4:{s:14:\"iconIdentifier\";s:22:\"content-elements-login\";s:5:\"title\";s:92:\"LLL:EXT:felogin/Resources/Private/Language/Database.xlf:tt_content.CType.felogin_login.title\";s:11:\"description\";s:98:\"LLL:EXT:felogin/Resources/Private/Language/Database.xlf:tt_content.CType.felogin_login.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:13:\"felogin_login\";}}}s:6:\"header\";s:80:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:forms\";}s:8:\"plugins.\";a:3:{s:6:\"header\";s:82:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:plugins\";s:9:\"elements.\";a:1:{s:8:\"general.\";a:4:{s:14:\"iconIdentifier\";s:14:\"content-plugin\";s:5:\"title\";s:96:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:plugins_general_title\";s:11:\"description\";s:102:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:plugins_general_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:4:\"list\";}}}s:4:\"show\";s:1:\"*\";}s:12:\"interactive.\";a:3:{s:6:\"header\";s:90:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_group.interactive\";s:9:\"elements.\";a:5:{s:10:\"accordion.\";a:4:{s:14:\"iconIdentifier\";s:34:\"content-bootstrappackage-accordion\";s:5:\"title\";s:90:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.accordion\";s:11:\"description\";s:102:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.accordion.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:9:\"accordion\";}}s:9:\"carousel.\";a:4:{s:14:\"iconIdentifier\";s:33:\"content-bootstrappackage-carousel\";s:5:\"title\";s:89:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.carousel\";s:11:\"description\";s:101:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.carousel.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:8:\"carousel\";}}s:20:\"carousel_fullscreen.\";a:4:{s:14:\"iconIdentifier\";s:33:\"content-bootstrappackage-carousel\";s:5:\"title\";s:100:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.carousel_fullscreen\";s:11:\"description\";s:112:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.carousel_fullscreen.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:19:\"carousel_fullscreen\";}}s:15:\"carousel_small.\";a:4:{s:14:\"iconIdentifier\";s:33:\"content-bootstrappackage-carousel\";s:5:\"title\";s:95:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.carousel_small\";s:11:\"description\";s:107:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.carousel_small.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:14:\"carousel_small\";}}s:9:\"timeline.\";a:4:{s:14:\"iconIdentifier\";s:33:\"content-bootstrappackage-timeline\";s:5:\"title\";s:89:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.timeline\";s:11:\"description\";s:101:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.timeline.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:8:\"timeline\";}}}s:4:\"show\";s:62:\"accordion,carousel,carousel_fullscreen,carousel_small,timeline\";}s:6:\"media.\";a:3:{s:6:\"header\";s:84:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_group.media\";s:9:\"elements.\";a:11:{s:6:\"audio.\";a:4:{s:14:\"iconIdentifier\";s:13:\"content-audio\";s:5:\"title\";s:86:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.audio\";s:11:\"description\";s:98:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.audio.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:5:\"audio\";}}s:11:\"card_group.\";a:4:{s:14:\"iconIdentifier\";s:35:\"content-bootstrappackage-card-group\";s:5:\"title\";s:91:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.card_group\";s:11:\"description\";s:103:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.card_group.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:10:\"card_group\";}}s:15:\"external_media.\";a:4:{s:14:\"iconIdentifier\";s:38:\"content-bootstrappackage-externalmedia\";s:5:\"title\";s:95:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.external_media\";s:11:\"description\";s:107:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.external_media.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:14:\"external_media\";}}s:8:\"gallery.\";a:4:{s:14:\"iconIdentifier\";s:32:\"content-bootstrappackage-gallery\";s:5:\"title\";s:88:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.gallery\";s:11:\"description\";s:100:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.gallery.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:7:\"gallery\";}}s:11:\"icon_group.\";a:4:{s:14:\"iconIdentifier\";s:35:\"content-bootstrappackage-icon-group\";s:5:\"title\";s:91:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.icon_group\";s:11:\"description\";s:103:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.icon_group.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:10:\"icon_group\";}}s:6:\"image.\";a:4:{s:14:\"iconIdentifier\";s:13:\"content-image\";s:5:\"title\";s:98:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_imagesOnly_title\";s:11:\"description\";s:104:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_imagesOnly_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:5:\"image\";}}s:6:\"media.\";a:4:{s:14:\"iconIdentifier\";s:30:\"mimetypes-x-content-multimedia\";s:5:\"title\";s:86:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.media\";s:11:\"description\";s:98:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.media.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:5:\"media\";}}s:4:\"tab.\";a:4:{s:14:\"iconIdentifier\";s:28:\"content-bootstrappackage-tab\";s:5:\"title\";s:84:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.tab\";s:11:\"description\";s:96:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.tab.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:3:\"tab\";}}s:10:\"textmedia.\";a:4:{s:14:\"iconIdentifier\";s:17:\"content-textmedia\";s:5:\"title\";s:97:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_textMedia_title\";s:11:\"description\";s:103:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_textMedia_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:9:\"textmedia\";}}s:8:\"textpic.\";a:4:{s:14:\"iconIdentifier\";s:15:\"content-textpic\";s:5:\"title\";s:97:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_textImage_title\";s:11:\"description\";s:103:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_textImage_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:7:\"textpic\";}}s:8:\"uploads.\";a:4:{s:14:\"iconIdentifier\";s:23:\"content-special-uploads\";s:5:\"title\";s:98:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:special_filelinks_title\";s:11:\"description\";s:104:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:special_filelinks_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:7:\"uploads\";}}}s:4:\"show\";s:92:\"audio,card_group,external_media,gallery,icon_group,image,media,tab,textmedia,textpic,uploads\";}s:5:\"text.\";a:3:{s:6:\"header\";s:83:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_group.text\";s:9:\"elements.\";a:13:{s:8:\"bullets.\";a:4:{s:14:\"iconIdentifier\";s:15:\"content-bullets\";s:5:\"title\";s:98:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_bulletList_title\";s:11:\"description\";s:104:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_bulletList_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:7:\"bullets\";}}s:11:\"card_group.\";a:4:{s:14:\"iconIdentifier\";s:35:\"content-bootstrappackage-card-group\";s:5:\"title\";s:91:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.card_group\";s:11:\"description\";s:103:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.card_group.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:10:\"card_group\";}}s:7:\"header.\";a:4:{s:14:\"iconIdentifier\";s:14:\"content-header\";s:5:\"title\";s:98:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_headerOnly_title\";s:11:\"description\";s:104:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_headerOnly_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:6:\"header\";}}s:10:\"listgroup.\";a:4:{s:14:\"iconIdentifier\";s:34:\"content-bootstrappackage-listgroup\";s:5:\"title\";s:90:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.listgroup\";s:11:\"description\";s:102:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.listgroup.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:9:\"listgroup\";}}s:6:\"panel.\";a:4:{s:14:\"iconIdentifier\";s:13:\"content-panel\";s:5:\"title\";s:86:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.panel\";s:11:\"description\";s:98:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.panel.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:5:\"panel\";}}s:6:\"quote.\";a:4:{s:14:\"iconIdentifier\";s:13:\"content-quote\";s:5:\"title\";s:86:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.quote\";s:11:\"description\";s:98:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.quote.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:5:\"quote\";}}s:6:\"table.\";a:4:{s:14:\"iconIdentifier\";s:13:\"content-table\";s:5:\"title\";s:93:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_table_title\";s:11:\"description\";s:99:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_table_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:5:\"table\";}}s:5:\"text.\";a:4:{s:14:\"iconIdentifier\";s:12:\"content-text\";s:5:\"title\";s:99:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_regularText_title\";s:11:\"description\";s:105:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_regularText_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:4:\"text\";}}s:11:\"textcolumn.\";a:4:{s:14:\"iconIdentifier\";s:20:\"content-text-columns\";s:5:\"title\";s:91:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.textcolumn\";s:11:\"description\";s:103:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.textcolumn.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:10:\"textcolumn\";}}s:9:\"texticon.\";a:4:{s:14:\"iconIdentifier\";s:33:\"content-bootstrappackage-texticon\";s:5:\"title\";s:89:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.texticon\";s:11:\"description\";s:101:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.texticon.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:8:\"texticon\";}}s:10:\"textmedia.\";a:4:{s:14:\"iconIdentifier\";s:17:\"content-textmedia\";s:5:\"title\";s:97:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_textMedia_title\";s:11:\"description\";s:103:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_textMedia_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:9:\"textmedia\";}}s:8:\"textpic.\";a:4:{s:14:\"iconIdentifier\";s:15:\"content-textpic\";s:5:\"title\";s:97:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_textImage_title\";s:11:\"description\";s:103:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_textImage_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:7:\"textpic\";}}s:11:\"textteaser.\";a:4:{s:14:\"iconIdentifier\";s:19:\"content-text-teaser\";s:5:\"title\";s:91:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.textteaser\";s:11:\"description\";s:103:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.textteaser.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:10:\"textteaser\";}}}s:4:\"show\";s:107:\"bullets,card_group,header,listgroup,panel,quote,table,text,textcolumn,texticon,textmedia,textpic,textteaser\";}s:7:\"social.\";a:3:{s:6:\"header\";s:91:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_group.social_media\";s:9:\"elements.\";a:1:{s:13:\"social_links.\";a:4:{s:14:\"iconIdentifier\";s:37:\"content-bootstrappackage-social-links\";s:5:\"title\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.social_links\";s:11:\"description\";s:105:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.social_links.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:12:\"social_links\";}}}s:4:\"show\";s:12:\"social_links\";}s:5:\"data.\";a:3:{s:6:\"header\";s:83:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_group.data\";s:9:\"elements.\";a:2:{s:4:\"csv.\";a:4:{s:14:\"iconIdentifier\";s:28:\"content-bootstrappackage-csv\";s:5:\"title\";s:84:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.csv\";s:11:\"description\";s:96:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:content_element.csv.description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:3:\"csv\";}}s:6:\"table.\";a:4:{s:14:\"iconIdentifier\";s:13:\"content-table\";s:5:\"title\";s:93:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_table_title\";s:11:\"description\";s:99:\"LLL:EXT:backend/Resources/Private/Language/locallang_db_new_content_el.xlf:common_table_description\";s:21:\"tt_content_defValues.\";a:1:{s:5:\"CType\";s:5:\"table\";}}}s:4:\"show\";s:9:\"csv,table\";}}}}s:9:\"web_view.\";a:1:{s:19:\"previewFrameWidths.\";a:12:{s:5:\"1920.\";a:4:{s:5:\"label\";s:66:\"LLL:EXT:viewpage/Resources/Private/Language/locallang.xlf:computer\";s:4:\"type\";s:7:\"desktop\";s:5:\"width\";s:4:\"1920\";s:6:\"height\";s:4:\"1080\";}s:5:\"1366.\";a:4:{s:5:\"label\";s:66:\"LLL:EXT:viewpage/Resources/Private/Language/locallang.xlf:computer\";s:4:\"type\";s:7:\"desktop\";s:5:\"width\";s:4:\"1366\";s:6:\"height\";s:3:\"768\";}s:5:\"1280.\";a:4:{s:5:\"label\";s:66:\"LLL:EXT:viewpage/Resources/Private/Language/locallang.xlf:computer\";s:4:\"type\";s:7:\"desktop\";s:5:\"width\";s:4:\"1280\";s:6:\"height\";s:4:\"1024\";}s:5:\"1024.\";a:4:{s:5:\"label\";s:66:\"LLL:EXT:viewpage/Resources/Private/Language/locallang.xlf:computer\";s:4:\"type\";s:7:\"desktop\";s:5:\"width\";s:4:\"1024\";s:6:\"height\";s:3:\"768\";}s:7:\"nexus7.\";a:4:{s:5:\"label\";s:7:\"Nexus 7\";s:4:\"type\";s:6:\"tablet\";s:5:\"width\";s:3:\"600\";s:6:\"height\";s:3:\"960\";}s:8:\"nexus6p.\";a:4:{s:5:\"label\";s:8:\"Nexus 6P\";s:4:\"type\";s:6:\"mobile\";s:5:\"width\";s:3:\"411\";s:6:\"height\";s:3:\"731\";}s:8:\"ipadpro.\";a:4:{s:5:\"label\";s:8:\"iPad Pro\";s:4:\"type\";s:6:\"tablet\";s:5:\"width\";s:4:\"1024\";s:6:\"height\";s:4:\"1366\";}s:8:\"ipadair.\";a:4:{s:5:\"label\";s:8:\"iPad Air\";s:4:\"type\";s:6:\"tablet\";s:5:\"width\";s:3:\"768\";s:6:\"height\";s:4:\"1024\";}s:12:\"iphone7plus.\";a:4:{s:5:\"label\";s:13:\"iPhone 7 Plus\";s:4:\"type\";s:6:\"mobile\";s:5:\"width\";s:3:\"414\";s:6:\"height\";s:3:\"736\";}s:8:\"iphone6.\";a:4:{s:5:\"label\";s:8:\"iPhone 6\";s:4:\"type\";s:6:\"mobile\";s:5:\"width\";s:3:\"375\";s:6:\"height\";s:3:\"667\";}s:8:\"iphone5.\";a:4:{s:5:\"label\";s:8:\"iPhone 5\";s:4:\"type\";s:6:\"mobile\";s:5:\"width\";s:3:\"320\";s:6:\"height\";s:3:\"568\";}s:8:\"iphone4.\";a:4:{s:5:\"label\";s:8:\"iPhone 4\";s:4:\"type\";s:6:\"mobile\";s:5:\"width\";s:3:\"320\";s:6:\"height\";s:3:\"480\";}}}s:9:\"web_info.\";a:1:{s:17:\"fieldDefinitions.\";a:5:{s:2:\"0.\";a:2:{s:5:\"label\";s:69:\"LLL:EXT:info/Resources/Private/Language/locallang_webinfo.xlf:pages_0\";s:6:\"fields\";s:75:\"title,uid,slug,starttime,endtime,fe_group,target,url,shortcut,shortcut_mode\";}s:2:\"1.\";a:2:{s:5:\"label\";s:69:\"LLL:EXT:info/Resources/Private/Language/locallang_webinfo.xlf:pages_1\";s:6:\"fields\";s:26:\"title,uid,###ALL_TABLES###\";}s:2:\"2.\";a:2:{s:5:\"label\";s:69:\"LLL:EXT:info/Resources/Private/Language/locallang_webinfo.xlf:pages_2\";s:6:\"fields\";s:93:\"title,uid,lastUpdated,newUntil,cache_timeout,php_tree_stop,TSconfig,is_siteroot,fe_login_mode\";}s:4:\"seo.\";a:2:{s:5:\"label\";s:64:\"LLL:EXT:seo/Resources/Private/Language/locallang_webinfo.xlf:seo\";s:6:\"fields\";s:106:\"title,uid,slug,seo_title,description,no_index,no_follow,canonical_link,sitemap_changefreq,sitemap_priority\";}s:13:\"social_media.\";a:2:{s:5:\"label\";s:73:\"LLL:EXT:seo/Resources/Private/Language/locallang_webinfo.xlf:social_media\";s:6:\"fields\";s:67:\"title,uid,og_title,og_description,twitter_title,twitter_description\";}}}s:11:\"web_layout.\";a:2:{s:11:\"tt_content.\";a:1:{s:8:\"preview.\";a:4:{s:3:\"csv\";s:66:\"EXT:bootstrap_package/Resources/Private/Templates/Preview/Csv.html\";s:14:\"external_media\";s:76:\"EXT:bootstrap_package/Resources/Private/Templates/Preview/ExternalMedia.html\";s:9:\"listgroup\";s:72:\"EXT:bootstrap_package/Resources/Private/Templates/Preview/ListGroup.html\";s:5:\"quote\";s:68:\"EXT:bootstrap_package/Resources/Private/Templates/Preview/Quote.html\";}}s:15:\"BackendLayouts.\";a:14:{s:10:\"2_columns.\";a:3:{s:5:\"title\";s:89:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.2_columns\";s:7:\"config.\";a:1:{s:15:\"backend_layout.\";a:3:{s:8:\"colCount\";s:2:\"12\";s:8:\"rowCount\";s:1:\"5\";s:5:\"rows.\";a:5:{s:2:\"1.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.border\";s:6:\"colPos\";s:1:\"3\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"2.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:100:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentbefore\";s:6:\"colPos\";s:1:\"8\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"3.\";a:1:{s:8:\"columns.\";a:2:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.normal\";s:6:\"colPos\";s:1:\"0\";s:7:\"colspan\";s:1:\"8\";}s:2:\"2.\";a:3:{s:4:\"name\";s:92:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.right\";s:6:\"colPos\";s:1:\"2\";s:7:\"colspan\";s:1:\"4\";}}}s:2:\"4.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:99:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentafter\";s:6:\"colPos\";s:1:\"9\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"5.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer1\";s:6:\"colPos\";s:2:\"10\";s:7:\"colspan\";s:1:\"4\";}s:2:\"2.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer2\";s:6:\"colPos\";s:2:\"11\";s:7:\"colspan\";s:1:\"4\";}s:2:\"3.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer3\";s:6:\"colPos\";s:2:\"12\";s:7:\"colspan\";s:1:\"4\";}}}}}}s:4:\"icon\";s:73:\"EXT:bootstrap_package/Resources/Public/Icons/BackendLayouts/2_columns.svg\";}s:16:\"2_columns_25_75.\";a:3:{s:5:\"title\";s:95:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.2_columns_25_75\";s:7:\"config.\";a:1:{s:15:\"backend_layout.\";a:3:{s:8:\"colCount\";s:2:\"12\";s:8:\"rowCount\";s:1:\"5\";s:5:\"rows.\";a:5:{s:2:\"1.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.border\";s:6:\"colPos\";s:1:\"3\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"2.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:100:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentbefore\";s:6:\"colPos\";s:1:\"8\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"3.\";a:1:{s:8:\"columns.\";a:2:{s:2:\"1.\";a:3:{s:4:\"name\";s:91:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.left\";s:6:\"colPos\";s:1:\"1\";s:7:\"colspan\";s:1:\"4\";}s:2:\"2.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.normal\";s:6:\"colPos\";s:1:\"0\";s:7:\"colspan\";s:1:\"8\";}}}s:2:\"4.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:99:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentafter\";s:6:\"colPos\";s:1:\"9\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"5.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer1\";s:6:\"colPos\";s:2:\"10\";s:7:\"colspan\";s:1:\"4\";}s:2:\"2.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer2\";s:6:\"colPos\";s:2:\"11\";s:7:\"colspan\";s:1:\"4\";}s:2:\"3.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer3\";s:6:\"colPos\";s:2:\"12\";s:7:\"colspan\";s:1:\"4\";}}}}}}s:4:\"icon\";s:79:\"EXT:bootstrap_package/Resources/Public/Icons/BackendLayouts/2_columns_25_75.svg\";}s:16:\"2_columns_50_50.\";a:3:{s:5:\"title\";s:95:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.2_columns_50_50\";s:7:\"config.\";a:1:{s:15:\"backend_layout.\";a:3:{s:8:\"colCount\";s:2:\"12\";s:8:\"rowCount\";s:1:\"5\";s:5:\"rows.\";a:5:{s:2:\"1.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.border\";s:6:\"colPos\";s:1:\"3\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"2.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:100:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentbefore\";s:6:\"colPos\";s:1:\"8\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"3.\";a:1:{s:8:\"columns.\";a:2:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.normal\";s:6:\"colPos\";s:1:\"0\";s:7:\"colspan\";s:1:\"6\";}s:2:\"2.\";a:3:{s:4:\"name\";s:92:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.right\";s:6:\"colPos\";s:1:\"2\";s:7:\"colspan\";s:1:\"6\";}}}s:2:\"4.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:99:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentafter\";s:6:\"colPos\";s:1:\"9\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"5.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer1\";s:6:\"colPos\";s:2:\"10\";s:7:\"colspan\";s:1:\"4\";}s:2:\"2.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer2\";s:6:\"colPos\";s:2:\"11\";s:7:\"colspan\";s:1:\"4\";}s:2:\"3.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer3\";s:6:\"colPos\";s:2:\"12\";s:7:\"colspan\";s:1:\"4\";}}}}}}s:4:\"icon\";s:79:\"EXT:bootstrap_package/Resources/Public/Icons/BackendLayouts/2_columns_50_50.svg\";}s:23:\"2_columns_offset_right.\";a:3:{s:5:\"title\";s:102:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.2_columns_offset_right\";s:7:\"config.\";a:1:{s:15:\"backend_layout.\";a:3:{s:8:\"colCount\";s:2:\"12\";s:8:\"rowCount\";s:1:\"5\";s:5:\"rows.\";a:5:{s:2:\"1.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.border\";s:6:\"colPos\";s:1:\"3\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"2.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:100:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentbefore\";s:6:\"colPos\";s:1:\"8\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"3.\";a:1:{s:8:\"columns.\";a:2:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.normal\";s:6:\"colPos\";s:1:\"0\";s:7:\"colspan\";s:1:\"8\";}s:2:\"2.\";a:3:{s:4:\"name\";s:92:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.right\";s:6:\"colPos\";s:1:\"2\";s:7:\"colspan\";s:1:\"4\";}}}s:2:\"4.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:99:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentafter\";s:6:\"colPos\";s:1:\"9\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"5.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer1\";s:6:\"colPos\";s:2:\"10\";s:7:\"colspan\";s:1:\"4\";}s:2:\"2.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer2\";s:6:\"colPos\";s:2:\"11\";s:7:\"colspan\";s:1:\"4\";}s:2:\"3.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer3\";s:6:\"colPos\";s:2:\"12\";s:7:\"colspan\";s:1:\"4\";}}}}}}s:4:\"icon\";s:86:\"EXT:bootstrap_package/Resources/Public/Icons/BackendLayouts/2_columns_offset_right.svg\";}s:10:\"3_columns.\";a:3:{s:5:\"title\";s:89:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.3_columns\";s:7:\"config.\";a:1:{s:15:\"backend_layout.\";a:3:{s:8:\"colCount\";s:2:\"12\";s:8:\"rowCount\";s:1:\"5\";s:5:\"rows.\";a:5:{s:2:\"1.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.border\";s:6:\"colPos\";s:1:\"3\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"2.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:100:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentbefore\";s:6:\"colPos\";s:1:\"8\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"3.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:3:{s:4:\"name\";s:91:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.left\";s:6:\"colPos\";s:1:\"1\";s:7:\"colspan\";s:1:\"3\";}s:2:\"2.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.normal\";s:6:\"colPos\";s:1:\"0\";s:7:\"colspan\";s:1:\"6\";}s:2:\"3.\";a:3:{s:4:\"name\";s:92:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.right\";s:6:\"colPos\";s:1:\"2\";s:7:\"colspan\";s:1:\"3\";}}}s:2:\"4.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:99:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentafter\";s:6:\"colPos\";s:1:\"9\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"5.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer1\";s:6:\"colPos\";s:2:\"10\";s:7:\"colspan\";s:1:\"4\";}s:2:\"2.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer2\";s:6:\"colPos\";s:2:\"11\";s:7:\"colspan\";s:1:\"4\";}s:2:\"3.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer3\";s:6:\"colPos\";s:2:\"12\";s:7:\"colspan\";s:1:\"4\";}}}}}}s:4:\"icon\";s:73:\"EXT:bootstrap_package/Resources/Public/Icons/BackendLayouts/3_columns.svg\";}s:8:\"default.\";a:3:{s:5:\"title\";s:87:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.default\";s:7:\"config.\";a:1:{s:15:\"backend_layout.\";a:3:{s:8:\"colCount\";s:2:\"12\";s:8:\"rowCount\";s:1:\"5\";s:5:\"rows.\";a:5:{s:2:\"1.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.border\";s:6:\"colPos\";s:1:\"3\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"2.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:100:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentbefore\";s:6:\"colPos\";s:1:\"8\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"3.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.normal\";s:6:\"colPos\";s:1:\"0\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"4.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:99:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentafter\";s:6:\"colPos\";s:1:\"9\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"5.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer1\";s:6:\"colPos\";s:2:\"10\";s:7:\"colspan\";s:1:\"4\";}s:2:\"2.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer2\";s:6:\"colPos\";s:2:\"11\";s:7:\"colspan\";s:1:\"4\";}s:2:\"3.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer3\";s:6:\"colPos\";s:2:\"12\";s:7:\"colspan\";s:1:\"4\";}}}}}}s:4:\"icon\";s:71:\"EXT:bootstrap_package/Resources/Public/Icons/BackendLayouts/default.svg\";}s:7:\"simple.\";a:3:{s:5:\"title\";s:86:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.simple\";s:7:\"config.\";a:1:{s:15:\"backend_layout.\";a:3:{s:8:\"colCount\";s:2:\"12\";s:8:\"rowCount\";s:1:\"4\";s:5:\"rows.\";a:4:{s:2:\"1.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.border\";s:6:\"colPos\";s:1:\"3\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"2.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:100:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentbefore\";s:6:\"colPos\";s:1:\"8\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"3.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.normal\";s:6:\"colPos\";s:1:\"0\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"4.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:99:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentafter\";s:6:\"colPos\";s:1:\"9\";s:7:\"colspan\";s:2:\"12\";}}}}}}s:4:\"icon\";s:70:\"EXT:bootstrap_package/Resources/Public/Icons/BackendLayouts/simple.svg\";}s:16:\"special_feature.\";a:3:{s:5:\"title\";s:95:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.special_feature\";s:7:\"config.\";a:1:{s:15:\"backend_layout.\";a:3:{s:8:\"colCount\";s:2:\"12\";s:8:\"rowCount\";s:2:\"10\";s:5:\"rows.\";a:10:{s:2:\"1.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.border\";s:6:\"colPos\";s:1:\"3\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"2.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:100:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentbefore\";s:6:\"colPos\";s:1:\"8\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"3.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.normal\";s:6:\"colPos\";s:1:\"0\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"4.\";a:1:{s:8:\"columns.\";a:2:{s:2:\"1.\";a:3:{s:4:\"name\";s:95:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.special1\";s:6:\"colPos\";s:2:\"30\";s:7:\"colspan\";s:1:\"6\";}s:2:\"2.\";a:3:{s:4:\"name\";s:95:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.special2\";s:6:\"colPos\";s:2:\"31\";s:7:\"colspan\";s:1:\"6\";}}}s:2:\"5.\";a:1:{s:8:\"columns.\";a:2:{s:2:\"1.\";a:3:{s:4:\"name\";s:95:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.special3\";s:6:\"colPos\";s:2:\"32\";s:7:\"colspan\";s:1:\"6\";}s:2:\"2.\";a:3:{s:4:\"name\";s:95:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.special4\";s:6:\"colPos\";s:2:\"33\";s:7:\"colspan\";s:1:\"6\";}}}s:2:\"6.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:92:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.main2\";s:6:\"colPos\";s:1:\"4\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"7.\";a:1:{s:8:\"columns.\";a:2:{s:2:\"1.\";a:3:{s:4:\"name\";s:95:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.special5\";s:6:\"colPos\";s:2:\"34\";s:7:\"colspan\";s:1:\"6\";}s:2:\"2.\";a:3:{s:4:\"name\";s:95:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.special6\";s:6:\"colPos\";s:2:\"35\";s:7:\"colspan\";s:1:\"6\";}}}s:2:\"8.\";a:1:{s:8:\"columns.\";a:2:{s:2:\"1.\";a:3:{s:4:\"name\";s:95:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.special7\";s:6:\"colPos\";s:2:\"36\";s:7:\"colspan\";s:1:\"6\";}s:2:\"2.\";a:3:{s:4:\"name\";s:95:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.special8\";s:6:\"colPos\";s:2:\"37\";s:7:\"colspan\";s:1:\"6\";}}}s:2:\"9.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:99:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentafter\";s:6:\"colPos\";s:1:\"9\";s:7:\"colspan\";s:2:\"12\";}}}s:3:\"10.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer1\";s:6:\"colPos\";s:2:\"10\";s:7:\"colspan\";s:1:\"4\";}s:2:\"2.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer2\";s:6:\"colPos\";s:2:\"11\";s:7:\"colspan\";s:1:\"4\";}s:2:\"3.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer3\";s:6:\"colPos\";s:2:\"12\";s:7:\"colspan\";s:1:\"4\";}}}}}}s:4:\"icon\";s:79:\"EXT:bootstrap_package/Resources/Public/Icons/BackendLayouts/special_feature.svg\";}s:14:\"special_start.\";a:3:{s:5:\"title\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.special_start\";s:7:\"config.\";a:1:{s:15:\"backend_layout.\";a:3:{s:8:\"colCount\";s:2:\"12\";s:8:\"rowCount\";s:1:\"6\";s:5:\"rows.\";a:6:{s:2:\"1.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.border\";s:6:\"colPos\";s:1:\"3\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"2.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:100:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentbefore\";s:6:\"colPos\";s:1:\"8\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"3.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.middle1\";s:6:\"colPos\";s:2:\"20\";s:7:\"colspan\";s:1:\"4\";}s:2:\"2.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.middle2\";s:6:\"colPos\";s:2:\"21\";s:7:\"colspan\";s:1:\"4\";}s:2:\"3.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.middle3\";s:6:\"colPos\";s:2:\"22\";s:7:\"colspan\";s:1:\"4\";}}}s:2:\"4.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.normal\";s:6:\"colPos\";s:1:\"0\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"5.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:99:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentafter\";s:6:\"colPos\";s:1:\"9\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"6.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer1\";s:6:\"colPos\";s:2:\"10\";s:7:\"colspan\";s:1:\"4\";}s:2:\"2.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer2\";s:6:\"colPos\";s:2:\"11\";s:7:\"colspan\";s:1:\"4\";}s:2:\"3.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer3\";s:6:\"colPos\";s:2:\"12\";s:7:\"colspan\";s:1:\"4\";}}}}}}s:4:\"icon\";s:77:\"EXT:bootstrap_package/Resources/Public/Icons/BackendLayouts/special_start.svg\";}s:19:\"subnavigation_left.\";a:3:{s:5:\"title\";s:98:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.subnavigation_left\";s:7:\"config.\";a:1:{s:15:\"backend_layout.\";a:3:{s:8:\"colCount\";s:2:\"12\";s:8:\"rowCount\";s:1:\"5\";s:5:\"rows.\";a:5:{s:2:\"1.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.border\";s:6:\"colPos\";s:1:\"3\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"2.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:100:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentbefore\";s:6:\"colPos\";s:1:\"8\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"3.\";a:1:{s:8:\"columns.\";a:2:{s:2:\"1.\";a:2:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.subnav\";s:7:\"colspan\";s:1:\"3\";}s:2:\"2.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.normal\";s:6:\"colPos\";s:1:\"0\";s:7:\"colspan\";s:1:\"9\";}}}s:2:\"4.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:99:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentafter\";s:6:\"colPos\";s:1:\"9\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"5.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer1\";s:6:\"colPos\";s:2:\"10\";s:7:\"colspan\";s:1:\"4\";}s:2:\"2.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer2\";s:6:\"colPos\";s:2:\"11\";s:7:\"colspan\";s:1:\"4\";}s:2:\"3.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer3\";s:6:\"colPos\";s:2:\"12\";s:7:\"colspan\";s:1:\"4\";}}}}}}s:4:\"icon\";s:82:\"EXT:bootstrap_package/Resources/Public/Icons/BackendLayouts/subnavigation_left.svg\";}s:29:\"subnavigation_left_2_columns.\";a:3:{s:5:\"title\";s:108:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.subnavigation_left_2_columns\";s:7:\"config.\";a:1:{s:15:\"backend_layout.\";a:3:{s:8:\"colCount\";s:2:\"12\";s:8:\"rowCount\";s:1:\"5\";s:5:\"rows.\";a:5:{s:2:\"1.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.border\";s:6:\"colPos\";s:1:\"3\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"2.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:100:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentbefore\";s:6:\"colPos\";s:1:\"8\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"3.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:2:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.subnav\";s:7:\"colspan\";s:1:\"3\";}s:2:\"2.\";a:3:{s:4:\"name\";s:91:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.left\";s:6:\"colPos\";s:1:\"1\";s:7:\"colspan\";s:1:\"3\";}s:2:\"3.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.normal\";s:6:\"colPos\";s:1:\"0\";s:7:\"colspan\";s:1:\"6\";}}}s:2:\"4.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:99:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentafter\";s:6:\"colPos\";s:1:\"9\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"5.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer1\";s:6:\"colPos\";s:2:\"10\";s:7:\"colspan\";s:1:\"4\";}s:2:\"2.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer2\";s:6:\"colPos\";s:2:\"11\";s:7:\"colspan\";s:1:\"4\";}s:2:\"3.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer3\";s:6:\"colPos\";s:2:\"12\";s:7:\"colspan\";s:1:\"4\";}}}}}}s:4:\"icon\";s:92:\"EXT:bootstrap_package/Resources/Public/Icons/BackendLayouts/subnavigation_left_2_columns.svg\";}s:20:\"subnavigation_right.\";a:3:{s:5:\"title\";s:99:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.subnavigation_right\";s:7:\"config.\";a:1:{s:15:\"backend_layout.\";a:3:{s:8:\"colCount\";s:2:\"12\";s:8:\"rowCount\";s:1:\"5\";s:5:\"rows.\";a:5:{s:2:\"1.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.border\";s:6:\"colPos\";s:1:\"3\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"2.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:100:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentbefore\";s:6:\"colPos\";s:1:\"8\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"3.\";a:1:{s:8:\"columns.\";a:2:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.normal\";s:6:\"colPos\";s:1:\"0\";s:7:\"colspan\";s:1:\"9\";}s:2:\"2.\";a:2:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.subnav\";s:7:\"colspan\";s:1:\"3\";}}}s:2:\"4.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:99:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentafter\";s:6:\"colPos\";s:1:\"9\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"5.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer1\";s:6:\"colPos\";s:2:\"10\";s:7:\"colspan\";s:1:\"4\";}s:2:\"2.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer2\";s:6:\"colPos\";s:2:\"11\";s:7:\"colspan\";s:1:\"4\";}s:2:\"3.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer3\";s:6:\"colPos\";s:2:\"12\";s:7:\"colspan\";s:1:\"4\";}}}}}}s:4:\"icon\";s:83:\"EXT:bootstrap_package/Resources/Public/Icons/BackendLayouts/subnavigation_right.svg\";}s:30:\"subnavigation_right_2_columns.\";a:3:{s:5:\"title\";s:109:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.subnavigation_right_2_columns\";s:7:\"config.\";a:1:{s:15:\"backend_layout.\";a:3:{s:8:\"colCount\";s:2:\"12\";s:8:\"rowCount\";s:1:\"5\";s:5:\"rows.\";a:5:{s:2:\"1.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.border\";s:6:\"colPos\";s:1:\"3\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"2.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:100:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentbefore\";s:6:\"colPos\";s:1:\"8\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"3.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:3:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.normal\";s:6:\"colPos\";s:1:\"0\";s:7:\"colspan\";s:1:\"6\";}s:2:\"2.\";a:3:{s:4:\"name\";s:92:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.right\";s:6:\"colPos\";s:1:\"2\";s:7:\"colspan\";s:1:\"3\";}s:2:\"3.\";a:2:{s:4:\"name\";s:93:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.subnav\";s:7:\"colspan\";s:1:\"3\";}}}s:2:\"4.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:3:{s:4:\"name\";s:99:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.contentafter\";s:6:\"colPos\";s:1:\"9\";s:7:\"colspan\";s:2:\"12\";}}}s:2:\"5.\";a:1:{s:8:\"columns.\";a:3:{s:2:\"1.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer1\";s:6:\"colPos\";s:2:\"10\";s:7:\"colspan\";s:1:\"4\";}s:2:\"2.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer2\";s:6:\"colPos\";s:2:\"11\";s:7:\"colspan\";s:1:\"4\";}s:2:\"3.\";a:3:{s:4:\"name\";s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:backend_layout.column.footer3\";s:6:\"colPos\";s:2:\"12\";s:7:\"colspan\";s:1:\"4\";}}}}}}s:4:\"icon\";s:93:\"EXT:bootstrap_package/Resources/Public/Icons/BackendLayouts/subnavigation_right_2_columns.svg\";}s:8:\"example.\";a:3:{s:5:\"title\";s:89:\"LLL:EXT:my_sitepackage/Resources/Private/Language/locallang_be.xlf:backend_layout.example\";s:7:\"config.\";a:1:{s:15:\"backend_layout.\";a:3:{s:8:\"colCount\";s:1:\"1\";s:8:\"rowCount\";s:1:\"1\";s:5:\"rows.\";a:1:{s:2:\"1.\";a:1:{s:8:\"columns.\";a:1:{s:2:\"1.\";a:2:{s:4:\"name\";s:95:\"LLL:EXT:my_sitepackage/Resources/Private/Language/locallang_be.xlf:backend_layout.column.normal\";s:6:\"colPos\";s:1:\"0\";}}}}}}s:4:\"icon\";s:68:\"EXT:my_sitepackage/Resources/Public/Icons/BackendLayouts/example.svg\";}}}}s:8:\"TCEMAIN.\";a:3:{s:18:\"translateToMessage\";s:16:\"Translate to %s:\";s:12:\"linkHandler.\";a:6:{s:5:\"page.\";a:2:{s:7:\"handler\";s:48:\"TYPO3\\CMS\\Recordlist\\LinkHandler\\PageLinkHandler\";s:5:\"label\";s:77:\"LLL:EXT:recordlist/Resources/Private/Language/locallang_browse_links.xlf:page\";}s:5:\"file.\";a:4:{s:7:\"handler\";s:48:\"TYPO3\\CMS\\Recordlist\\LinkHandler\\FileLinkHandler\";s:5:\"label\";s:77:\"LLL:EXT:recordlist/Resources/Private/Language/locallang_browse_links.xlf:file\";s:12:\"displayAfter\";s:4:\"page\";s:9:\"scanAfter\";s:4:\"page\";}s:7:\"folder.\";a:4:{s:7:\"handler\";s:50:\"TYPO3\\CMS\\Recordlist\\LinkHandler\\FolderLinkHandler\";s:5:\"label\";s:79:\"LLL:EXT:recordlist/Resources/Private/Language/locallang_browse_links.xlf:folder\";s:12:\"displayAfter\";s:9:\"page,file\";s:9:\"scanAfter\";s:9:\"page,file\";}s:4:\"url.\";a:4:{s:7:\"handler\";s:47:\"TYPO3\\CMS\\Recordlist\\LinkHandler\\UrlLinkHandler\";s:5:\"label\";s:79:\"LLL:EXT:recordlist/Resources/Private/Language/locallang_browse_links.xlf:extUrl\";s:12:\"displayAfter\";s:16:\"page,file,folder\";s:9:\"scanAfter\";s:9:\"telephone\";}s:5:\"mail.\";a:4:{s:7:\"handler\";s:48:\"TYPO3\\CMS\\Recordlist\\LinkHandler\\MailLinkHandler\";s:5:\"label\";s:78:\"LLL:EXT:recordlist/Resources/Private/Language/locallang_browse_links.xlf:email\";s:12:\"displayAfter\";s:20:\"page,file,folder,url\";s:10:\"scanBefore\";s:3:\"url\";}s:10:\"telephone.\";a:4:{s:7:\"handler\";s:53:\"TYPO3\\CMS\\Recordlist\\LinkHandler\\TelephoneLinkHandler\";s:5:\"label\";s:82:\"LLL:EXT:recordlist/Resources/Private/Language/locallang_browse_links.xlf:telephone\";s:12:\"displayAfter\";s:25:\"page,file,folder,url,mail\";s:10:\"scanBefore\";s:3:\"url\";}}s:12:\"permissions.\";a:4:{s:7:\"groupid\";s:1:\"1\";s:4:\"user\";s:36:\"show, editcontent, edit, new, delete\";s:5:\"group\";s:36:\"show, editcontent, edit, new, delete\";s:9:\"everybody\";s:0:\"\";}}s:8:\"TCEFORM.\";a:2:{s:11:\"tt_content.\";a:10:{s:12:\"imageorient.\";a:2:{s:6:\"types.\";a:2:{s:6:\"image.\";a:2:{s:11:\"removeItems\";s:18:\"8,9,10,17,18,25,26\";s:8:\"disabled\";s:1:\"1\";}s:6:\"media.\";a:1:{s:8:\"disabled\";s:1:\"1\";}}s:11:\"removeItems\";s:14:\"1,2,9,10,17,18\";}s:14:\"header_layout.\";a:1:{s:10:\"altLabels.\";a:5:{i:1;s:2:\"H1\";i:2;s:2:\"H2\";i:3;s:2:\"H3\";i:4;s:2:\"H4\";i:5;s:2:\"H5\";}}s:7:\"layout.\";a:3:{s:11:\"removeItems\";s:5:\"1,2,3\";s:29:\"disableNoMatchingValueElement\";s:1:\"1\";s:6:\"types.\";a:1:{s:8:\"uploads.\";a:2:{s:11:\"removeItems\";s:1:\"3\";s:10:\"altLabels.\";a:3:{i:0;s:86:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:uploadslayout.default\";i:1;s:84:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:uploadslayout.icons\";i:2;s:94:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:uploadslayout.iconsandpreview\";}}}}s:12:\"table_class.\";a:1:{s:9:\"addItems.\";a:2:{s:5:\"hover\";s:82:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:tablelayout.hover\";s:9:\"condensed\";s:86:\"LLL:EXT:bootstrap_package/Resources/Private/Language/Backend.xlf:tablelayout.condensed\";}}s:12:\"imageborder.\";a:1:{s:8:\"disabled\";s:1:\"1\";}s:10:\"imagecols.\";a:1:{s:11:\"removeItems\";s:3:\"7,8\";}s:11:\"image_zoom.\";a:1:{s:6:\"types.\";a:1:{s:6:\"media.\";a:1:{s:8:\"disabled\";s:1:\"1\";}}}s:20:\"accessibility_title.\";a:1:{s:8:\"disabled\";s:1:\"1\";}s:12:\"imageheight.\";a:1:{s:8:\"disabled\";s:1:\"1\";}s:11:\"imagewidth.\";a:1:{s:8:\"disabled\";s:1:\"1\";}}s:6:\"pages.\";a:1:{s:7:\"layout.\";a:1:{s:11:\"removeItems\";s:5:\"1,2,3\";}}}s:4:\"RTE.\";a:1:{s:8:\"default.\";a:1:{s:6:\"preset\";s:14:\"my_sitepackage\";}}s:12:\"TCAdefaults.\";a:1:{s:11:\"tt_content.\";a:1:{s:9:\"imagecols\";s:1:\"1\";}}}s:8:\"sections\";a:0:{}s:5:\"match\";a:0:{}}i:1;s:32:\"f8342b40331360151d86fdd2df88e47a\";}');
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
INSERT INTO `cache_hash_tags` VALUES (1,'d07b003d9fce07cd551ada22027bf881','UserTSconfig'),(2,'95fd679b4c2e0087232eee3d1495afb1','ident_TS_TEMPLATE'),(3,'ae17c0809aeff68300a79c4ba3157375','ident_TMPL_CONDITIONS_ALL'),(4,'4c016b0241af84857eab5a57446249e9','ident_MENUDATA'),(5,'3bf4f6c578689d38935bc2ec133dd8af','ident_MENUDATA'),(6,'44de090abc9448d6f75574d58d9319db','ident_MENUDATA'),(7,'8dead708ac2d1dff4ea3197518fe0b7f','pageTSconfig'),(8,'989101fd1e8a9bdb09b1375f9ebe9e55','pageTSconfig');
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_imagesizes`
--

DROP TABLE IF EXISTS `cache_imagesizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_imagesizes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_imagesizes`
--

LOCK TABLES `cache_imagesizes` WRITE;
/*!40000 ALTER TABLE `cache_imagesizes` DISABLE KEYS */;
INSERT INTO `cache_imagesizes` VALUES (1,'7adebacc05dc01fd06e37969e614c204a29a03fc',2145909600,'x�-�K\n� Eѽ���oLW�����:(�{:{.O��3زj2�:�V������j�h(c\0`������3�W�/���y����nƟ[��톎��� '),(2,'0c95f80a250ad4d76b566424317c737587f235c2',2145909600,'x�-�K� ��	h(�4��p���݅�����19zN��t>���d2jK� �Ɋc�	X2��՘8��������C��0&�v	�E/��k����~�`!�'),(3,'ed4001abce596a5ccfb876b605294979cc842121',2145909600,'x�-�9� ��0��kq�@J��)�jf����`˪�h�XS���DLt�PrL&�x�q\Z�HB����Kj�{�롳!�9���^���x?c 6'),(4,'e3e18464017c6d3a352df6c850f996bc2f5a7036',2145909600,'x�-�K� Eѽ���򑺚R@8�āq�B�����	?\'[6M�f�1��:��#��*aZ\"��5Q\n$6z-�4{}?d/w��x��d�����k�u���V {'),(5,'223115c1b4edaa3ff44cd9b07ccdc0d8920aa0c6',2145909600,'x�-�A� ���B���T)���&�o��ɨxyN	⚞��1A�b�3U������+�AYc�(AH�<}~?t���k�$������ޮy0S~?U�!>'),(6,'aa39f66aad7f0ccb11537f9d5c182d4dabfec519',2145909600,'x�-�A� ��Z,�k�V��	ƿ����dT&y�������OǼ#[�\na1������V���i#?|�~=���nW/T�	ǟ�G��A���0� �'),(7,'d82c1255976e5a406466880609f5a7ff2fdedda3',2145909600,'x�-�A� ���@�kZ(���&�o���\n~N�욜�mczv��a�%W2S	ZMuI\"e[�\0�F�����\Z�����ϛ��]S�!��!�'),(8,'0707b0a04720a369a41c5800be0250af10bc806b',2145909600,'x�-�K� ��	�-b�i���&.�ww/�&�BbZ�sZ1��1�PpSܓ��!���J\".�6�������=_��-�~޴�v���DE!8'),(9,'fea5b93d079910475190f762caa98dffbc38078d',2145909600,'x�-�K� Eѽ���o�����#M�.$�^rn����dϦ���:&�	��M�	����(�%䅜�=������5:�%��?���vMIqY�;	 �'),(10,'fac2ba93eb39f8b01d2ab33a671bbd7671f12996',2145909600,'x�-�K� Eѽ�J�e5|�0p���ޅ�����K��Bbz:��sZ1[�R]ˡON+�@�q�,\02+oW�G����C<-�����_ˑ��� 9'),(11,'efed118068d9a4358e0a54e10abeed654268aca3',2145909600,'x�-�A� Dѻp����4�Ra�Jƻ����Ϩ�<����W	��I�\Za��q�Ԁic\' $#e7P�}qP��C��G����P�i0�\\r=J�Kz?� �'),(12,'e453280e55b30ee64ecc1fe167c65ba386ace8a5',2145909600,'x�-�9�0Dѻ��\n1�1v��*�(w\'��FO_Ch���PU�Us*�`�\rg6<eق03@����z=�vQIw�1\Z�X�\\S+u,���~2D!]'),(13,'ffa16f93490ddfc75856229f6da03d7f7e2f901b',2145909600,'x�-�1� ��0���(�J�+N����n53ZS��Ҭa�5¹f� �b0p,8��,�I������\n��i��cݿ���a.R��᳏{F<�!3 �'),(14,'21f3d658517d90d23140d1a316a5cc6a1365aee5',2145909600,'x�-�A� ��\n���J�p���-����d����&r���C �\0!�e�U��b�Ej�:�QV��{�����].{�\"���{Ӿ�ko��\0Gi!m'),(15,'04e48939453806db4d434fdbde0ad9fc22d62625',2145909600,'x�-�A� Dѻp\n���Z� qa�����������#U�W��Ԥ���5���݇���F,#��#�u��ٷ�K�����(�b���V�X�0��� M'),(16,'9bc4b52e86bc1977c284db9fea24a78fe8ed730f',2145909600,'x�-�K� ��	�H��4X*�p��݅��˼�$r�t�H�ԫ�sjR�\"^0\0\'X�������8dF#�y�f��JE��,4B�7?��J�����r�!�'),(17,'d917d5f05c9a35beff4de71dd5f693446331954c',2145909600,'x�-�K� ��	��m=\rJ�4qa����{�7�,V�S����f�1A�b�i���C(X+�%H��r�u�q�8�~�]�^�Q�L�?o��v��AZ�	� x'),(18,'02d1eb7a7d48d92aa268bc5b829c3e9c5701567a',2145909600,'x�-�A� ���-���T[��\'M<�.$�63�UAyN!	U�\Z�>�[\'#N>;)��bfdPRc�=+Q���޷C��ͮ��$�88��z+�\Z�x?a!r'),(19,'1093be50efe08b19a55a220a404c3dcdb06f6b2e',2145909600,'x�-�K� ��	\nE>�4��[��ą��B��e�d���A�T���>\'����Ɖ�#\"�T\"8�x�B��������5�]�Y��.��r��Z�1��~1� �'),(20,'409a39b7e67edd035cb66da4bc8ffe4aa7683ad1',2145909600,'x�-̱\r�0D�]2�mBl�4���\n$\n��$�I��L}N�\Z��%�m�s��1��JBNq��G�\rx�����z��w�W{��$�(^�ru�4��:� �');
/*!40000 ALTER TABLE `cache_imagesizes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_imagesizes_tags`
--

DROP TABLE IF EXISTS `cache_imagesizes_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_imagesizes_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_imagesizes_tags`
--

LOCK TABLES `cache_imagesizes_tags` WRITE;
/*!40000 ALTER TABLE `cache_imagesizes_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_imagesizes_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
INSERT INTO `cache_pages` VALUES (3,'cf176d6ea44076f899071d8b3de76c43',1639145827,'x��:msܶџ�_��_����v�Աe;q�$\ZK��v&37 	��C�\']���?�\0���tg�If���xX\0��ž��x�/�t��sVw��5��K�]\ZY�Da2��vq�ؑ�ǩ��(�|�EK��k���5_:\Z���d�~�4ξz����?�ޒۮ*/^���=7ʮ5HI����j���2�_�xqV���얶�u�F�f��_�&y��T����t��\0�=�Z�Nv-m���-�n�kV�L+^����#&p�5riY����t�`6z�\"����nn�$�,��c~6➵@�iR&�lx��5i�hJF:A$�ʾ��j̣�h#�a5��o3F.�p�����|�Ҋ݋���Ӳܒ�e���Je�Zr}Gi{+~&��I�3V�\0�:��o~�뛫��L4ۖ�o;�$Il���Q<F� o��E\rܶl6\r�hyKZS��o`!�5k%�y_��h�?��-O{\r�&)w�FxѮ��	{�����,�\ry+�.�;�a�An[V�z\0\n�=tִC�a���LRZW}\nb���`it�h�� ������:_T<k�E�P�@�:ޕ��[Q�3K��\r7�/=ߜfOMЈ֙�� �b��ߞ�|\rk�W��k�hgc��\\~}0z��}2�\r��yw{�3X3U����h�Ν���W}5�\"�ͰrP����(Kq0���]��eF�|6G�UE���pڀ���H9|�DL\0�m辄jq(!֏���ֲEW����ۖL�2֍�١>dR�kJǪƢ<��)˨+P���)M���\Z�I��E��^�F.c4�(eE��6M�,�7fN�|�M���8�`��i���^b��$�X�)H�,Q�~�f`h`�V��5���MC/m긩�v�a���,��cz�O�\\$�,�ŰXF�S?�|6�׳�ߛ_��A�v�%���n� Ml�;��,Ķ�Ћ��g!s�e�i~A;d��#��>�#/��<�C?�(-X���v�\"�`��8q���>D9H�%�zc,Ii�9����8�4�\r�c�@u��|Kx~n4`�Y	����h:?%۰ҴU��l���yI���̜�/;���5��|�0w�A�мP��\nR6ӵq1\r̄��]\"F��3�К�CG6�1AdǨ���\0�l��naϟ��ezᅁ� �,���(&H+N�T@I�YL��W_@�5�螏S܋�@���8�b!�Y�Nq�2�k9�!���F�/`2��򤸿�/�\0ծ�8�W8`\\�p���)�oX�}f�K�0`��I%�/A����g���z\nYJ%Ϟ�}�)|��g�k�&�������H[�w:��j?�� ��~+l�����,|�j������O.��X[�>i����Sg�V{:��\r�=�\n�-��\Z�Bd��;���U\Z�1����o��UJ��o\"@/δ������{8X*M`H�6)?&℟|��:F��yK��2��C�,�!W�	��V;N[�6�\r�lJTh߉!ǜ��Z?��,�Z�5�1�1O*�U| qiM��Px.�fmZB���!3�3�^L!!\0�q��ֹ�����������������7Y*��ZK+�.O�����5�����dʢ/��W����W/�]�`A5T�s���˥v	�?�+��&�)�?٤�\Z��B�lb^<��n\Z�yݺ��b�#�Z�:��Daw`�Z��\'h8-�,S�}��c[c�m���ɧ����Q����&�ؚ��tEx�\"�E)Z����%QN�cdH��0&ÃV�}I0ǃľ\"������J�sy@��sp��Ǆ8\"R0E��B�k\nZ�鷀\0Ur�o#ʾ�z� �:j���8�f�\Z+��s/���P�~F�J�jA��iX0����ʜ��j���/�[�DIG�`�_�:�z���qY,N��WN39�Y��,���L���&���V��(��k�JmؓCL(x�i�\Zr�n�G@��\"���b�л��N��X|\rtt�A�ZY�>FUӆ���IҸT\r����\\�C�9*�cI߶��?��N�����`���m~l\r��`!�P�v*0g��=���{�\\�>M-I�c�VM+2uJ���Y��V��U�nL���?��f�#�������y��y��\'��=�%8�\rA~�`|�A��O��ҧ�\"H;�)����4��lGS�R@��U�?�c��9�ш�id#�]��ld��01 �t-��xE��#T�:*�RG\'���Mvii�=�O��\Z�r����ܵ9������>H40��7>J#u��tsVZ�^�C��CV��1��k������!QA�Y�ߙ��zZ!�_�ax�D8<��C��gF�a��B6i�O�aH_*#!����d&Ӊ��^��|��>PU��*o�1�����z]ry;I��)�Ur�ӗǗ0�S�Z�c_ט9���L,�]�p�;�CJ�{�R����W 5�n���4^ע`�wA~��ړ7�ϡqpg������ҥ�����w�+�뀝=�� ieZ;�~����,���dFf�(Ku�3n��1���Q��G�L5��� ��_�d���>��ԋ �)(c	�J�N/C3\r�\"	�4�v�g�I�y�� +��ĥϳy�!\'�!���0i����<��(�~hB�Bi�a̲�Il�.b��n�QR@�q����۟���G���qd4�e+L?�������z��YA\"��#�7npîZ�$^�OS��ѲL��9�a�0i�e ?]~��%��OW#>��W�	_�&.�[���x�9�k&fh���\"V��^zhh��$�tܥAS��W���AZ��-�Je	ƹR�Sb\\\Z���3!���^G}�Y�5k����#L�M�\Z��(nW-nZ^�\r\0��������f���rX҇?Af�牸Z����U��\n=�[�S�\'��TШQO5;@�TP�х�w��un�%�h����aR��zOD!�f�_��Ug|rOH x��\0�3u6=���p)5-���c7F����{a��L�RT���(��~��V��x	2lK��c-z4��AXC��*`�0��vp������\\�\0��m\r��;�ݬ��T��)�� ,���#L�6�N?�Ļ[�X��~�;̍�>d��X�x�b�%�>��/���c0�4b^��l��Z!^�	�;�Li�%T1��j�-��o��\r���=��%���Q�DfNLm�o%ծ{�9W`�p���UY�U,���������At��[�k|0�ހ��Q���7\\��؛#V7w\'����$�|g�v�0i�\0G���]5b��QJ�.�~�gk/�����:y%v#P)5�^Π��{;6�a�*�����t���\0� U��@`�}�\0�^k\0. �v�&�jQ>�Ĩ+�Tϰ�ᡏ��qݧ�	r�#wz��4p/�ǀ��`НԐ���ϙR�\0�z���e�]�+���R��[u\rf�Hݶp-вňk�E.�tܼ�j+�v\\���k�D9�=��R�y=�\Z݁�=�4Yi�j�J=H���o��$�\0�r����؍�N�3�U3�@2�$<)4��,�>L��`#7#�!�8|�����:M���|� ��9z�C');
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
INSERT INTO `cache_pages_tags` VALUES (3,'cf176d6ea44076f899071d8b3de76c43','pageId_1');
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pagesection`
--

DROP TABLE IF EXISTS `cache_pagesection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pagesection` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pagesection`
--

LOCK TABLES `cache_pagesection` WRITE;
/*!40000 ALTER TABLE `cache_pagesection` DISABLE KEYS */;
INSERT INTO `cache_pagesection` VALUES (2,'1_222419149',1641651427,'x�Ś�n�8�oe��R͏����fG���v��*r�i�\Z�0��Y���&@m��f\'�B0���k��,�忔�X\0c�\n,���]Z��6J�$�A\'s�0����m}\'�f�uE�����y����o�꥽����v��r���nWI�2늧�w���aw�Ҫ�\'Xm�kg�\'>S!��Si\rj�\',�r,i}\"y���-��fx�LZ��9��¥���4uo�%<�,�E��l�*��F�Pm��`��)L���W�)����Y�5Y5��C*���c�/a���^��ء{��+/������AE����g/ �~���~CQ\rK�>2��m���@�Ha�����Ɵ]c���eu�\"��\'�mN���m�B��!�k_\Z�{Tlr�\rb�L�-cb�9��)�� �yyiծ���yǉ���t�,�4_��|����㕸<9��En|��3\r�X\'�o�?�̾$��Bem������C��W^�+��3��LNZW�ԯ<<T>��L����)���o�w��2���T��%�Η�)t7}�` �7��Պ@�TQ;F��QN�ʄқ���G&�w��Q�-dE�?�w�c1ȟ7VC��	]�D,1�\Z��A�D\n{��qZg�����O������:�v�l1Jm檈g�=e��l��qݙ�an���[^���9]�u|Ϗ����$>U=�_6�BP�D�x�ג�\"����yQFn�\'���\'#���t\"�/�-�s�	^`U ����M��n L�g�e��)d�̽�l��Xr������� ?r�ba>�G�H~�d�i�I\n�TV�.��?\rs�Bhיy����&����sV�O��\Z��)=#����Q�=TS���]\\���(���\Zp��ONV�\0�_��5�ȵ�=@��M�1�������	��-}R��f��#\r�Df;���\'2X)���ӝcx̶\Z�13b?笔��5#�D�����H��$SӍb��\'%G��z�m�\Z��»$�-��=��O���_O ��<\\�c��&�M\\炰����.����!���]R�?`�����2c��)Y}9Ҹ�\n�V��Zޗ��;�V���0�Ռ�91;FM1=�b��jFߠ�FM1\r�`~oH����e��u�@�:m�ҏ���I�_P��ı�&^�-�h��̔w��(�Q����å7��m�9�\Z�� \\3��D�]��33s�|���&��(���djf�NSRe:�� 4Cx��#?��&���:FH\Z\n�[\'�h�r���p��A9Z�\\Z�\rƌBu�f�߽�`����1�{>�ֆ�^��ٟ�-��\Z�/|WO��73E�\n\r���(�\Z\'l�f3�B�s�j��PXY�bT�\0aln9ϣ�{�������;Ψ�?�\r[?4��\0���,��(���rlY��sw_�o0I�4rY��߿��-T=������Vz�/\"9V,f��4M�ч�O2��4���p�#4��_�TRD�OF��d7C�XS���w�gzb��Y+-1t���K�:>�{��8�G,y���y��K���_^�����');
/*!40000 ALTER TABLE `cache_pagesection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pagesection_tags`
--

DROP TABLE IF EXISTS `cache_pagesection_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pagesection_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pagesection_tags`
--

LOCK TABLES `cache_pagesection_tags` WRITE;
/*!40000 ALTER TABLE `cache_pagesection_tags` DISABLE KEYS */;
INSERT INTO `cache_pagesection_tags` VALUES (3,'1_222419149','pageId_1'),(4,'1_222419149','mpvarHash_222419149');
/*!40000 ALTER TABLE `cache_pagesection_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
INSERT INTO `cache_rootline` VALUES (3,'1__0_0',1641651427,'x�M��n�0������ͩ�*�TU\n��,;Ԋ�\"��EQ޽��7����;((�ba�WP�p	��Y-��U\\T��	��K�w��CF�D)2	�1��X����ɹ^\rr=�H��[����=�F��|Y��O���ʞȶ� ��9yq2��1vYz�i��[�!;՘�eh<�ؙ�gT�\Z��6b�>����B����z��E�Q�����L��3Go^fg�Y��*,z�1�=;w���_�6��=\"e۶=��e%����6���ZF�E�M��\\ڕ�k��ƭ�\\��6���');
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
INSERT INTO `cache_rootline_tags` VALUES (3,'1__0_0','pageId_1');
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_treelist`
--

DROP TABLE IF EXISTS `cache_treelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_treelist` (
  `md5hash` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT 0,
  `treelist` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`md5hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_treelist`
--

LOCK TABLES `cache_treelist` WRITE;
/*!40000 ALTER TABLE `cache_treelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_treelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tx_extbase_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `lockToDomain` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `subgroup` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `felogin_redirectPid` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  `ses_anonymous` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tx_extbase_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `usergroup` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(160) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `middle_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `telephone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fax` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `lockToDomain` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `uc` blob DEFAULT NULL,
  `title` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `zip` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `country` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `www` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `company` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastlogin` int(10) unsigned NOT NULL DEFAULT 0,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `felogin_redirectPid` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `felogin_forgotHash` varchar(80) COLLATE utf8_unicode_ci DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(2048) COLLATE utf8_unicode_ci DEFAULT NULL,
  `doktype` int(10) unsigned NOT NULL DEFAULT 0,
  `TSconfig` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_siteroot` smallint(6) NOT NULL DEFAULT 0,
  `php_tree_stop` smallint(6) NOT NULL DEFAULT 0,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `target` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `lastUpdated` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `newUntil` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `abstract` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `module` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `author` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `author_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `nav_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `nav_hide` smallint(6) NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `l18n_cfg` smallint(6) NOT NULL DEFAULT 0,
  `fe_login_mode` smallint(6) NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tsconfig_includes` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `legacy_overlay_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `seo_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `no_index` smallint(6) NOT NULL DEFAULT 0,
  `no_follow` smallint(6) NOT NULL DEFAULT 0,
  `og_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `og_description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `twitter_description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_card` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `canonical_link` varchar(2048) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `sitemap_changefreq` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `categories` int(11) NOT NULL DEFAULT 0,
  `nav_icon_set` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `nav_icon_identifier` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `nav_icon` int(10) unsigned DEFAULT 0,
  `thumbnail` int(10) unsigned DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `legacy_overlay` (`legacy_overlay_uid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,0,1639057371,1639057254,1,0,0,0,0,'',256,NULL,0,0,0,0,NULL,0,'a:1:{s:6:\"hidden\";N;}',0,0,0,0,0,0,0,1,1,31,31,0,'Home','/',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1639057371,NULL,'',0,'','','',0,0,0,0,0,0,'','','EXT:my_sitepackage/Configuration/TsConfig/Page/All.tsconfig',0,0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'',0,'','',0,0);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `module_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `url` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `parent` int(11) NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fieldname` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  KEY `uid_local_foreign` (`uid_local`,`uid_foreign`),
  KEY `uid_foreign_tablefield` (`uid_foreign`,`tablenames`(40),`fieldname`(3),`sorting_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_collection`
--

DROP TABLE IF EXISTS `sys_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'static',
  `table_name` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `items` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_collection`
--

LOCK TABLES `sys_collection` WRITE;
/*!40000 ALTER TABLE `sys_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_collection_entries`
--

DROP TABLE IF EXISTS `sys_collection_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_collection_entries` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_collection_entries`
--

LOCK TABLES `sys_collection_entries` WRITE;
/*!40000 ALTER TABLE `sys_collection_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_collection_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `missing` smallint(6) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `type` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `metadata` int(11) NOT NULL DEFAULT 0,
  `identifier` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `identifier_hash` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `folder_hash` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `extension` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `mime_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `name` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `sha1` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `size` bigint(20) unsigned NOT NULL DEFAULT 0,
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES (1,0,1639057531,0,0,0,'2',0,'/typo3conf/ext/bootstrap_package/Resources/Public/Images/BootstrapPackage.svg','53b7aaf32363271515e80e6c7b25293292185218','27aadec2782a38a84423e8476091a41d1dbdbc06','svg','image/svg+xml','BootstrapPackage.svg','a6fb0cc7b50579d6255f16171147695a55b93c27',3843,1639057091,1637325343),(2,0,1639057531,0,0,0,'2',0,'/typo3conf/ext/bootstrap_package/Resources/Public/Images/BootstrapPackageInverted.svg','5b24af7f7f2c99d8a6188015bc8298396b952ab7','27aadec2782a38a84423e8476091a41d1dbdbc06','svg','image/svg+xml','BootstrapPackageInverted.svg','493f5cd69ede03cf7d436e92481422145674b907',3784,1639057091,1637325343),(3,0,1639057856,0,0,1,'2',0,'/user_upload/DevOp.png','994108972ddb5a2faeab2ba2f6eadaed76698d42','19669f1e02c2f16705ec7587044c66443be70725','png','image/png','DevOp.png','32e499d3bcbeaf58c9dc37a173f4fb6fa8b719db',155018,1639057856,1639057856),(5,0,1639059383,0,0,1,'2',0,'/DevOp.png','f4035d72aa3560d6b22268e1c66988a1ed20477b','42099b4af021e53fd8fd4e056c2568d7c2e3ffa8','png','image/png','DevOp.png','32e499d3bcbeaf58c9dc37a173f4fb6fa8b719db',155018,1639059383,1639059383);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'static',
  `files` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `folder` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `recursive` smallint(6) NOT NULL DEFAULT 0,
  `category` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `file` int(11) NOT NULL DEFAULT 0,
  `title` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `alternative` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `categories` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `fal_filelist` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES (1,0,1639057531,1639057531,1,0,0,NULL,0,'',0,0,0,0,0,0,0,1,NULL,244,68,NULL,NULL,0),(2,0,1639057531,1639057531,1,0,0,NULL,0,'',0,0,0,0,0,0,0,2,NULL,244,68,NULL,NULL,0),(3,0,1639057856,1639057856,1,0,0,NULL,0,'',0,0,0,0,0,0,0,3,NULL,1050,630,NULL,NULL,0),(5,0,1639059383,1639059383,1,0,0,NULL,0,'',0,0,0,0,0,0,0,5,NULL,1050,630,NULL,NULL,0);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `name` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `processing_url` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `task_type` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `checksum` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
INSERT INTO `sys_file_processedfile` VALUES (1,1639057531,1639057531,0,1,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','a6fb0cc7b50579d6255f16171147695a55b93c27','Image.CropScaleMask','0d7caec922',244,68),(2,1639057531,1639057531,0,2,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','493f5cd69ede03cf7d436e92481422145674b907','Image.CropScaleMask','631463fb33',244,68),(3,1639059297,1639057856,1,3,'/_processed_/1/7/preview_DevOp_186f7c10be.png','preview_DevOp_186f7c10be.png',NULL,'a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','32e499d3bcbeaf58c9dc37a173f4fb6fa8b719db','Image.Preview','186f7c10be',NULL,NULL),(4,1639059332,1639057856,1,3,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','32e499d3bcbeaf58c9dc37a173f4fb6fa8b719db','Image.CropScaleMask','975f3987d6',250,150),(5,1639059332,1639057856,1,3,'',NULL,'','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','32e499d3bcbeaf58c9dc37a173f4fb6fa8b719db','Image.CropScaleMask','1210bca832',75,45),(6,1639057869,1639057869,1,3,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1280;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','50fbdb0a1f728492fbac899aee2989b520ffbb71','32e499d3bcbeaf58c9dc37a173f4fb6fa8b719db','Image.CropScaleMask','e6761f286d',NULL,NULL),(7,1639057869,1639057869,1,3,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1100;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','013cecd923f59a410611402187055a763c68a59b','32e499d3bcbeaf58c9dc37a173f4fb6fa8b719db','Image.CropScaleMask','d8a8dc4465',NULL,NULL),(8,1639059298,1639057856,1,3,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:920;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','d6c532fac79f74ae7340dca7311482304d1103a0','32e499d3bcbeaf58c9dc37a173f4fb6fa8b719db','Image.CropScaleMask','56f7b261d3',920,552),(9,1639059298,1639057856,1,3,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:680;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','cf2eda657680e587f6f971ef728630d6d456e19d','32e499d3bcbeaf58c9dc37a173f4fb6fa8b719db','Image.CropScaleMask','5c820f991d',680,408),(10,1639059298,1639057856,1,3,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:500;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','81c13e849ae84d032c9f0e3805b43b5c2b54d6ef','32e499d3bcbeaf58c9dc37a173f4fb6fa8b719db','Image.CropScaleMask','405f12a9df',500,300),(11,1639059298,1639057856,1,3,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:374;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','fe99132c8b06a533c81165edcdfea60272e46f99','32e499d3bcbeaf58c9dc37a173f4fb6fa8b719db','Image.CropScaleMask','dc9dab99f1',374,225),(12,1639059298,1639057856,1,3,'',NULL,'','a:7:{s:5:\"width\";i:1280;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','515a7b508f756e7c6c38d99c444f9648bb23597d','32e499d3bcbeaf58c9dc37a173f4fb6fa8b719db','Image.CropScaleMask','e5db70d96d',1280,769),(14,1639059383,1639059383,1,5,'/_processed_/5/e/preview_DevOp_2138b25670.png','preview_DevOp_2138b25670.png',NULL,'a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','32e499d3bcbeaf58c9dc37a173f4fb6fa8b719db','Image.Preview','2138b25670',64,38),(15,1639059423,1639059423,1,5,'/_processed_/5/e/csm_DevOp_336f0c21a0.png','csm_DevOp_336f0c21a0.png',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','32e499d3bcbeaf58c9dc37a173f4fb6fa8b719db','Image.CropScaleMask','336f0c21a0',250,150),(16,1639059423,1639059423,1,5,'/_processed_/5/e/csm_DevOp_4573255a44.png','csm_DevOp_4573255a44.png',NULL,'a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','32e499d3bcbeaf58c9dc37a173f4fb6fa8b719db','Image.CropScaleMask','4573255a44',75,45),(17,1639059428,1639059428,1,5,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1280;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','50fbdb0a1f728492fbac899aee2989b520ffbb71','32e499d3bcbeaf58c9dc37a173f4fb6fa8b719db','Image.CropScaleMask','405abc3eb7',NULL,NULL),(18,1639059428,1639059428,1,5,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1100;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','013cecd923f59a410611402187055a763c68a59b','32e499d3bcbeaf58c9dc37a173f4fb6fa8b719db','Image.CropScaleMask','6b99719440',NULL,NULL),(19,1639059428,1639059428,1,5,'/_processed_/5/e/csm_DevOp_66228a360d.png','csm_DevOp_66228a360d.png',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:920;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','d6c532fac79f74ae7340dca7311482304d1103a0','32e499d3bcbeaf58c9dc37a173f4fb6fa8b719db','Image.CropScaleMask','66228a360d',920,552),(20,1639059428,1639059428,1,5,'/_processed_/5/e/csm_DevOp_0d7b4d5253.png','csm_DevOp_0d7b4d5253.png',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:680;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','cf2eda657680e587f6f971ef728630d6d456e19d','32e499d3bcbeaf58c9dc37a173f4fb6fa8b719db','Image.CropScaleMask','0d7b4d5253',680,408),(21,1639059428,1639059428,1,5,'/_processed_/5/e/csm_DevOp_64e2b5f4a3.png','csm_DevOp_64e2b5f4a3.png',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:500;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','81c13e849ae84d032c9f0e3805b43b5c2b54d6ef','32e499d3bcbeaf58c9dc37a173f4fb6fa8b719db','Image.CropScaleMask','64e2b5f4a3',500,300),(22,1639059428,1639059428,1,5,'/_processed_/5/e/csm_DevOp_0f0c4b905c.png','csm_DevOp_0f0c4b905c.png',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:374;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','fe99132c8b06a533c81165edcdfea60272e46f99','32e499d3bcbeaf58c9dc37a173f4fb6fa8b719db','Image.CropScaleMask','0f0c4b905c',374,225),(23,1639059429,1639059429,1,5,'/_processed_/5/e/csm_DevOp_1eca7e4b70.png','csm_DevOp_1eca7e4b70.png',NULL,'a:7:{s:5:\"width\";i:1280;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','515a7b508f756e7c6c38d99c444f9648bb23597d','32e499d3bcbeaf58c9dc37a173f4fb6fa8b719db','Image.CropScaleMask','1eca7e4b70',1280,769);
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `fieldname` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `table_local` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `title` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `alternative` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `crop` varchar(4000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `autoplay` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
INSERT INTO `sys_file_reference` VALUES (1,1,1639058015,1639057860,1,1,0,0,0,NULL,'',0,0,0,0,0,0,0,3,2,'tt_content','image',1,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"large\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"medium\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"small\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"extrasmall\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(2,1,1639059354,1639058015,1,1,0,0,0,NULL,'',0,0,0,0,0,0,0,3,2,'tt_content','image',1,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"large\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"medium\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"small\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"extrasmall\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),(3,1,1639059425,1639059425,1,0,0,0,0,NULL,'',0,0,0,0,0,0,0,5,2,'tt_content','image',1,'sys_file',NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"large\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"medium\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"small\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null},\"extrasmall\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0);
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `driver` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `configuration` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_default` smallint(6) NOT NULL DEFAULT 0,
  `is_browsable` smallint(6) NOT NULL DEFAULT 0,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `is_writable` smallint(6) NOT NULL DEFAULT 0,
  `is_online` smallint(6) NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(6) NOT NULL DEFAULT 1,
  `processingfolder` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES (1,0,1639057261,1639057261,0,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.','fileadmin/ (auto-created)','Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',1,1,1,1,1,1,NULL);
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `path` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `base` int(10) unsigned NOT NULL DEFAULT 0,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `history_data` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
INSERT INTO `sys_history` VALUES (1,1639057254,1,'BE',1,0,1,'pages','{\"uid\":1,\"pid\":0,\"tstamp\":1639057254,\"crdate\":1639057254,\"cruser_id\":1,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":256,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"title\":\"Home\",\"slug\":\"\\/\",\"doktype\":1,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"lastUpdated\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"newUntil\":0,\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"fe_login_mode\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"legacy_overlay_uid\":0,\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\",\"categories\":0}',0,'0400$39853a43f242a9200e553d6fc735e121:e175f7045d7ccbfb26ffcf279422c2e5'),(2,1639057254,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"a:1:{s:4:\\\"slug\\\";N;}\"}}',0,'0400$e7b7bca4f7e892515869724b8e7d4980:e175f7045d7ccbfb26ffcf279422c2e5'),(3,1639057357,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"tsconfig_includes\":null,\"fe_group\":\"0\",\"l10n_diffsource\":\"a:1:{s:4:\\\"slug\\\";N;}\"},\"newRecord\":{\"tsconfig_includes\":\"EXT:my_sitepackage\\/Configuration\\/TsConfig\\/Page\\/All.tsconfig\",\"fe_group\":\"\",\"l10n_diffsource\":\"a:53:{s:7:\\\"doktype\\\";N;s:5:\\\"title\\\";N;s:4:\\\"slug\\\";N;s:9:\\\"nav_title\\\";N;s:8:\\\"subtitle\\\";N;s:12:\\\"nav_icon_set\\\";N;s:8:\\\"nav_icon\\\";N;s:9:\\\"seo_title\\\";N;s:11:\\\"description\\\";N;s:8:\\\"no_index\\\";N;s:9:\\\"no_follow\\\";N;s:14:\\\"canonical_link\\\";N;s:18:\\\"sitemap_changefreq\\\";N;s:16:\\\"sitemap_priority\\\";N;s:8:\\\"og_title\\\";N;s:14:\\\"og_description\\\";N;s:8:\\\"og_image\\\";N;s:13:\\\"twitter_title\\\";N;s:19:\\\"twitter_description\\\";N;s:13:\\\"twitter_image\\\";N;s:12:\\\"twitter_card\\\";N;s:8:\\\"abstract\\\";N;s:8:\\\"keywords\\\";N;s:6:\\\"author\\\";N;s:12:\\\"author_email\\\";N;s:11:\\\"lastUpdated\\\";N;s:6:\\\"layout\\\";N;s:8:\\\"newUntil\\\";N;s:14:\\\"backend_layout\\\";N;s:25:\\\"backend_layout_next_level\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"content_from_pid\\\";N;s:6:\\\"target\\\";N;s:13:\\\"cache_timeout\\\";N;s:10:\\\"cache_tags\\\";N;s:11:\\\"is_siteroot\\\";N;s:9:\\\"no_search\\\";N;s:13:\\\"php_tree_stop\\\";N;s:6:\\\"module\\\";N;s:5:\\\"media\\\";N;s:17:\\\"tsconfig_includes\\\";N;s:8:\\\"TSconfig\\\";N;s:8:\\\"l18n_cfg\\\";N;s:6:\\\"hidden\\\";N;s:8:\\\"nav_hide\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:16:\\\"extendToSubpages\\\";N;s:8:\\\"fe_group\\\";N;s:13:\\\"fe_login_mode\\\";N;s:8:\\\"editlock\\\";N;s:10:\\\"categories\\\";N;s:14:\\\"rowDescription\\\";N;}\"}}',0,'0400$1d0fe8571182d3c4a2a4f0ab7982994c:e175f7045d7ccbfb26ffcf279422c2e5'),(4,1639057371,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"a:53:{s:7:\\\"doktype\\\";N;s:5:\\\"title\\\";N;s:4:\\\"slug\\\";N;s:9:\\\"nav_title\\\";N;s:8:\\\"subtitle\\\";N;s:12:\\\"nav_icon_set\\\";N;s:8:\\\"nav_icon\\\";N;s:9:\\\"seo_title\\\";N;s:11:\\\"description\\\";N;s:8:\\\"no_index\\\";N;s:9:\\\"no_follow\\\";N;s:14:\\\"canonical_link\\\";N;s:18:\\\"sitemap_changefreq\\\";N;s:16:\\\"sitemap_priority\\\";N;s:8:\\\"og_title\\\";N;s:14:\\\"og_description\\\";N;s:8:\\\"og_image\\\";N;s:13:\\\"twitter_title\\\";N;s:19:\\\"twitter_description\\\";N;s:13:\\\"twitter_image\\\";N;s:12:\\\"twitter_card\\\";N;s:8:\\\"abstract\\\";N;s:8:\\\"keywords\\\";N;s:6:\\\"author\\\";N;s:12:\\\"author_email\\\";N;s:11:\\\"lastUpdated\\\";N;s:6:\\\"layout\\\";N;s:8:\\\"newUntil\\\";N;s:14:\\\"backend_layout\\\";N;s:25:\\\"backend_layout_next_level\\\";N;s:9:\\\"thumbnail\\\";N;s:16:\\\"content_from_pid\\\";N;s:6:\\\"target\\\";N;s:13:\\\"cache_timeout\\\";N;s:10:\\\"cache_tags\\\";N;s:11:\\\"is_siteroot\\\";N;s:9:\\\"no_search\\\";N;s:13:\\\"php_tree_stop\\\";N;s:6:\\\"module\\\";N;s:5:\\\"media\\\";N;s:17:\\\"tsconfig_includes\\\";N;s:8:\\\"TSconfig\\\";N;s:8:\\\"l18n_cfg\\\";N;s:6:\\\"hidden\\\";N;s:8:\\\"nav_hide\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:16:\\\"extendToSubpages\\\";N;s:8:\\\"fe_group\\\";N;s:13:\\\"fe_login_mode\\\";N;s:8:\\\"editlock\\\";N;s:10:\\\"categories\\\";N;s:14:\\\"rowDescription\\\";N;}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"a:1:{s:6:\\\"hidden\\\";N;}\"}}',0,'0400$78dbf93bb2a6354bf962eb52a808fa3b:e175f7045d7ccbfb26ffcf279422c2e5'),(5,1639057398,1,'BE',1,0,1,'sys_template','{\"uid\":1,\"pid\":1,\"tstamp\":1639057398,\"crdate\":1639057398,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sorting\":256,\"description\":null,\"t3_origuid\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"title\":\"NEW SITE\",\"sitetitle\":\"\",\"root\":1,\"clear\":3,\"include_static_file\":null,\"constants\":null,\"config\":\"\\n# Default PAGE object:\\npage = PAGE\\npage.10 = TEXT\\npage.10.value = HELLO WORLD!\\n\",\"basedOn\":\"\",\"includeStaticAfterBasedOn\":0,\"static_file_mode\":0,\"tx_impexp_origuid\":0}',0,'0400$d793741ffc2a3f0eeb9260e5dc79d425:35af6288617af54964e77af08c30949a'),(6,1639057428,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"config\":\"\\n# Default PAGE object:\\npage = PAGE\\npage.10 = TEXT\\npage.10.value = HELLO WORLD!\\n\",\"include_static_file\":null},\"newRecord\":{\"config\":\"# Default PAGE object:\\r\\npage = PAGE\\r\\npage.10 = TEXT\\r\\npage.10.value = HELLO WORLD!\\r\\n\",\"include_static_file\":\"EXT:my_sitepackage\\/Configuration\\/TypoScript\"}}',0,'0400$ca87277cac4d20d520fa4a0d293ef433:35af6288617af54964e77af08c30949a'),(7,1639057453,1,'BE',1,0,1,'tt_content','{\"uid\":1,\"rowDescription\":\"\",\"pid\":1,\"tstamp\":1639057453,\"crdate\":1639057453,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"CType\":\"text\",\"header\":\"\",\"header_position\":\"\",\"bodytext\":\"<p>test<\\/p>\",\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":1,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"date\":0,\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"selected_categories\":null,\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"tx_impexp_origuid\":0,\"categories\":0,\"teaser\":null,\"aspect_ratio\":\"1.3333333333333\",\"items_per_page\":10,\"readmore_label\":\"\",\"quote_source\":\"\",\"quote_link\":\"\",\"panel_class\":\"default\",\"file_folder\":null,\"icon\":\"\",\"icon_set\":\"\",\"icon_file\":0,\"icon_position\":\"\",\"icon_size\":\"default\",\"icon_type\":\"default\",\"icon_color\":\"#FFFFFF\",\"icon_background\":\"#333333\",\"external_media_source\":\"\",\"external_media_ratio\":\"\",\"tx_bootstrappackage_card_group_item\":0,\"tx_bootstrappackage_carousel_item\":0,\"tx_bootstrappackage_accordion_item\":0,\"tx_bootstrappackage_icon_group_item\":0,\"tx_bootstrappackage_tab_item\":0,\"tx_bootstrappackage_timeline_item\":0,\"frame_layout\":\"default\",\"background_color_class\":\"none\",\"background_image\":0,\"background_image_options\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"parallax\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"fade\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"filter\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"}',0,'0400$d0788b42b9f48aa4f769da05706d6842:7fa2c035f26826fe83eeecaaeddc4d40'),(8,1639057484,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"include_static_file\":\"EXT:my_sitepackage\\/Configuration\\/TypoScript\"},\"newRecord\":{\"include_static_file\":\"EXT:my_sitepackage\\/Configuration\\/TypoScript,EXT:bootstrap_package\\/Configuration\\/TypoScript,EXT:bootstrap_package\\/Configuration\\/TypoScript\\/ContentElement,EXT:bootstrap_package\\/Configuration\\/TypoScript\\/Bootstrap5\"}}',0,'0400$ab66ddd154bce737c12a6f382226714c:35af6288617af54964e77af08c30949a'),(9,1639057528,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"config\":\"# Default PAGE object:\\r\\npage = PAGE\\r\\npage.10 = TEXT\\r\\npage.10.value = HELLO WORLD!\\r\\n\"},\"newRecord\":{\"config\":\"\"}}',0,'0400$268b3c5d07602d4e6c96289f6fc862c1:35af6288617af54964e77af08c30949a'),(10,1639057561,2,'BE',1,0,1,'tt_content','{\"oldRecord\":{\"bodytext\":\"<p>test<\\/p>\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"bodytext\":\"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.<\\/p>\",\"l18n_diffsource\":\"a:27:{s:5:\\\"CType\\\";N;s:6:\\\"colPos\\\";N;s:6:\\\"header\\\";N;s:13:\\\"header_layout\\\";N;s:15:\\\"header_position\\\";N;s:4:\\\"date\\\";N;s:11:\\\"header_link\\\";N;s:9:\\\"subheader\\\";N;s:8:\\\"bodytext\\\";N;s:6:\\\"layout\\\";N;s:11:\\\"frame_class\\\";N;s:18:\\\"space_before_class\\\";N;s:17:\\\"space_after_class\\\";N;s:12:\\\"frame_layout\\\";N;s:22:\\\"background_color_class\\\";N;s:16:\\\"background_image\\\";N;s:24:\\\"background_image_options\\\";N;s:12:\\\"sectionIndex\\\";N;s:9:\\\"linkToTop\\\";N;s:16:\\\"sys_language_uid\\\";N;s:6:\\\"hidden\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:8:\\\"fe_group\\\";N;s:8:\\\"editlock\\\";N;s:10:\\\"categories\\\";N;s:14:\\\"rowDescription\\\";N;}\"}}',0,'0400$363cdc8d6a451e876906c175d7ae6fc1:7fa2c035f26826fe83eeecaaeddc4d40'),(11,1639057860,1,'BE',1,0,2,'tt_content','{\"uid\":2,\"rowDescription\":\"\",\"pid\":1,\"tstamp\":1639057860,\"crdate\":1639057860,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":512,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"CType\":\"textpic\",\"header\":\"\",\"header_position\":\"\",\"bodytext\":\"\",\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":1,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"date\":0,\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"selected_categories\":null,\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"tx_impexp_origuid\":0,\"categories\":0,\"teaser\":null,\"aspect_ratio\":\"1.3333333333333\",\"items_per_page\":10,\"readmore_label\":\"\",\"quote_source\":\"\",\"quote_link\":\"\",\"panel_class\":\"default\",\"file_folder\":\"\",\"icon\":\"\",\"icon_set\":\"\",\"icon_file\":0,\"icon_position\":\"\",\"icon_size\":\"default\",\"icon_type\":\"default\",\"icon_color\":\"#FFFFFF\",\"icon_background\":\"#333333\",\"external_media_source\":\"\",\"external_media_ratio\":\"\",\"tx_bootstrappackage_card_group_item\":0,\"tx_bootstrappackage_carousel_item\":0,\"tx_bootstrappackage_accordion_item\":0,\"tx_bootstrappackage_icon_group_item\":0,\"tx_bootstrappackage_tab_item\":0,\"tx_bootstrappackage_timeline_item\":0,\"frame_layout\":\"default\",\"background_color_class\":\"none\",\"background_image\":0,\"background_image_options\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"parallax\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"fade\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"filter\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"}',0,'0400$29306917cda08282a583e7e1f64bb4c5:01dbc21fdb1263685b9147b3b1596ea8'),(12,1639057860,1,'BE',1,0,1,'sys_file_reference','{\"uid\":1,\"pid\":1,\"tstamp\":1639057860,\"crdate\":1639057860,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"uid_local\":3,\"uid_foreign\":0,\"tablenames\":\"\",\"fieldname\":\"\",\"sorting_foreign\":0,\"table_local\":\"sys_file\",\"title\":null,\"description\":null,\"alternative\":null,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null},\\\"large\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null},\\\"medium\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null},\\\"small\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null},\\\"extrasmall\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0}',0,'0400$29306917cda08282a583e7e1f64bb4c5:4cf496f597e7b095ce8b755e6cec3c0c'),(13,1639058015,2,'BE',1,0,2,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"\"},\"newRecord\":{\"l18n_diffsource\":\"a:33:{s:5:\\\"CType\\\";N;s:6:\\\"colPos\\\";N;s:6:\\\"header\\\";N;s:13:\\\"header_layout\\\";N;s:15:\\\"header_position\\\";N;s:4:\\\"date\\\";N;s:11:\\\"header_link\\\";N;s:9:\\\"subheader\\\";N;s:8:\\\"bodytext\\\";N;s:5:\\\"image\\\";N;s:11:\\\"file_folder\\\";N;s:16:\\\"filelink_sorting\\\";N;s:11:\\\"imageorient\\\";N;s:9:\\\"imagecols\\\";N;s:10:\\\"image_zoom\\\";N;s:6:\\\"layout\\\";N;s:11:\\\"frame_class\\\";N;s:18:\\\"space_before_class\\\";N;s:17:\\\"space_after_class\\\";N;s:12:\\\"frame_layout\\\";N;s:22:\\\"background_color_class\\\";N;s:16:\\\"background_image\\\";N;s:24:\\\"background_image_options\\\";N;s:12:\\\"sectionIndex\\\";N;s:9:\\\"linkToTop\\\";N;s:16:\\\"sys_language_uid\\\";N;s:6:\\\"hidden\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:8:\\\"fe_group\\\";N;s:8:\\\"editlock\\\";N;s:10:\\\"categories\\\";N;s:14:\\\"rowDescription\\\";N;}\"}}',0,'0400$8b7490f2246fe7590733712ff6f14725:01dbc21fdb1263685b9147b3b1596ea8'),(14,1639058015,1,'BE',1,0,2,'sys_file_reference','{\"uid\":2,\"pid\":1,\"tstamp\":1639058015,\"crdate\":1639058015,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"uid_local\":3,\"uid_foreign\":0,\"tablenames\":\"\",\"fieldname\":\"\",\"sorting_foreign\":0,\"table_local\":\"sys_file\",\"title\":null,\"description\":null,\"alternative\":null,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null},\\\"large\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null},\\\"medium\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null},\\\"small\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null},\\\"extrasmall\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0}',0,'0400$8b7490f2246fe7590733712ff6f14725:814fc0f720dfab882655a795e23a5b66'),(15,1639058015,2,'BE',1,0,2,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"\"},\"newRecord\":{\"l18n_diffsource\":\"a:33:{s:5:\\\"CType\\\";N;s:6:\\\"colPos\\\";N;s:6:\\\"header\\\";N;s:13:\\\"header_layout\\\";N;s:15:\\\"header_position\\\";N;s:4:\\\"date\\\";N;s:11:\\\"header_link\\\";N;s:9:\\\"subheader\\\";N;s:8:\\\"bodytext\\\";N;s:5:\\\"image\\\";N;s:11:\\\"file_folder\\\";N;s:16:\\\"filelink_sorting\\\";N;s:11:\\\"imageorient\\\";N;s:9:\\\"imagecols\\\";N;s:10:\\\"image_zoom\\\";N;s:6:\\\"layout\\\";N;s:11:\\\"frame_class\\\";N;s:18:\\\"space_before_class\\\";N;s:17:\\\"space_after_class\\\";N;s:12:\\\"frame_layout\\\";N;s:22:\\\"background_color_class\\\";N;s:16:\\\"background_image\\\";N;s:24:\\\"background_image_options\\\";N;s:12:\\\"sectionIndex\\\";N;s:9:\\\"linkToTop\\\";N;s:16:\\\"sys_language_uid\\\";N;s:6:\\\"hidden\\\";N;s:9:\\\"starttime\\\";N;s:7:\\\"endtime\\\";N;s:8:\\\"fe_group\\\";N;s:8:\\\"editlock\\\";N;s:10:\\\"categories\\\";N;s:14:\\\"rowDescription\\\";N;}\"}}',0,'0400$8b7490f2246fe7590733712ff6f14725:01dbc21fdb1263685b9147b3b1596ea8'),(16,1639058015,4,'BE',1,0,1,'sys_file_reference',NULL,0,'0400$8b7490f2246fe7590733712ff6f14725:4cf496f597e7b095ce8b755e6cec3c0c'),(17,1639058044,4,'BE',1,0,1,'tt_content',NULL,0,'0400$21141f17f35a08b1bfb000fd02c6b746:7fa2c035f26826fe83eeecaaeddc4d40'),(18,1639058072,1,'BE',1,0,3,'tt_content','{\"uid\":3,\"rowDescription\":\"\",\"pid\":1,\"tstamp\":1639058072,\"crdate\":1639058072,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"CType\":\"text\",\"header\":\"\",\"header_position\":\"\",\"bodytext\":\"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.<\\/p>\",\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":1,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"date\":0,\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"selected_categories\":null,\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"tx_impexp_origuid\":0,\"categories\":0,\"teaser\":null,\"aspect_ratio\":\"1.3333333333333\",\"items_per_page\":10,\"readmore_label\":\"\",\"quote_source\":\"\",\"quote_link\":\"\",\"panel_class\":\"default\",\"file_folder\":null,\"icon\":\"\",\"icon_set\":\"\",\"icon_file\":0,\"icon_position\":\"\",\"icon_size\":\"default\",\"icon_type\":\"default\",\"icon_color\":\"#FFFFFF\",\"icon_background\":\"#333333\",\"external_media_source\":\"\",\"external_media_ratio\":\"\",\"tx_bootstrappackage_card_group_item\":0,\"tx_bootstrappackage_carousel_item\":0,\"tx_bootstrappackage_accordion_item\":0,\"tx_bootstrappackage_icon_group_item\":0,\"tx_bootstrappackage_tab_item\":0,\"tx_bootstrappackage_timeline_item\":0,\"frame_layout\":\"default\",\"background_color_class\":\"none\",\"background_image\":0,\"background_image_options\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"parallax\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"fade\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"filter\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"}',0,'0400$0799a7ab006e8baa8557e5116c3c3780:b92300cfb5d1d3645c9cb212a7f56c1f'),(19,1639058089,4,'BE',1,0,3,'tt_content',NULL,0,'0400$1acc08dce9cd4f5250af40873eb3f059:b92300cfb5d1d3645c9cb212a7f56c1f'),(20,1639058194,1,'BE',1,0,4,'tt_content','{\"uid\":4,\"rowDescription\":\"\",\"pid\":1,\"tstamp\":1639058194,\"crdate\":1639058194,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"CType\":\"text\",\"header\":\"\",\"header_position\":\"\",\"bodytext\":\"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.<\\/p>\",\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":1,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"date\":0,\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"selected_categories\":null,\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"tx_impexp_origuid\":0,\"categories\":0,\"teaser\":null,\"aspect_ratio\":\"1.3333333333333\",\"items_per_page\":10,\"readmore_label\":\"\",\"quote_source\":\"\",\"quote_link\":\"\",\"panel_class\":\"default\",\"file_folder\":null,\"icon\":\"\",\"icon_set\":\"\",\"icon_file\":0,\"icon_position\":\"\",\"icon_size\":\"default\",\"icon_type\":\"default\",\"icon_color\":\"#FFFFFF\",\"icon_background\":\"#333333\",\"external_media_source\":\"\",\"external_media_ratio\":\"\",\"tx_bootstrappackage_card_group_item\":0,\"tx_bootstrappackage_carousel_item\":0,\"tx_bootstrappackage_accordion_item\":0,\"tx_bootstrappackage_icon_group_item\":0,\"tx_bootstrappackage_tab_item\":0,\"tx_bootstrappackage_timeline_item\":0,\"frame_layout\":\"default\",\"background_color_class\":\"none\",\"background_image\":0,\"background_image_options\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"parallax\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"fade\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"filter\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"}',0,'0400$c0202ec044f8f91d9e02f01419c24252:4d391f5ef79b8d5d10dffa8a07ca167d'),(21,1639059354,2,'BE',1,0,2,'tt_content','{\"oldRecord\":{\"image\":1},\"newRecord\":{\"image\":0}}',0,'0400$efa40620049efd4d0a1b523ef8697dff:01dbc21fdb1263685b9147b3b1596ea8'),(22,1639059354,4,'BE',1,0,2,'sys_file_reference',NULL,0,'0400$efa40620049efd4d0a1b523ef8697dff:814fc0f720dfab882655a795e23a5b66'),(23,1639059425,1,'BE',1,0,3,'sys_file_reference','{\"uid\":3,\"pid\":1,\"tstamp\":1639059425,\"crdate\":1639059425,\"cruser_id\":1,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"t3ver_count\":0,\"t3ver_tstamp\":0,\"t3ver_move_id\":0,\"uid_local\":5,\"uid_foreign\":0,\"tablenames\":\"\",\"fieldname\":\"\",\"sorting_foreign\":0,\"table_local\":\"sys_file\",\"title\":null,\"description\":null,\"alternative\":null,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null},\\\"large\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null},\\\"medium\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null},\\\"small\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null},\\\"extrasmall\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0}',0,'0400$cc61bb12a65e1c00d7ecd98213fc68a6:d2c609347a4764200256b39b9425159a');
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_language`
--

DROP TABLE IF EXISTS `sys_language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_language` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `title` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `flag` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `language_isocode` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `nav_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `locale` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `hreflang` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `direction` varchar(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_language`
--

LOCK TABLES `sys_language` WRITE;
/*!40000 ALTER TABLE `sys_language` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
INSERT INTO `sys_lockedrecords` VALUES (20,1,1639059425,'tt_content',2,1,'admin',0);
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details_nr` smallint(6) NOT NULL DEFAULT 0,
  `IP` varchar(39) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `log_data` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `NEWid` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `request_id` varchar(13) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `level` smallint(5) unsigned NOT NULL DEFAULT 0,
  `message` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
INSERT INTO `sys_log` VALUES (1,0,1639056571,1,1,0,'',0,0,'User %s logged in from ###IP###',255,1,'172.23.0.6','a:1:{i:0;s:5:\"admin\";}',-1,-99,'','',0,'',0,NULL,NULL),(2,0,1639057254,1,1,1,'pages',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'172.23.0.6','a:4:{i:0;s:4:\"Home\";i:1;s:7:\"pages:1\";i:2;s:12:\"[root-level]\";i:3;i:0;}',0,0,'NEW_1','',0,'',0,NULL,NULL),(3,0,1639057254,1,2,1,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.23.0.6','a:3:{i:0;s:4:\"Home\";i:1;s:7:\"pages:1\";s:7:\"history\";s:1:\"2\";}',1,0,'','',0,'',0,NULL,NULL),(4,0,1639057254,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: An exception occurred while executing \'SELECT `uid`, `l10n_parent`, `sys_language_uid`, `fe_group`, `url`, `shortcut`, `content_from_pid`, `mount_pid`, `author_email`, `media`, `tsconfig_includes`, `categories`, `canonical_link`, `og_image`, `twitter_image`, `nav_icon`, `thumbnail`, `deleted`, `t3ver_wsid`, `t3ver_state` FROM `pages` WHERE `uid` = ?\' with params [1]:\n\nUnknown column \'nav_icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/lib/Doctrine/DBAL/Driver/AbstractMySQLDriver.php in line 79. Requested URL: http://my-typo3-site.ddev.site:8080/typo3/index.php?route=%%2Fajax%%2Frecord%%2Fprocess&token=--AnonymizedToken--',5,0,'172.23.0.6','',-1,0,'','',0,'',0,NULL,NULL),(5,0,1639057306,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: An exception occurred while executing \'SELECT `nav_icon_set` FROM `pages` WHERE `uid` = ?\' with params [1]:\n\nUnknown column \'nav_icon_set\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/lib/Doctrine/DBAL/Driver/AbstractMySQLDriver.php in line 79. Requested URL: http://my-typo3-site.ddev.site:8080/typo3/index.php?route=%%2Frecord%%2Fedit&token=--AnonymizedToken--&edit%%5Bpages%%5D%%5B1%%5D=edit&overrideVals%%5Bpages%%5D%%5Bsys_language_uid%%5D=0&returnUrl=%%2Ftypo3%%2Findex.php%%3Froute%%3D%%252Fmodule%%252Fweb%%252Flist%%26token%%3D90b70556c97f7b90541fc0fe8225358e6913fe1e%%26id%%3D0',5,0,'172.23.0.6','',-1,0,'','',0,'',0,NULL,NULL),(6,0,1639057357,1,2,1,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.23.0.6','a:3:{i:0;s:4:\"Home\";i:1;s:7:\"pages:1\";s:7:\"history\";s:1:\"3\";}',1,0,'','',0,'',0,NULL,NULL),(7,0,1639057371,1,2,1,'pages',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.23.0.6','a:3:{i:0;s:4:\"Home\";i:1;s:7:\"pages:1\";s:7:\"history\";s:1:\"4\";}',1,0,'','',0,'',0,NULL,NULL),(8,0,1639057373,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1294587218: No TypoScript template found! | TYPO3\\CMS\\Core\\Error\\Http\\InternalServerErrorException thrown in file /var/www/html/public/typo3/sysext/frontend/Classes/Controller/TypoScriptFrontendController.php in line 2175. Requested URL: http://my-typo3-site.ddev.site:8080/autogenerated-1/',5,0,'172.23.0.6','',-1,0,'','',0,'',0,NULL,NULL),(9,0,1639057398,1,1,1,'sys_template',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'172.23.0.6','a:4:{i:0;s:8:\"NEW SITE\";i:1;s:14:\"sys_template:1\";i:2;s:4:\"Home\";i:3;i:1;}',1,0,'NEW','',0,'',0,NULL,NULL),(10,0,1639057428,1,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.23.0.6','a:3:{i:0;s:8:\"NEW SITE\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:1:\"6\";}',1,0,'','',0,'',0,NULL,NULL),(11,0,1639057453,1,1,1,'tt_content',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'172.23.0.6','a:4:{i:0;s:4:\"test\";i:1;s:12:\"tt_content:1\";i:2;s:4:\"Home\";i:3;i:1;}',1,0,'NEW61b20829977da336324316','',0,'',0,NULL,NULL),(12,0,1639057484,1,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.23.0.6','a:3:{i:0;s:8:\"NEW SITE\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:1:\"8\";}',1,0,'','',0,'',0,NULL,NULL),(13,0,1639057528,1,2,1,'sys_template',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.23.0.6','a:3:{i:0;s:8:\"NEW SITE\";i:1;s:14:\"sys_template:1\";s:7:\"history\";s:1:\"9\";}',1,0,'','',0,'',0,NULL,NULL),(14,0,1639057561,1,2,1,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.23.0.6','a:3:{i:0;s:203:\"Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores ...\";i:1;s:12:\"tt_content:1\";s:7:\"history\";s:2:\"10\";}',1,0,'','',0,'',0,NULL,NULL),(15,0,1639057856,1,1,0,'',0,0,'Uploading file \"%s\" to \"%s\"',2,1,'172.23.0.6','a:2:{i:0;s:9:\"DevOp.png\";i:1;s:13:\"/user_upload/\";}',-1,0,'','',0,'',0,NULL,NULL),(16,0,1639057860,1,1,2,'tt_content',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'172.23.0.6','a:4:{i:0;s:10:\"[No title]\";i:1;s:12:\"tt_content:2\";i:2;s:4:\"Home\";i:3;i:1;}',1,0,'NEW61b20988c57ba658654552','',0,'',0,NULL,NULL),(17,0,1639057860,1,1,1,'sys_file_reference',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'172.23.0.6','a:4:{i:0;s:9:\"DevOp.png\";i:1;s:20:\"sys_file_reference:1\";i:2;s:4:\"Home\";i:3;i:1;}',1,0,'NEW61b209c0afe1a441324505','',0,'',0,NULL,NULL),(18,0,1639057860,1,2,2,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.23.0.6','a:3:{i:0;s:10:\"[No title]\";i:1;s:12:\"tt_content:2\";s:7:\"history\";i:0;}',1,0,'','',0,'',0,NULL,NULL),(19,0,1639057998,1,1,0,'',0,0,'Uploading file \"%s\" to \"%s\"',2,1,'172.23.0.6','a:2:{i:0;s:9:\"DevOp.png\";i:1;s:1:\"/\";}',-1,0,'','',0,'',0,NULL,NULL),(20,0,1639058015,1,2,2,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.23.0.6','a:3:{i:0;s:10:\"[No title]\";i:1;s:12:\"tt_content:2\";s:7:\"history\";s:2:\"13\";}',1,0,'','',0,'',0,NULL,NULL),(21,0,1639058015,1,1,2,'sys_file_reference',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'172.23.0.6','a:4:{i:0;s:9:\"DevOp.png\";i:1;s:20:\"sys_file_reference:2\";i:2;s:4:\"Home\";i:3;i:1;}',1,0,'NEW61b20a5dcb50d082098967','',0,'',0,NULL,NULL),(22,0,1639058015,1,2,2,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.23.0.6','a:3:{i:0;s:10:\"[No title]\";i:1;s:12:\"tt_content:2\";s:7:\"history\";s:2:\"15\";}',1,0,'','',0,'',0,NULL,NULL),(23,0,1639058015,1,3,1,'sys_file_reference',0,0,'Record \'%s\' (%s) was deleted from page \'%s\' (%s)',1,0,'172.23.0.6','a:4:{i:0;s:9:\"DevOp.png\";i:1;s:20:\"sys_file_reference:1\";i:2;s:4:\"Home\";i:3;i:1;}',1,0,'','',0,'',0,NULL,NULL),(24,0,1639058044,1,3,1,'tt_content',0,0,'Record \'%s\' (%s) was deleted from page \'%s\' (%s)',1,0,'172.23.0.6','a:4:{i:0;s:203:\"Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores ...\";i:1;s:12:\"tt_content:1\";i:2;s:4:\"Home\";i:3;i:1;}',1,0,'','',0,'',0,NULL,NULL),(25,0,1639058072,1,1,3,'tt_content',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'172.23.0.6','a:4:{i:0;s:203:\"Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores ...\";i:1;s:12:\"tt_content:3\";i:2;s:4:\"Home\";i:3;i:1;}',1,0,'NEW61b20a8718021086272637','',0,'',0,NULL,NULL),(26,0,1639058089,1,3,3,'tt_content',0,0,'Record \'%s\' (%s) was deleted from page \'%s\' (%s)',1,0,'172.23.0.6','a:4:{i:0;s:203:\"Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores ...\";i:1;s:12:\"tt_content:3\";i:2;s:4:\"Home\";i:3;i:1;}',1,0,'','',0,'',0,NULL,NULL),(27,0,1639058194,1,1,4,'tt_content',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'172.23.0.6','a:4:{i:0;s:203:\"Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores ...\";i:1;s:12:\"tt_content:4\";i:2;s:4:\"Home\";i:3;i:1;}',1,0,'NEW61b20b0a203b4633014468','',0,'',0,NULL,NULL),(28,0,1639059354,1,2,2,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.23.0.6','a:3:{i:0;s:10:\"[No title]\";i:1;s:12:\"tt_content:2\";s:7:\"history\";s:2:\"21\";}',1,0,'','',0,'',0,NULL,NULL),(29,0,1639059354,1,3,2,'sys_file_reference',0,0,'Record \'%s\' (%s) was deleted from page \'%s\' (%s)',1,0,'172.23.0.6','a:4:{i:0;s:9:\"DevOp.png\";i:1;s:20:\"sys_file_reference:2\";i:2;s:4:\"Home\";i:3;i:1;}',1,0,'','',0,'',0,NULL,NULL),(30,0,1639059378,1,4,0,'',0,0,'File \"%s\" deleted',2,1,'172.23.0.6','a:1:{i:0;s:10:\"/DevOp.png\";}',-1,0,'','',0,'',0,NULL,NULL),(31,0,1639059383,1,1,0,'',0,0,'Uploading file \"%s\" to \"%s\"',2,1,'172.23.0.6','a:2:{i:0;s:9:\"DevOp.png\";i:1;s:1:\"/\";}',-1,0,'','',0,'',0,NULL,NULL),(32,0,1639059425,1,2,2,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.23.0.6','a:3:{i:0;s:10:\"[No title]\";i:1;s:12:\"tt_content:2\";s:7:\"history\";i:0;}',1,0,'','',0,'',0,NULL,NULL),(33,0,1639059425,1,1,3,'sys_file_reference',0,0,'Record \'%s\' (%s) was inserted on page \'%s\' (%s)',1,10,'172.23.0.6','a:4:{i:0;s:9:\"DevOp.png\";i:1;s:20:\"sys_file_reference:3\";i:2;s:4:\"Home\";i:3;i:1;}',1,0,'NEW61b20fdecf567326325230','',0,'',0,NULL,NULL),(34,0,1639059425,1,2,2,'tt_content',0,0,'Record \'%s\' (%s) was updated. (Online).',1,10,'172.23.0.6','a:3:{i:0;s:10:\"[No title]\";i:1;s:12:\"tt_content:2\";s:7:\"history\";i:0;}',1,0,'','',0,'',0,NULL,NULL);
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `content` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `message` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tablename` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `recuid` int(11) NOT NULL DEFAULT 0,
  `field` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `flexpointer` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `softref_key` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `softref_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `ref_table` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`(100),`recuid`),
  KEY `lookup_uid` (`ref_table`(100),`ref_uid`),
  KEY `lookup_string` (`ref_string`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES ('03385cc350d36e9aefea64cd095f918d','sys_file_reference',2,'uid_local','','','',0,1,0,'sys_file',3,''),('5466a62d7dac2c88afbb1c572e2744b0','sys_file_reference',1,'uid_local','','','',0,1,0,'sys_file',3,''),('63747fd73040778d4a4dd19e44961737','tt_content',2,'image','','','',0,0,0,'sys_file_reference',3,''),('764ed7b4d26b234a0b36628e00db1247','sys_file',5,'storage','','','',0,0,0,'sys_file_storage',1,''),('7a66b3840db495c00630b24088cf396c','sys_file',3,'metadata','','','',0,0,0,'sys_file_metadata',3,''),('893e20b39f66903f90c681e8c41b6297','sys_file',3,'storage','','','',0,0,0,'sys_file_storage',1,''),('89ac10896dd65fbf4a567be2e7d8cdd1','sys_file_reference',3,'uid_local','','','',0,0,0,'sys_file',5,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_key` varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES (1,'installUpdate','TYPO3\\CMS\\Form\\Hooks\\FormFileExtensionUpdate','i:1;'),(2,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Typo3DbExtractionUpdate','i:1;'),(3,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FuncExtractionUpdate','i:1;'),(4,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateUrlTypesInPagesUpdate','i:1;'),(5,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RedirectExtractionUpdate','i:1;'),(6,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendUserStartModuleUpdate','i:1;'),(7,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigratePagesLanguageOverlayUpdate','i:1;'),(8,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigratePagesLanguageOverlayBeGroupsAccessRights','i:1;'),(9,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendLayoutIconUpdateWizard','i:1;'),(10,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RedirectsExtensionUpdate','i:1;'),(11,'installUpdate','TYPO3\\CMS\\Install\\Updates\\AdminPanelInstall','i:1;'),(12,'installUpdate','TYPO3\\CMS\\Install\\Updates\\PopulatePageSlugs','i:1;'),(13,'installUpdate','TYPO3\\CMS\\Install\\Updates\\Argon2iPasswordHashes','i:1;'),(14,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendUserConfigurationUpdate','i:1;'),(15,'installUpdate','TYPO3\\CMS\\Install\\Updates\\RsaauthExtractionUpdate','i:1;'),(16,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FeeditExtractionUpdate','i:1;'),(17,'installUpdate','TYPO3\\CMS\\Install\\Updates\\TaskcenterExtractionUpdate','i:1;'),(18,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysActionExtractionUpdate','i:1;'),(19,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SvgFilesSanitization','i:1;'),(20,'installUpdate','TYPO3\\CMS\\Felogin\\Updates\\MigrateFeloginPlugins','i:1;'),(21,'installUpdateRows','rowUpdatersDone','a:1:{i:0;s:69:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\WorkspaceVersionRecordsMigration\";}'),(22,'core','formProtectionSessionToken:1','s:64:\"3182f95bfc7d9cae6d47a17095117576a021425270d73d9b17e25304691ceac5\";');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sitetitle` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `include_static_file` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `constants` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `config` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `basedOn` tinytext COLLATE utf8_unicode_ci DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `static_file_mode` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
INSERT INTO `sys_template` VALUES (1,1,1639057528,1639057398,1,0,0,0,0,256,NULL,0,0,0,0,0,0,0,0,'NEW SITE','',1,3,'EXT:my_sitepackage/Configuration/TypoScript,EXT:bootstrap_package/Configuration/TypoScript,EXT:bootstrap_package/Configuration/TypoScript/ContentElement,EXT:bootstrap_package/Configuration/TypoScript/Bootstrap5',NULL,'','',0,0,0);
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rowDescription` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `CType` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `header` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `header_position` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bodytext` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `bullets_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned NOT NULL DEFAULT 0,
  `imageorient` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `frame_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `space_after_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `records` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `pages` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `subheader` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `header_link` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `header_layout` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `list_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 0,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `target` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `date` int(10) unsigned NOT NULL DEFAULT 0,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageheight` int(10) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `accessibility_title` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `accessibility_bypass` smallint(5) unsigned NOT NULL DEFAULT 0,
  `accessibility_bypass_text` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `selected_categories` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_field` varchar(64) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `table_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `table_caption` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `table_delimiter` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_enclosure` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_header_position` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `categories` int(11) NOT NULL DEFAULT 0,
  `teaser` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `aspect_ratio` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1.3333333333333',
  `items_per_page` int(10) unsigned DEFAULT 10,
  `readmore_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `quote_source` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `quote_link` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `panel_class` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `file_folder` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `icon_set` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `icon_file` int(10) unsigned DEFAULT 0,
  `icon_position` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `icon_size` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `icon_type` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `icon_color` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `icon_background` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `external_media_source` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `external_media_ratio` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tx_bootstrappackage_card_group_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_carousel_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_accordion_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_icon_group_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_tab_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_timeline_item` int(10) unsigned DEFAULT 0,
  `frame_layout` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `background_color_class` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `background_image` int(10) unsigned DEFAULT 0,
  `background_image_options` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES (1,'',1,1639058044,1639057453,1,1,0,0,0,'',256,0,0,0,0,NULL,0,'a:27:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:8:\"bodytext\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"frame_layout\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'text','','','<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>',0,0,0,0,0,0,0,1,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,NULL,'1.3333333333333',10,'','','','default',NULL,'','',0,'','default','default','#FFFFFF','#333333','','',0,0,0,0,0,0,'default','none',0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"parallax\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fade\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"filter\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>'),(2,'',1,1639059425,1639057860,1,0,0,0,0,'',512,0,0,0,0,NULL,0,'a:33:{s:5:\"CType\";N;s:6:\"colPos\";N;s:6:\"header\";N;s:13:\"header_layout\";N;s:15:\"header_position\";N;s:4:\"date\";N;s:11:\"header_link\";N;s:9:\"subheader\";N;s:8:\"bodytext\";N;s:5:\"image\";N;s:11:\"file_folder\";N;s:16:\"filelink_sorting\";N;s:11:\"imageorient\";N;s:9:\"imagecols\";N;s:10:\"image_zoom\";N;s:6:\"layout\";N;s:11:\"frame_class\";N;s:18:\"space_before_class\";N;s:17:\"space_after_class\";N;s:12:\"frame_layout\";N;s:22:\"background_color_class\";N;s:16:\"background_image\";N;s:24:\"background_image_options\";N;s:12:\"sectionIndex\";N;s:9:\"linkToTop\";N;s:16:\"sys_language_uid\";N;s:6:\"hidden\";N;s:9:\"starttime\";N;s:7:\"endtime\";N;s:8:\"fe_group\";N;s:8:\"editlock\";N;s:10:\"categories\";N;s:14:\"rowDescription\";N;}',0,0,0,0,0,0,0,'textpic','','','',0,0,0,0,1,0,0,1,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,NULL,'1.3333333333333',10,'','','','default','','','',0,'','default','default','#FFFFFF','#333333','','',0,0,0,0,0,0,'default','none',0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"parallax\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fade\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"filter\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>'),(3,'',1,1639058089,1639058072,1,1,0,0,0,'',256,0,0,0,0,NULL,0,'',0,0,0,0,0,0,0,'text','','','<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>',0,0,0,0,0,0,0,1,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,NULL,'1.3333333333333',10,'','','','default',NULL,'','',0,'','default','default','#FFFFFF','#333333','','',0,0,0,0,0,0,'default','none',0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"parallax\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fade\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"filter\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>'),(4,'',1,1639058194,1639058194,1,0,0,0,0,'',256,0,0,0,0,NULL,0,'',0,0,0,0,0,0,0,'text','','','<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>',0,0,0,0,0,0,0,1,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'',NULL,'','',NULL,124,0,0,0,0,0,NULL,'1.3333333333333',10,'','','','default',NULL,'','',0,'','default','default','#FFFFFF','#333333','','',0,0,0,0,0,0,'default','none',0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"parallax\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fade\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"filter\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>');
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_accordion_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_accordion_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_accordion_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `header` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bodytext` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `media` int(10) unsigned DEFAULT 0,
  `mediaorient` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'left',
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 1,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_accordion_item`
--

LOCK TABLES `tx_bootstrappackage_accordion_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_accordion_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_accordion_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_card_group_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_card_group_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_card_group_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `header` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `subheader` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `image` int(11) NOT NULL DEFAULT 0,
  `bodytext` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_icon_set` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_icon_identifier` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_icon` int(10) unsigned DEFAULT 0,
  `link_class` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_card_group_item`
--

LOCK TABLES `tx_bootstrappackage_card_group_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_card_group_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_card_group_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_carousel_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_carousel_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_carousel_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `item_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `layout` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `header` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `header_layout` smallint(5) unsigned NOT NULL DEFAULT 1,
  `header_position` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'center',
  `header_class` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `subheader` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `subheader_layout` smallint(5) unsigned NOT NULL DEFAULT 2,
  `subheader_class` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `nav_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `button_text` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bodytext` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `image` int(10) unsigned DEFAULT 0,
  `link` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `text_color` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `background_color` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `background_image` int(10) unsigned DEFAULT 0,
  `background_image_options` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_carousel_item`
--

LOCK TABLES `tx_bootstrappackage_carousel_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_carousel_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_carousel_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_icon_group_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_icon_group_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_icon_group_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `header` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `subheader` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bodytext` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(1024) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `icon_set` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `icon_identifier` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `icon_file` int(10) unsigned DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_icon_group_item`
--

LOCK TABLES `tx_bootstrappackage_icon_group_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_icon_group_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_icon_group_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_tab_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_tab_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_tab_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `header` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bodytext` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `media` int(10) unsigned DEFAULT 0,
  `mediaorient` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'left',
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 1,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_tab_item`
--

LOCK TABLES `tx_bootstrappackage_tab_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_tab_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_tab_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_timeline_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_timeline_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_timeline_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `t3ver_count` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_move_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `tt_content` int(10) unsigned DEFAULT 0,
  `date` datetime DEFAULT NULL,
  `header` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bodytext` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `icon_set` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `icon_identifier` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `icon_file` int(10) unsigned DEFAULT 0,
  `image` int(10) unsigned DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `t3ver_id` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_timeline_item`
--

LOCK TABLES `tx_bootstrappackage_timeline_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_timeline_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_timeline_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_extension`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_extensionmanager_domain_model_extension` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_key` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `repository` int(10) unsigned NOT NULL DEFAULT 1,
  `version` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `alldownloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `downloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `review_state` int(11) NOT NULL DEFAULT 0,
  `category` int(11) NOT NULL DEFAULT 0,
  `last_updated` int(10) unsigned NOT NULL DEFAULT 0,
  `serialized_dependencies` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `author_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `author_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ownerusername` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `md5hash` varchar(35) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `update_comment` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `authorcompany` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `integer_version` int(11) NOT NULL DEFAULT 0,
  `current_version` int(11) NOT NULL DEFAULT 0,
  `lastreviewedversion` int(11) NOT NULL DEFAULT 0,
  `documentation_link` varchar(2048) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `versionextrepo` (`extension_key`,`version`,`repository`),
  KEY `index_extrepo` (`extension_key`,`repository`),
  KEY `index_versionrepo` (`integer_version`,`repository`,`extension_key`),
  KEY `index_currentversions` (`current_version`,`review_state`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_extension`
--

LOCK TABLES `tx_extensionmanager_domain_model_extension` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_repository`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_repository`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_extensionmanager_domain_model_repository` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `wsdl_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `mirror_list_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `last_update` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_count` int(11) NOT NULL DEFAULT 0,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_repository`
--

LOCK TABLES `tx_extensionmanager_domain_model_repository` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_repository` DISABLE KEYS */;
INSERT INTO `tx_extensionmanager_domain_model_repository` VALUES (1,'TYPO3.org Main Repository','Main repository on typo3.org. This repository has some mirrors configured which are available with the mirror url.','https://typo3.org/wsdl/tx_ter_wsdl.php','https://repositories.typo3.org/mirrors.xml.gz',1346191200,0,0);
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_repository` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-09 14:22:52
